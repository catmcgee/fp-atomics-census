r"""
Compile-time auto-tuning block: 

import torch
from math import inf, nan
from torch._dynamo.testing import rand_strided
from torch._dynamo.utils import preserve_rng_state
from torch._inductor.select_algorithm import AlgorithmSelectorCache
from torch._inductor.async_compile import AsyncCompile

async_compile = AsyncCompile()
generate_example_value = AlgorithmSelectorCache.generate_example_value
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
get_raw_stream = torch._C._cuda_getCurrentRawStream


# kernel path: /tmp/torchinductor_root/o4/co4mgrmlzjuntxot2pel3sv6dwpa3qiuwbczmntcborlijakgu5s.py
# Topologically Sorted Source Nodes: [view, abs_1, max_1], Original ATen: [aten.view, aten.abs, aten.max]
# Source node to ATen node mapping:
#   abs_1 => abs_1
#   max_1 => max_1
#   view => view
# Graph fragment:
#   %arg0_1 : Tensor "bf16[s72, 28, 128][3584, 128, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %view : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%arg0_1, [-1, 3584]), kwargs = {})
#   %abs_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%view,), kwargs = {})
#   %max_1 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_1,), kwargs = {})
#   return %buf2
triton_red_fused_abs_max_view_0 = async_compile.triton('triton_red_fused_abs_max_view_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 512, 'r0_': 131072},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'ks0': 'i64', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_abs_max_view_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 4096, 'r0_': 117440512}, 'kernel_num_gb': 0.11744256, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_abs_max_view_0(in_ptr0, out_ptr0, ks0, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 512
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp3 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (((r0_1 + 7*ks0*x0) % (3584*ks0))), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl_math.abs(tmp0)
        tmp2 = tl.broadcast_to(tmp1, [XBLOCK, R0_BLOCK])
        tmp4 = triton_helpers.maximum(_tmp3, tmp2)
        _tmp3 = tl.where(r0_mask & xmask, tmp4, _tmp3)
    tmp3 = triton_helpers.max2(_tmp3, 1)[:, None]
    tl.store(out_ptr0 + (x0), tmp3, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/rv/crv4nsvpan3bi4pcidkzxzyrovc423mhopehoxdv34k7cs4rpfef.py
# Topologically Sorted Source Nodes: [view, to_1, abs_1, max_1, unsqueeze, to, truediv, clamp, reciprocal, mul, clamp_1, to_3, cutlass_scaled_mm], Original ATen: [aten.view, aten._to_copy, aten.abs, aten.max, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   abs_1 => abs_1
#   clamp => clamp_min
#   clamp_1 => clamp_max, clamp_min_1
#   cutlass_scaled_mm => cutlass_scaled_mm_default_3
#   max_1 => max_1
#   mul => mul_8
#   reciprocal => reciprocal
#   to => convert_element_type
#   to_1 => convert_element_type_1
#   to_3 => convert_element_type_2
#   truediv => div
#   unsqueeze => unsqueeze
#   view => view
# Graph fragment:
#   %buf2 : Tensor "f32[512][1]cuda:0" = PlaceHolder[target=buf2]
#   %max_1 : Tensor "bf16[][]cuda:0" = PlaceHolder[target=max_1]
#   %view : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%arg0_1, [-1, 3584]), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.float32), kwargs = {})
#   %abs_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%view,), kwargs = {})
#   %max_1 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_1,), kwargs = {})
#   %unsqueeze : Tensor "bf16[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%max_1, -1), kwargs = {})
#   %convert_element_type : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %div : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type, 448.0), kwargs = {})
#   %clamp_min : Tensor "f32[1][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div, 4.359654017857143e-06), kwargs = {})
#   %reciprocal : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min,), kwargs = {})
#   %mul_8 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_1, %reciprocal), kwargs = {})
#   %clamp_min_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_8, -448.0), kwargs = {})
#   %clamp_max : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_1, 448.0), kwargs = {})
#   %convert_element_type_2 : Tensor "f8e4m3fn[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_3 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty, %convert_element_type_2, %arg2_1, %clamp_min, %arg3_1, None), kwargs = {})
#   return %max_1,%buf5
triton_per_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_1 = async_compile.triton('triton_per_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 1, 'r0_': 512},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*fp32', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 2048}, 'kernel_num_gb': 2.054e-06, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_per_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_1(in_ptr0, out_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 512
    R0_BLOCK: tl.constexpr = 512
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_0 = r0_index
    tmp0 = tl.load(in_ptr0 + (r0_0), None, eviction_policy='evict_first')
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK, R0_BLOCK])
    tmp3 = triton_helpers.max2(tmp1, 1)[:, None].to(tl.float32)
    tmp4 = tmp3.to(tl.float32)
    tmp5 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp6 = tmp4 * tmp5
    tmp7 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
    tmp8 = triton_helpers.maximum(tmp6, tmp7)
    tl.store(out_ptr1 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp8, None)
    tl.store(out_ptr0 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp3, None)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/3a/c3aze2xrwkho426sn2f76dqzbx2xiruort5xz7a5fzy4gaavumow.py
# Topologically Sorted Source Nodes: [view, to_1, unsqueeze, to, truediv, clamp, reciprocal, mul, clamp_1, to_3, cutlass_scaled_mm], Original ATen: [aten.view, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   clamp => clamp_min
#   clamp_1 => clamp_max, clamp_min_1
#   cutlass_scaled_mm => cutlass_scaled_mm_default_3
#   mul => mul_8
#   reciprocal => reciprocal
#   to => convert_element_type
#   to_1 => convert_element_type_1
#   to_3 => convert_element_type_2
#   truediv => div
#   unsqueeze => unsqueeze
#   view => view
# Graph fragment:
#   %arg0_1 : Tensor "bf16[s72, 28, 128][3584, 128, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %max_1 : Tensor "bf16[][]cuda:0" = PlaceHolder[target=max_1]
#   %view : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%arg0_1, [-1, 3584]), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.float32), kwargs = {})
#   %unsqueeze : Tensor "bf16[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%max_1, -1), kwargs = {})
#   %convert_element_type : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %div : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type, 448.0), kwargs = {})
#   %clamp_min : Tensor "f32[1][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div, 4.359654017857143e-06), kwargs = {})
#   %reciprocal : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min,), kwargs = {})
#   %mul_8 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_1, %reciprocal), kwargs = {})
#   %clamp_min_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_8, -448.0), kwargs = {})
#   %clamp_max : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_1, 448.0), kwargs = {})
#   %convert_element_type_2 : Tensor "f8e4m3fn[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_3 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty, %convert_element_type_2, %arg2_1, %clamp_min, %arg3_1, None), kwargs = {})
#   return %buf4
triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2 = async_compile.triton('triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 67108864}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*fp8e4nv', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 234881024}, 'kernel_num_gb': 0.17616077, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=2
)
@triton.jit
def triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (0)).to(tl.float32)
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK])
    tmp1 = tmp0.to(tl.float32)
    tmp4 = tmp3.to(tl.float32)
    tmp5 = tl.full([1], 0.002232142857142857, tl.float32)
    tmp6 = tmp4 * tmp5
    tmp7 = tl.full([1], 4.359654017857143e-06, tl.float32)
    tmp8 = triton_helpers.maximum(tmp6, tmp7)
    tmp9 = tl.full([1], 1.0, tl.float32)
    tmp10 = (tmp9 / tmp8)
    tmp11 = tmp1 * tmp10
    tmp12 = tl.full([1], -448.0, tl.float32)
    tmp13 = triton_helpers.maximum(tmp11, tmp12)
    tmp14 = tl.full([1], 448.0, tl.float32)
    tmp15 = triton_helpers.minimum(tmp13, tmp14)
    tmp16 = tmp15.to(tl.float8e4nv)
    tl.store(out_ptr0 + (x0), tmp16, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/gu/cgu6umxyqv26q5ope4p7bcd32jyqwsx7hxxxip2qecmytyim25c7.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, abs_2, max_2], Original ATen: [vllm_ir.fused_add_rms_norm, aten.abs, aten.max]
# Source node to ATen node mapping:
#   abs_2 => abs_2
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, add_tensor_3, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_7, mean_dim_1, mul_tensor_2, mul_tensor_3, pow_tensor_scalar_1, rsqrt_default_1
#   max_2 => max_2
# Graph fragment:
#   %buf7 : Tensor  = PlaceHolder[target=buf7]
#   %arg5_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %buf8 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf8]
#   %arg4_1 : Tensor "bf16[3584][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %convert_element_type_default_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %pow_tensor_scalar_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_2, 2), kwargs = {})
#   %mean_dim_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_1, [-1], True), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_1, 1e-06), kwargs = {})
#   %rsqrt_default_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_2, %rsqrt_default_1), kwargs = {})
#   %convert_element_type_default_7 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_2, torch.bfloat16), kwargs = {})
#   %mul_tensor_3 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_7, %arg4_1), kwargs = {})
#   %abs_2 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_tensor_3,), kwargs = {})
#   %max_2 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_2,), kwargs = {})
#   return %buf8,%buf10
triton_red_fused_abs_fused_add_rms_norm_max_3 = async_compile.triton('triton_red_fused_abs_fused_add_rms_norm_max_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_abs_fused_add_rms_norm_max_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 262144, 'r0_': 117447680}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.117578752, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_abs_fused_add_rms_norm_max_3(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 3584
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp1 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tl.store(out_ptr0 + (x0), tmp7, xmask)
    _tmp25 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp21 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tmp9.to(tl.float32)
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tmp10 + tmp12
        tmp14 = tl.full([1, 1], 3584.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1, 1], 1e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp20 = tmp19.to(tl.float32)
        tmp22 = tmp20 * tmp21
        tmp23 = tl_math.abs(tmp22)
        tmp24 = tl.broadcast_to(tmp23, [XBLOCK, R0_BLOCK])
        tmp26 = triton_helpers.maximum(_tmp25, tmp24)
        _tmp25 = tl.where(r0_mask & xmask, tmp26, _tmp25)
    tmp25 = triton_helpers.max2(_tmp25, 1)[:, None]
    tl.store(out_ptr1 + (x0), tmp25, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/k5/ck5q6wahumf22tbxxw3ha7yc6w6p4h3etbn6zmbmhzic5fxprzbi.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, to_5, abs_2, max_2, unsqueeze_1, to_4, truediv_1, clamp_2, reciprocal_1, mul_1, clamp_3, to_7, cutlass_scaled_mm_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten._to_copy, aten.abs, aten.max, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   abs_2 => abs_2
#   clamp_2 => clamp_min_2
#   clamp_3 => clamp_max_1, clamp_min_3
#   cutlass_scaled_mm_1 => cutlass_scaled_mm_default_2
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, add_tensor_3, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_7, mean_dim_1, mul_tensor_2, mul_tensor_3, pow_tensor_scalar_1, rsqrt_default_1
#   max_2 => max_2
#   mul_1 => mul_31
#   reciprocal_1 => reciprocal_1
#   to_4 => convert_element_type_3
#   to_5 => convert_element_type_4
#   to_7 => convert_element_type_5
#   truediv_1 => div_1
#   unsqueeze_1 => unsqueeze_1
# Graph fragment:
#   %buf10 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf10]
#   %max_2 : Tensor "bf16[][]cuda:0" = PlaceHolder[target=max_2]
#   %convert_element_type_default_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %pow_tensor_scalar_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_2, 2), kwargs = {})
#   %mean_dim_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_1, [-1], True), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_1, 1e-06), kwargs = {})
#   %rsqrt_default_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_2, %rsqrt_default_1), kwargs = {})
#   %convert_element_type_default_7 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_2, torch.bfloat16), kwargs = {})
#   %mul_tensor_3 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_7, %arg4_1), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_3, torch.float32), kwargs = {})
#   %abs_2 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_tensor_3,), kwargs = {})
#   %max_2 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_2,), kwargs = {})
#   %unsqueeze_1 : Tensor "bf16[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%max_2, -1), kwargs = {})
#   %convert_element_type_3 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_1, torch.float32), kwargs = {})
#   %div_1 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_3, 448.0), kwargs = {})
#   %clamp_min_2 : Tensor "f32[1][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div_1, 4.359654017857143e-06), kwargs = {})
#   %reciprocal_1 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min_2,), kwargs = {})
#   %mul_31 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_4, %reciprocal_1), kwargs = {})
#   %clamp_min_3 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_31, -448.0), kwargs = {})
#   %clamp_max_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_3, 448.0), kwargs = {})
#   %convert_element_type_5 : Tensor "f8e4m3fn[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max_1, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_2 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty_1, %convert_element_type_5, %arg6_1, %clamp_min_2, %arg7_1, None), kwargs = {})
#   return %max_2,%buf13
triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_4 = async_compile.triton('triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 16384},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*fp32', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 65536}, 'kernel_num_gb': 6.5542e-05, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_4(in_ptr0, out_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    _tmp2 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.broadcast_to(tmp0, [XBLOCK, R0_BLOCK])
        tmp3 = triton_helpers.maximum(_tmp2, tmp1)
        _tmp2 = tl.where(r0_mask, tmp3, _tmp2)
    tmp2 = triton_helpers.max2(_tmp2, 1)[:, None]
    tl.store(out_ptr0 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp2, None)
    tmp4 = tmp2.to(tl.float32)
    tmp5 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp6 = tmp4 * tmp5
    tmp7 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
    tmp8 = triton_helpers.maximum(tmp6, tmp7)
    tl.store(out_ptr1 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp8, None)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/xw/cxwqaiqfum5cnelxy7yg6uol3dxgg27tjnlvknyxipfsdtn4tm6i.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, to_5, unsqueeze_1, to_4, truediv_1, clamp_2, reciprocal_1, mul_1, clamp_3, to_7, cutlass_scaled_mm_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   clamp_2 => clamp_min_2
#   clamp_3 => clamp_max_1, clamp_min_3
#   cutlass_scaled_mm_1 => cutlass_scaled_mm_default_2
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, add_tensor_3, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_7, mean_dim_1, mul_tensor_2, mul_tensor_3, pow_tensor_scalar_1, rsqrt_default_1
#   mul_1 => mul_31
#   reciprocal_1 => reciprocal_1
#   to_4 => convert_element_type_3
#   to_5 => convert_element_type_4
#   to_7 => convert_element_type_5
#   truediv_1 => div_1
#   unsqueeze_1 => unsqueeze_1
# Graph fragment:
#   %buf7 : Tensor  = PlaceHolder[target=buf7]
#   %arg5_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %buf8 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf8]
#   %arg4_1 : Tensor "bf16[3584][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %max_2 : Tensor "bf16[][]cuda:0" = PlaceHolder[target=max_2]
#   %convert_element_type_default_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %pow_tensor_scalar_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_2, 2), kwargs = {})
#   %mean_dim_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_1, [-1], True), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_1, 1e-06), kwargs = {})
#   %rsqrt_default_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_2, %rsqrt_default_1), kwargs = {})
#   %convert_element_type_default_7 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_2, torch.bfloat16), kwargs = {})
#   %mul_tensor_3 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_7, %arg4_1), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_3, torch.float32), kwargs = {})
#   %unsqueeze_1 : Tensor "bf16[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%max_2, -1), kwargs = {})
#   %convert_element_type_3 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_1, torch.float32), kwargs = {})
#   %div_1 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_3, 448.0), kwargs = {})
#   %clamp_min_2 : Tensor "f32[1][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div_1, 4.359654017857143e-06), kwargs = {})
#   %reciprocal_1 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min_2,), kwargs = {})
#   %mul_31 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_4, %reciprocal_1), kwargs = {})
#   %clamp_min_3 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_31, -448.0), kwargs = {})
#   %clamp_max_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_3, 448.0), kwargs = {})
#   %convert_element_type_5 : Tensor "f8e4m3fn[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max_1, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_2 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty_1, %convert_element_type_5, %arg6_1, %clamp_min_2, %arg7_1, None), kwargs = {})
#   return %buf12
triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_mul_reciprocal_unsqueeze_5 = async_compile.triton('triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_mul_reciprocal_unsqueeze_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 67108864}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr0': '*fp8e4nv', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_mul_reciprocal_unsqueeze_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 234953728}, 'kernel_num_gb': 0.176233474, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=2
)
@triton.jit
def triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_mul_reciprocal_unsqueeze_5(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x1 = xindex // 3584
    x0 = (xindex % 3584)
    tmp0 = tl.load(in_ptr0 + (x2), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x2), xmask).to(tl.float32)
    tmp5 = tl.load(in_ptr2 + (x1), xmask, eviction_policy='evict_last')
    tmp13 = tl.load(in_ptr3 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp16 = tl.load(in_ptr4 + (0)).to(tl.float32)
    tmp17 = tl.broadcast_to(tmp16, [XBLOCK])
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 + tmp3
    tmp6 = tl.full([1], 3584.0, tl.float32)
    tmp7 = (tmp5 / tmp6)
    tmp8 = tl.full([1], 1e-06, tl.float32)
    tmp9 = tmp7 + tmp8
    tmp10 = libdevice.rsqrt(tmp9)
    tmp11 = tmp4 * tmp10
    tmp12 = tmp11.to(tl.float32)
    tmp14 = tmp12 * tmp13
    tmp15 = tmp14.to(tl.float32)
    tmp18 = tmp17.to(tl.float32)
    tmp19 = tl.full([1], 0.002232142857142857, tl.float32)
    tmp20 = tmp18 * tmp19
    tmp21 = tl.full([1], 4.359654017857143e-06, tl.float32)
    tmp22 = triton_helpers.maximum(tmp20, tmp21)
    tmp23 = tl.full([1], 1.0, tl.float32)
    tmp24 = (tmp23 / tmp22)
    tmp25 = tmp15 * tmp24
    tmp26 = tl.full([1], -448.0, tl.float32)
    tmp27 = triton_helpers.maximum(tmp25, tmp26)
    tmp28 = tl.full([1], 448.0, tl.float32)
    tmp29 = triton_helpers.minimum(tmp27, tmp28)
    tmp30 = tmp29.to(tl.float8e4nv)
    tl.store(out_ptr0 + (x2), tmp30, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/dq/cdqcllcu3pxeapsaylitflml7seepocmmvzsqa2il7c2a6e42dbx.py
# Topologically Sorted Source Nodes: [silu, mul_2, abs_3, max_3], Original ATen: [aten.slice, aten.silu, aten.mul, aten.abs, aten.max]
# Source node to ATen node mapping:
#   abs_3 => abs_3
#   max_3 => max_3
#   mul_2 => mul_50, slice_4
#   silu => add_72, convert_element_type_6, convert_element_type_7, div_2, exp, neg, slice_2
# Graph fragment:
#   %buf15 : Tensor  = PlaceHolder[target=buf15]
#   %slice_2 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 0, 18944), kwargs = {})
#   %convert_element_type_6 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_2, torch.float32), kwargs = {})
#   %neg : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_6,), kwargs = {})
#   %exp : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_72 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_6, %add_72), kwargs = {})
#   %convert_element_type_7 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_2, torch.bfloat16), kwargs = {})
#   %slice_4 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 18944, 9223372036854775807), kwargs = {})
#   %mul_50 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %slice_4), kwargs = {})
#   %abs_3 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_50,), kwargs = {})
#   %max_3 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_3,), kwargs = {})
#   return %buf18
triton_red_fused_abs_max_mul_silu_slice_6 = async_compile.triton('triton_red_fused_abs_max_mul_silu_slice_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4096, 'r0_': 131072},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'ks0': 'i64', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_abs_max_mul_silu_slice_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 18944, 'r0_': 0}, 'kernel_num_gb': 9.472e-06, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_abs_max_mul_silu_slice_6(in_ptr0, out_ptr0, ks0, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 2368
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp12 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (37888*((((r0_1 + 8*ks0*x0) // 18944) % ks0)) + (((r0_1 + 8*ks0*x0) % 18944))), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp8 = tl.load(in_ptr0 + (18944 + 37888*((((r0_1 + 8*ks0*x0) // 18944) % ks0)) + (((r0_1 + 8*ks0*x0) % 18944))), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = -tmp1
        tmp3 = libdevice.exp(tmp2)
        tmp4 = tl.full([1, 1], 1.0, tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = (tmp1 / tmp5)
        tmp7 = tmp6.to(tl.float32)
        tmp9 = tmp7 * tmp8
        tmp10 = tl_math.abs(tmp9)
        tmp11 = tl.broadcast_to(tmp10, [XBLOCK, R0_BLOCK])
        tmp13 = triton_helpers.maximum(_tmp12, tmp11)
        _tmp12 = tl.where(r0_mask & xmask, tmp13, _tmp12)
    tmp12 = triton_helpers.max2(_tmp12, 1)[:, None]
    tl.store(out_ptr0 + (x0), tmp12, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/77/c77xjpeqo37eox3cbbc42lzvk3mldqq5ktnpjnhm3k5qa3ntnfvt.py
# Topologically Sorted Source Nodes: [silu, mul_2, to_9, abs_3, max_3, unsqueeze_2, to_8, truediv_2, clamp_4, reciprocal_2, mul_3, clamp_5, to_11, cutlass_scaled_mm_2], Original ATen: [aten.slice, aten.silu, aten.mul, aten._to_copy, aten.abs, aten.max, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   abs_3 => abs_3
#   clamp_4 => clamp_min_4
#   clamp_5 => clamp_max_2, clamp_min_5
#   cutlass_scaled_mm_2 => cutlass_scaled_mm_default_1
#   max_3 => max_3
#   mul_2 => mul_50, slice_4
#   mul_3 => mul_59
#   reciprocal_2 => reciprocal_2
#   silu => add_72, convert_element_type_6, convert_element_type_7, div_2, exp, neg, slice_2
#   to_11 => convert_element_type_10
#   to_8 => convert_element_type_8
#   to_9 => convert_element_type_9
#   truediv_2 => div_3
#   unsqueeze_2 => unsqueeze_2
# Graph fragment:
#   %buf18 : Tensor "f32[2368][1]cuda:0" = PlaceHolder[target=buf18]
#   %max_3 : Tensor "bf16[][]cuda:0" = PlaceHolder[target=max_3]
#   %slice_2 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 0, 18944), kwargs = {})
#   %convert_element_type_6 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_2, torch.float32), kwargs = {})
#   %neg : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_6,), kwargs = {})
#   %exp : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_72 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_6, %add_72), kwargs = {})
#   %convert_element_type_7 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_2, torch.bfloat16), kwargs = {})
#   %slice_4 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 18944, 9223372036854775807), kwargs = {})
#   %mul_50 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %slice_4), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_50, torch.float32), kwargs = {})
#   %abs_3 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_50,), kwargs = {})
#   %max_3 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_3,), kwargs = {})
#   %unsqueeze_2 : Tensor "bf16[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%max_3, -1), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %div_3 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_8, 448.0), kwargs = {})
#   %clamp_min_4 : Tensor "f32[1][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div_3, 4.359654017857143e-06), kwargs = {})
#   %reciprocal_2 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min_4,), kwargs = {})
#   %mul_59 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_9, %reciprocal_2), kwargs = {})
#   %clamp_min_5 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_59, -448.0), kwargs = {})
#   %clamp_max_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_5, 448.0), kwargs = {})
#   %convert_element_type_10 : Tensor "f8e4m3fn[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max_2, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_1 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty_2, %convert_element_type_10, %arg8_1, %clamp_min_4, %arg9_1, None), kwargs = {})
#   return %max_3,%buf21
triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_7 = async_compile.triton('triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*fp32', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 9472}, 'kernel_num_gb': 9.478e-06, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_7(in_ptr0, out_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 2368
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    _tmp2 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.broadcast_to(tmp0, [XBLOCK, R0_BLOCK])
        tmp3 = triton_helpers.maximum(_tmp2, tmp1)
        _tmp2 = tl.where(r0_mask, tmp3, _tmp2)
    tmp2 = triton_helpers.max2(_tmp2, 1)[:, None]
    tl.store(out_ptr0 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp2, None)
    tmp4 = tmp2.to(tl.float32)
    tmp5 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp6 = tmp4 * tmp5
    tmp7 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
    tmp8 = triton_helpers.maximum(tmp6, tmp7)
    tl.store(out_ptr1 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp8, None)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/xr/cxr3alzfc6a77cth4z4elak65zlkb2cxflrqpechxsc6ymcum2lt.py
# Topologically Sorted Source Nodes: [silu, mul_2, to_9, unsqueeze_2, to_8, truediv_2, clamp_4, reciprocal_2, mul_3, clamp_5, to_11, cutlass_scaled_mm_2], Original ATen: [aten.slice, aten.silu, aten.mul, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   clamp_4 => clamp_min_4
#   clamp_5 => clamp_max_2, clamp_min_5
#   cutlass_scaled_mm_2 => cutlass_scaled_mm_default_1
#   mul_2 => mul_50, slice_4
#   mul_3 => mul_59
#   reciprocal_2 => reciprocal_2
#   silu => add_72, convert_element_type_6, convert_element_type_7, div_2, exp, neg, slice_2
#   to_11 => convert_element_type_10
#   to_8 => convert_element_type_8
#   to_9 => convert_element_type_9
#   truediv_2 => div_3
#   unsqueeze_2 => unsqueeze_2
# Graph fragment:
#   %buf15 : Tensor  = PlaceHolder[target=buf15]
#   %max_3 : Tensor "bf16[][]cuda:0" = PlaceHolder[target=max_3]
#   %slice_2 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 0, 18944), kwargs = {})
#   %convert_element_type_6 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_2, torch.float32), kwargs = {})
#   %neg : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_6,), kwargs = {})
#   %exp : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_72 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_6, %add_72), kwargs = {})
#   %convert_element_type_7 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_2, torch.bfloat16), kwargs = {})
#   %slice_4 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 18944, 9223372036854775807), kwargs = {})
#   %mul_50 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %slice_4), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_50, torch.float32), kwargs = {})
#   %unsqueeze_2 : Tensor "bf16[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%max_3, -1), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %div_3 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_8, 448.0), kwargs = {})
#   %clamp_min_4 : Tensor "f32[1][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div_3, 4.359654017857143e-06), kwargs = {})
#   %reciprocal_2 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min_4,), kwargs = {})
#   %mul_59 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_9, %reciprocal_2), kwargs = {})
#   %clamp_min_5 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_59, -448.0), kwargs = {})
#   %clamp_max_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_5, 448.0), kwargs = {})
#   %convert_element_type_10 : Tensor "f8e4m3fn[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max_2, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_1 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty_2, %convert_element_type_10, %arg8_1, %clamp_min_4, %arg9_1, None), kwargs = {})
#   return %buf20
triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_silu_slice_unsqueeze_8 = async_compile.triton('triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_silu_slice_unsqueeze_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 536870912}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*fp8e4nv', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_silu_slice_unsqueeze_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 620756992}, 'kernel_num_gb': 0.310378498, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=2
)
@triton.jit
def triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_silu_slice_unsqueeze_8(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 18944)
    x1 = xindex // 18944
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 37888*x1), xmask).to(tl.float32)
    tmp8 = tl.load(in_ptr0 + (18944 + x0 + 37888*x1), xmask).to(tl.float32)
    tmp11 = tl.load(in_ptr1 + (0)).to(tl.float32)
    tmp12 = tl.broadcast_to(tmp11, [XBLOCK])
    tmp1 = tmp0.to(tl.float32)
    tmp2 = -tmp1
    tmp3 = libdevice.exp(tmp2)
    tmp4 = tl.full([1], 1.0, tl.float32)
    tmp5 = tmp3 + tmp4
    tmp6 = (tmp1 / tmp5)
    tmp7 = tmp6.to(tl.float32)
    tmp9 = tmp7 * tmp8
    tmp10 = tmp9.to(tl.float32)
    tmp13 = tmp12.to(tl.float32)
    tmp14 = tl.full([1], 0.002232142857142857, tl.float32)
    tmp15 = tmp13 * tmp14
    tmp16 = tl.full([1], 4.359654017857143e-06, tl.float32)
    tmp17 = triton_helpers.maximum(tmp15, tmp16)
    tmp18 = (tmp4 / tmp17)
    tmp19 = tmp10 * tmp18
    tmp20 = tl.full([1], -448.0, tl.float32)
    tmp21 = triton_helpers.maximum(tmp19, tmp20)
    tmp22 = tl.full([1], 448.0, tl.float32)
    tmp23 = triton_helpers.minimum(tmp21, tmp22)
    tmp24 = tmp23.to(tl.float8e4nv)
    tl.store(out_ptr0 + (x2), tmp24, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/t6/ct643ivnmz6chgkiu345u4glp3fk7xojxi5gxdoyl4h7hzyeb52k.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, fused_add_rms_norm_maybe_inplace_1, abs_4, max_4], Original ATen: [vllm_ir.fused_add_rms_norm, aten.abs, aten.max]
# Source node to ATen node mapping:
#   abs_4 => abs_4
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_6
#   fused_add_rms_norm_maybe_inplace_1 => add_tensor, add_tensor_1, convert_element_type_default, convert_element_type_default_1, convert_element_type_default_2, convert_element_type_default_3, mean_dim, mul_tensor, mul_tensor_1, pow_tensor_scalar, rsqrt_default
#   max_4 => max_4
# Graph fragment:
#   %buf23 : Tensor  = PlaceHolder[target=buf23]
#   %buf7 : Tensor  = PlaceHolder[target=buf7]
#   %arg5_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %buf25 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf25]
#   %arg10_1 : Tensor "bf16[3584][1]cuda:0" = PlaceHolder[target=arg10_1]
#   %mul_tensor_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0" = PlaceHolder[target=mul_tensor_1]
#   %convert_element_type_default_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %convert_element_type_default_6 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor_2, torch.bfloat16), kwargs = {})
#   %convert_element_type_default : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty_2, torch.float32), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%convert_element_type_default_6, torch.float32), kwargs = {})
#   %add_tensor : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default, %convert_element_type_default_1), kwargs = {})
#   %convert_element_type_default_2 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor, torch.bfloat16), kwargs = {})
#   %pow_tensor_scalar : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor, 2), kwargs = {})
#   %mean_dim : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar, [-1], True), kwargs = {})
#   %add_tensor_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim, 1e-06), kwargs = {})
#   %rsqrt_default : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_1,), kwargs = {})
#   %mul_tensor : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor, %rsqrt_default), kwargs = {})
#   %convert_element_type_default_3 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor, torch.bfloat16), kwargs = {})
#   %mul_tensor_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_3, %arg10_1), kwargs = {})
#   %abs_4 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_tensor_1,), kwargs = {})
#   %max_4 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_4,), kwargs = {})
#   return %buf25,%convert_element_type_default_2,%mul_tensor_1,%buf28
triton_red_fused_abs_fused_add_rms_norm_max_9 = async_compile.triton('triton_red_fused_abs_fused_add_rms_norm_max_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_abs_fused_add_rms_norm_max_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 3, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 131072, 'r0_': 587209728}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.35239424, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_abs_fused_add_rms_norm_max_9(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, out_ptr2, out_ptr3, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 3584
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp12 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tl.load(in_ptr2 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp3 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp1 + tmp8
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [XBLOCK, R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask & xmask, tmp13, _tmp12)
        tmp14 = tmp9.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 3584*x0), tmp14, r0_mask & xmask)
    tmp12 = tl.sum(_tmp12, 1)[:, None]
    _tmp36 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp15 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp17 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp19 = tl.load(in_ptr2 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp32 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp16 = tmp15.to(tl.float32)
        tmp18 = tmp17.to(tl.float32)
        tmp20 = tmp19.to(tl.float32)
        tmp21 = tmp18 + tmp20
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp16 + tmp23
        tmp25 = tl.full([1, 1], 3584.0, tl.float32)
        tmp26 = (tmp12 / tmp25)
        tmp27 = tl.full([1, 1], 1e-06, tl.float32)
        tmp28 = tmp26 + tmp27
        tmp29 = libdevice.rsqrt(tmp28)
        tmp30 = tmp24 * tmp29
        tmp31 = tmp30.to(tl.float32)
        tmp33 = tmp31 * tmp32
        tmp34 = tl_math.abs(tmp33)
        tmp35 = tl.broadcast_to(tmp34, [XBLOCK, R0_BLOCK])
        tmp37 = triton_helpers.maximum(_tmp36, tmp35)
        _tmp36 = tl.where(r0_mask & xmask, tmp37, _tmp36)
        tl.store(out_ptr2 + (r0_1 + 3584*x0), tmp33, r0_mask & xmask)
    tmp36 = triton_helpers.max2(_tmp36, 1)[:, None]
    tl.store(out_ptr3 + (x0), tmp36, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/t7/ct7xmyznacyon5l62c4gcloxpwrp3kbaq6vzremumetolbme7yp3.py
# Unsorted Source Nodes: [], Original ATen: []
# Source node to ATen node mapping:
triton_poi_fused_10 = async_compile.triton('triton_poi_fused_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 67108864}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*i64', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'kernel_num_gb': 0.125960192, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_10(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 28)
    x2 = xindex // 3584
    x4 = xindex
    tmp0 = (x0).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 64, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tl.load(in_ptr0 + (128*x1 + 4608*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp8 = tl.load(in_ptr1 + (x2), tmp6 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp10 = tmp8 + tmp9
    tmp11 = tmp8 < 0
    tmp12 = tl.where(tmp11, tmp10, tmp8)
    tl.device_assert(((0 <= tl.broadcast_to(tmp12, [XBLOCK])) & (tl.broadcast_to(tmp12, [XBLOCK]) < 32768)) | ~(tmp6 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp12, [XBLOCK]) < 32768")
    tmp14 = tl.load(in_ptr2 + (128*tmp12 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp15 = tmp7 * tmp14
    tmp16 = tl.load(in_ptr0 + (64 + 128*x1 + 4608*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp17 = tl.load(in_ptr2 + (64 + 128*tmp12 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp18 = tmp16 * tmp17
    tmp19 = tmp15 - tmp18
    tmp20 = tl.full(tmp19.shape, 0.0, tmp19.dtype)
    tmp21 = tl.where(tmp6, tmp19, tmp20)
    tmp22 = tmp0 >= tmp5
    tmp23 = tl.full([1], 128, tl.int64)
    tmp24 = tmp0 < tmp23
    tmp25 = tl.load(in_ptr0 + (64 + 128*x1 + 4608*x2 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp26 = tl.load(in_ptr1 + (x2), tmp22 & xmask, eviction_policy='evict_last', other=0.0)
    tmp27 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp28 = tmp26 + tmp27
    tmp29 = tmp26 < 0
    tmp30 = tl.where(tmp29, tmp28, tmp26)
    tl.device_assert(((0 <= tl.broadcast_to(tmp30, [XBLOCK])) & (tl.broadcast_to(tmp30, [XBLOCK]) < 32768)) | ~(tmp22 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp30, [XBLOCK]) < 32768")
    tmp32 = tl.load(in_ptr2 + (128*tmp30 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp33 = tmp25 * tmp32
    tmp34 = tl.load(in_ptr0 + (128*x1 + 4608*x2 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp35 = tl.load(in_ptr2 + (64 + 128*tmp30 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp36 = tmp34 * tmp35
    tmp37 = tmp33 + tmp36
    tmp38 = tl.full(tmp37.shape, 0.0, tmp37.dtype)
    tmp39 = tl.where(tmp22, tmp37, tmp38)
    tmp40 = tl.where(tmp6, tmp21, tmp39)
    tl.store(out_ptr0 + (x4), tmp40, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/sy/csybsiuhrrrreq74metiuazdakmwnrtst6kgp4mq6hqa5ok4s4h4.py
# Unsorted Source Nodes: [], Original ATen: []
# Source node to ATen node mapping:
triton_poi_fused_11 = async_compile.triton('triton_poi_fused_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8388608}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*i64', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'kernel_num_gb': 0.025296896, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_11(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 4)
    x2 = xindex // 512
    x4 = xindex
    tmp0 = (x0).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 64, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tl.load(in_ptr0 + (3584 + 128*x1 + 4608*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp8 = tl.load(in_ptr1 + (x2), tmp6 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp10 = tmp8 + tmp9
    tmp11 = tmp8 < 0
    tmp12 = tl.where(tmp11, tmp10, tmp8)
    tl.device_assert(((0 <= tl.broadcast_to(tmp12, [XBLOCK])) & (tl.broadcast_to(tmp12, [XBLOCK]) < 32768)) | ~(tmp6 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp12, [XBLOCK]) < 32768")
    tmp14 = tl.load(in_ptr2 + (128*tmp12 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp15 = tmp7 * tmp14
    tmp16 = tl.load(in_ptr0 + (3648 + 128*x1 + 4608*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp17 = tl.load(in_ptr2 + (64 + 128*tmp12 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp18 = tmp16 * tmp17
    tmp19 = tmp15 - tmp18
    tmp20 = tl.full(tmp19.shape, 0.0, tmp19.dtype)
    tmp21 = tl.where(tmp6, tmp19, tmp20)
    tmp22 = tmp0 >= tmp5
    tmp23 = tl.full([1], 128, tl.int64)
    tmp24 = tmp0 < tmp23
    tmp25 = tl.load(in_ptr0 + (3648 + 128*x1 + 4608*x2 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp26 = tl.load(in_ptr1 + (x2), tmp22 & xmask, eviction_policy='evict_last', other=0.0)
    tmp27 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp28 = tmp26 + tmp27
    tmp29 = tmp26 < 0
    tmp30 = tl.where(tmp29, tmp28, tmp26)
    tl.device_assert(((0 <= tl.broadcast_to(tmp30, [XBLOCK])) & (tl.broadcast_to(tmp30, [XBLOCK]) < 32768)) | ~(tmp22 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp30, [XBLOCK]) < 32768")
    tmp32 = tl.load(in_ptr2 + (128*tmp30 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp33 = tmp25 * tmp32
    tmp34 = tl.load(in_ptr0 + (3584 + 128*x1 + 4608*x2 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp35 = tl.load(in_ptr2 + (64 + 128*tmp30 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp36 = tmp34 * tmp35
    tmp37 = tmp33 + tmp36
    tmp38 = tl.full(tmp37.shape, 0.0, tmp37.dtype)
    tmp39 = tl.where(tmp22, tmp37, tmp38)
    tmp40 = tl.where(tmp6, tmp21, tmp39)
    tl.store(out_ptr0 + (x4), tmp40, xmask)
''', device_str='cuda')

async_compile.wait(globals())
del async_compile

import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
with torch.cuda._DeviceGuard(0):
    raw_stream0 = get_raw_stream(0)
raw_stream0 = get_raw_stream(0)
arg0_1 = generate_example_value((16384, 28, 128), (3584, 128, 1), 'cuda:0', torch.bfloat16, 0, (16384, 28, 128))
buf2 = generate_example_value((512,), (1,), 'cuda:0', torch.float32, 0, (512,))
with torch.cuda._DeviceGuard(0):
    triton_red_fused_abs_max_view_0.run(arg0_1, buf2, 16384, 512, 114688, stream=raw_stream0)

raw_stream0 = get_raw_stream(0)
buf3 = generate_example_value((), (), 'cuda:0', torch.bfloat16, 0, ())
buf5 = generate_example_value((1,), (1,), 'cuda:0', torch.float32, 0, (1,))
with torch.cuda._DeviceGuard(0):
    triton_per_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_1.run(buf2, buf3, buf5, 1, 512, stream=raw_stream0)
del buf2, buf5

raw_stream0 = get_raw_stream(0)
buf4 = generate_example_value((16384, 3584), (3584, 1), 'cuda:0', torch.float8_e4m3fn, 0, (16384, 3584))
with torch.cuda._DeviceGuard(0):
    triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2.run(arg0_1, buf3, buf4, 58720256, stream=raw_stream0)
del arg0_1, buf3, buf4

raw_stream0 = get_raw_stream(0)
buf0 = generate_example_value((16384, 3584), (3584, 1), 'cuda:0', torch.bfloat16, 0, (16384, 3584))
arg5_1 = generate_example_value((16384, 3584), (3584, 1), 'cuda:0', torch.bfloat16, 0, (16384, 3584))
arg4_1 = generate_example_value((3584,), (1,), 'cuda:0', torch.bfloat16, 0, (3584,))
buf8 = generate_example_value((16384, 1), (1, 16384), 'cuda:0', torch.float32, 0, (16384, 1))
buf10 = generate_example_value((16384, 1), (1, 16384), 'cuda:0', torch.float32, 0, (16384, 1))
with torch.cuda._DeviceGuard(0):
    triton_red_fused_abs_fused_add_rms_norm_max_3.run(buf0, arg5_1, arg4_1, buf8, buf10, 16384, 3584, stream=raw_stream0)

raw_stream0 = get_raw_stream(0)
buf11 = generate_example_value((), (), 'cuda:0', torch.bfloat16, 0, ())
buf13 = generate_example_value((1,), (1,), 'cuda:0', torch.float32, 0, (1,))
with torch.cuda._DeviceGuard(0):
    triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_4.run(buf10, buf11, buf13, 1, 16384, stream=raw_stream0)
del buf10, buf13

raw_stream0 = get_raw_stream(0)
buf12 = generate_example_value((16384, 3584), (3584, 1), 'cuda:0', torch.float8_e4m3fn, 0, (16384, 3584))
with torch.cuda._DeviceGuard(0):
    triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_mul_reciprocal_unsqueeze_5.run(buf0, arg5_1, buf8, arg4_1, buf11, buf12, 58720256, stream=raw_stream0)
del arg4_1, buf8, buf11, buf12

raw_stream0 = get_raw_stream(0)
buf9 = generate_example_value((16384, 37888), (37888, 1), 'cuda:0', torch.bfloat16, 0, (16384, 37888))
buf18 = generate_example_value((2368,), (1,), 'cuda:0', torch.float32, 0, (2368,))
with torch.cuda._DeviceGuard(0):
    triton_red_fused_abs_max_mul_silu_slice_6.run(buf9, buf18, 16384, 2368, 131072, stream=raw_stream0)

raw_stream0 = get_raw_stream(0)
buf19 = generate_example_value((), (), 'cuda:0', torch.bfloat16, 0, ())
buf21 = generate_example_value((1,), (1,), 'cuda:0', torch.float32, 0, (1,))
with torch.cuda._DeviceGuard(0):
    triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_7.run(buf18, buf19, buf21, 1, 2368, stream=raw_stream0)
del buf18, buf21

raw_stream0 = get_raw_stream(0)
buf20 = generate_example_value((16384, 18944), (18944, 1), 'cuda:0', torch.float8_e4m3fn, 0, (16384, 18944))
with torch.cuda._DeviceGuard(0):
    triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_silu_slice_unsqueeze_8.run(buf9, buf19, buf20, 310378496, stream=raw_stream0)
del buf9, buf19, buf20

raw_stream0 = get_raw_stream(0)
buf16 = generate_example_value((16384, 3584), (3584, 1), 'cuda:0', torch.bfloat16, 0, (16384, 3584))
arg10_1 = generate_example_value((3584,), (1,), 'cuda:0', torch.bfloat16, 0, (3584,))
buf24 = generate_example_value((16384, 3584), (3584, 1), 'cuda:0', torch.bfloat16, 0, (16384, 3584))
buf26 = generate_example_value((16384, 3584), (3584, 1), 'cuda:0', torch.bfloat16, 0, (16384, 3584))
buf28 = generate_example_value((16384, 1), (1, 16384), 'cuda:0', torch.float32, 0, (16384, 1))
with torch.cuda._DeviceGuard(0):
    triton_red_fused_abs_fused_add_rms_norm_max_9.run(buf16, buf0, arg5_1, arg10_1, buf24, buf26, buf28, 16384, 3584, stream=raw_stream0)
del buf0, arg5_1, buf16, arg10_1, buf24, buf26, buf28

raw_stream0 = get_raw_stream(0)
raw_stream0 = get_raw_stream(0)
raw_stream0 = get_raw_stream(0)
buf27 = generate_example_value((16384, 4608), (4608, 1), 'cuda:0', torch.bfloat16, 0, (16384, 4608))
arg14_1 = generate_example_value((16384,), (1,), 'cuda:0', torch.int64, 0, (16384,))
arg15_1 = generate_example_value((32768, 128), (128, 1), 'cuda:0', torch.bfloat16, 0, (32768, 128))
buf35 = generate_example_value((16384, 28, 128), (3584, 128, 1), 'cuda:0', torch.bfloat16, 0, (16384, 28, 128))
with torch.cuda._DeviceGuard(0):
    triton_poi_fused_10.run(buf27, arg14_1, arg15_1, buf35, 58720256, stream=raw_stream0)
del buf35

raw_stream0 = get_raw_stream(0)
buf34 = generate_example_value((16384, 4, 128), (512, 128, 1), 'cuda:0', torch.bfloat16, 0, (16384, 4, 128))
with torch.cuda._DeviceGuard(0):
    triton_poi_fused_11.run(buf27, arg14_1, arg15_1, buf34, 8388608, stream=raw_stream0)
del buf27, arg14_1, arg15_1, buf34

"""
# AOT ID: ['1_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /tmp/torchinductor_root/o4/co4mgrmlzjuntxot2pel3sv6dwpa3qiuwbczmntcborlijakgu5s.py
# Topologically Sorted Source Nodes: [view, abs_1, max_1], Original ATen: [aten.view, aten.abs, aten.max]
# Source node to ATen node mapping:
#   abs_1 => abs_1
#   max_1 => max_1
#   view => view
# Graph fragment:
#   %arg0_1 : Tensor "bf16[s72, 28, 128][3584, 128, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %view : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%arg0_1, [-1, 3584]), kwargs = {})
#   %abs_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%view,), kwargs = {})
#   %max_1 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_1,), kwargs = {})
#   return %buf2
triton_red_fused_abs_max_view_0 = async_compile.triton('triton_red_fused_abs_max_view_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 512, 'r0_': 131072},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'ks0': 'i64', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_abs_max_view_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 4096, 'r0_': 117440512}, 'kernel_num_gb': 0.11744256, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_abs_max_view_0(in_ptr0, out_ptr0, ks0, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 512
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp3 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (((r0_1 + 7*ks0*x0) % (3584*ks0))), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl_math.abs(tmp0)
        tmp2 = tl.broadcast_to(tmp1, [XBLOCK, R0_BLOCK])
        tmp4 = triton_helpers.maximum(_tmp3, tmp2)
        _tmp3 = tl.where(r0_mask & xmask, tmp4, _tmp3)
    tmp3 = triton_helpers.max2(_tmp3, 1)[:, None]
    tl.store(out_ptr0 + (x0), tmp3, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/rv/crv4nsvpan3bi4pcidkzxzyrovc423mhopehoxdv34k7cs4rpfef.py
# Topologically Sorted Source Nodes: [view, to_1, abs_1, max_1, unsqueeze, to, truediv, clamp, reciprocal, mul, clamp_1, to_3, cutlass_scaled_mm], Original ATen: [aten.view, aten._to_copy, aten.abs, aten.max, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   abs_1 => abs_1
#   clamp => clamp_min
#   clamp_1 => clamp_max, clamp_min_1
#   cutlass_scaled_mm => cutlass_scaled_mm_default_3
#   max_1 => max_1
#   mul => mul_8
#   reciprocal => reciprocal
#   to => convert_element_type
#   to_1 => convert_element_type_1
#   to_3 => convert_element_type_2
#   truediv => div
#   unsqueeze => unsqueeze
#   view => view
# Graph fragment:
#   %buf2 : Tensor "f32[512][1]cuda:0" = PlaceHolder[target=buf2]
#   %max_1 : Tensor "bf16[][]cuda:0" = PlaceHolder[target=max_1]
#   %view : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%arg0_1, [-1, 3584]), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.float32), kwargs = {})
#   %abs_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%view,), kwargs = {})
#   %max_1 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_1,), kwargs = {})
#   %unsqueeze : Tensor "bf16[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%max_1, -1), kwargs = {})
#   %convert_element_type : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %div : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type, 448.0), kwargs = {})
#   %clamp_min : Tensor "f32[1][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div, 4.359654017857143e-06), kwargs = {})
#   %reciprocal : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min,), kwargs = {})
#   %mul_8 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_1, %reciprocal), kwargs = {})
#   %clamp_min_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_8, -448.0), kwargs = {})
#   %clamp_max : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_1, 448.0), kwargs = {})
#   %convert_element_type_2 : Tensor "f8e4m3fn[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_3 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty, %convert_element_type_2, %arg2_1, %clamp_min, %arg3_1, None), kwargs = {})
#   return %max_1,%buf5
triton_per_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_1 = async_compile.triton('triton_per_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 1, 'r0_': 512},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*fp32', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_per_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 2048}, 'kernel_num_gb': 2.054e-06, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_per_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_1(in_ptr0, out_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 512
    R0_BLOCK: tl.constexpr = 512
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_0 = r0_index
    tmp0 = tl.load(in_ptr0 + (r0_0), None, eviction_policy='evict_first')
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK, R0_BLOCK])
    tmp3 = triton_helpers.max2(tmp1, 1)[:, None].to(tl.float32)
    tmp4 = tmp3.to(tl.float32)
    tmp5 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp6 = tmp4 * tmp5
    tmp7 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
    tmp8 = triton_helpers.maximum(tmp6, tmp7)
    tl.store(out_ptr1 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp8, None)
    tl.store(out_ptr0 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp3, None)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/3a/c3aze2xrwkho426sn2f76dqzbx2xiruort5xz7a5fzy4gaavumow.py
# Topologically Sorted Source Nodes: [view, to_1, unsqueeze, to, truediv, clamp, reciprocal, mul, clamp_1, to_3, cutlass_scaled_mm], Original ATen: [aten.view, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   clamp => clamp_min
#   clamp_1 => clamp_max, clamp_min_1
#   cutlass_scaled_mm => cutlass_scaled_mm_default_3
#   mul => mul_8
#   reciprocal => reciprocal
#   to => convert_element_type
#   to_1 => convert_element_type_1
#   to_3 => convert_element_type_2
#   truediv => div
#   unsqueeze => unsqueeze
#   view => view
# Graph fragment:
#   %arg0_1 : Tensor "bf16[s72, 28, 128][3584, 128, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %max_1 : Tensor "bf16[][]cuda:0" = PlaceHolder[target=max_1]
#   %view : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%arg0_1, [-1, 3584]), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.float32), kwargs = {})
#   %unsqueeze : Tensor "bf16[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%max_1, -1), kwargs = {})
#   %convert_element_type : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %div : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type, 448.0), kwargs = {})
#   %clamp_min : Tensor "f32[1][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div, 4.359654017857143e-06), kwargs = {})
#   %reciprocal : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min,), kwargs = {})
#   %mul_8 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_1, %reciprocal), kwargs = {})
#   %clamp_min_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_8, -448.0), kwargs = {})
#   %clamp_max : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_1, 448.0), kwargs = {})
#   %convert_element_type_2 : Tensor "f8e4m3fn[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_3 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty, %convert_element_type_2, %arg2_1, %clamp_min, %arg3_1, None), kwargs = {})
#   return %buf4
triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2 = async_compile.triton('triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 67108864}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*fp8e4nv', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 234881024}, 'kernel_num_gb': 0.17616077, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=2
)
@triton.jit
def triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (0)).to(tl.float32)
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK])
    tmp1 = tmp0.to(tl.float32)
    tmp4 = tmp3.to(tl.float32)
    tmp5 = tl.full([1], 0.002232142857142857, tl.float32)
    tmp6 = tmp4 * tmp5
    tmp7 = tl.full([1], 4.359654017857143e-06, tl.float32)
    tmp8 = triton_helpers.maximum(tmp6, tmp7)
    tmp9 = tl.full([1], 1.0, tl.float32)
    tmp10 = (tmp9 / tmp8)
    tmp11 = tmp1 * tmp10
    tmp12 = tl.full([1], -448.0, tl.float32)
    tmp13 = triton_helpers.maximum(tmp11, tmp12)
    tmp14 = tl.full([1], 448.0, tl.float32)
    tmp15 = triton_helpers.minimum(tmp13, tmp14)
    tmp16 = tmp15.to(tl.float8e4nv)
    tl.store(out_ptr0 + (x0), tmp16, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/gu/cgu6umxyqv26q5ope4p7bcd32jyqwsx7hxxxip2qecmytyim25c7.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, abs_2, max_2], Original ATen: [vllm_ir.fused_add_rms_norm, aten.abs, aten.max]
# Source node to ATen node mapping:
#   abs_2 => abs_2
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, add_tensor_3, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_7, mean_dim_1, mul_tensor_2, mul_tensor_3, pow_tensor_scalar_1, rsqrt_default_1
#   max_2 => max_2
# Graph fragment:
#   %buf7 : Tensor  = PlaceHolder[target=buf7]
#   %arg5_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %buf8 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf8]
#   %arg4_1 : Tensor "bf16[3584][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %convert_element_type_default_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %pow_tensor_scalar_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_2, 2), kwargs = {})
#   %mean_dim_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_1, [-1], True), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_1, 1e-06), kwargs = {})
#   %rsqrt_default_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_2, %rsqrt_default_1), kwargs = {})
#   %convert_element_type_default_7 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_2, torch.bfloat16), kwargs = {})
#   %mul_tensor_3 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_7, %arg4_1), kwargs = {})
#   %abs_2 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_tensor_3,), kwargs = {})
#   %max_2 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_2,), kwargs = {})
#   return %buf8,%buf10
triton_red_fused_abs_fused_add_rms_norm_max_3 = async_compile.triton('triton_red_fused_abs_fused_add_rms_norm_max_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_abs_fused_add_rms_norm_max_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 2, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 262144, 'r0_': 117447680}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.117578752, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_abs_fused_add_rms_norm_max_3(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 3584
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp1 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    tl.store(out_ptr0 + (x0), tmp7, xmask)
    _tmp25 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp21 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tmp9.to(tl.float32)
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tmp10 + tmp12
        tmp14 = tl.full([1, 1], 3584.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1, 1], 1e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp20 = tmp19.to(tl.float32)
        tmp22 = tmp20 * tmp21
        tmp23 = tl_math.abs(tmp22)
        tmp24 = tl.broadcast_to(tmp23, [XBLOCK, R0_BLOCK])
        tmp26 = triton_helpers.maximum(_tmp25, tmp24)
        _tmp25 = tl.where(r0_mask & xmask, tmp26, _tmp25)
    tmp25 = triton_helpers.max2(_tmp25, 1)[:, None]
    tl.store(out_ptr1 + (x0), tmp25, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/k5/ck5q6wahumf22tbxxw3ha7yc6w6p4h3etbn6zmbmhzic5fxprzbi.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, to_5, abs_2, max_2, unsqueeze_1, to_4, truediv_1, clamp_2, reciprocal_1, mul_1, clamp_3, to_7, cutlass_scaled_mm_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten._to_copy, aten.abs, aten.max, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   abs_2 => abs_2
#   clamp_2 => clamp_min_2
#   clamp_3 => clamp_max_1, clamp_min_3
#   cutlass_scaled_mm_1 => cutlass_scaled_mm_default_2
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, add_tensor_3, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_7, mean_dim_1, mul_tensor_2, mul_tensor_3, pow_tensor_scalar_1, rsqrt_default_1
#   max_2 => max_2
#   mul_1 => mul_31
#   reciprocal_1 => reciprocal_1
#   to_4 => convert_element_type_3
#   to_5 => convert_element_type_4
#   to_7 => convert_element_type_5
#   truediv_1 => div_1
#   unsqueeze_1 => unsqueeze_1
# Graph fragment:
#   %buf10 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf10]
#   %max_2 : Tensor "bf16[][]cuda:0" = PlaceHolder[target=max_2]
#   %convert_element_type_default_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %pow_tensor_scalar_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_2, 2), kwargs = {})
#   %mean_dim_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_1, [-1], True), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_1, 1e-06), kwargs = {})
#   %rsqrt_default_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_2, %rsqrt_default_1), kwargs = {})
#   %convert_element_type_default_7 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_2, torch.bfloat16), kwargs = {})
#   %mul_tensor_3 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_7, %arg4_1), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_3, torch.float32), kwargs = {})
#   %abs_2 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_tensor_3,), kwargs = {})
#   %max_2 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_2,), kwargs = {})
#   %unsqueeze_1 : Tensor "bf16[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%max_2, -1), kwargs = {})
#   %convert_element_type_3 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_1, torch.float32), kwargs = {})
#   %div_1 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_3, 448.0), kwargs = {})
#   %clamp_min_2 : Tensor "f32[1][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div_1, 4.359654017857143e-06), kwargs = {})
#   %reciprocal_1 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min_2,), kwargs = {})
#   %mul_31 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_4, %reciprocal_1), kwargs = {})
#   %clamp_min_3 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_31, -448.0), kwargs = {})
#   %clamp_max_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_3, 448.0), kwargs = {})
#   %convert_element_type_5 : Tensor "f8e4m3fn[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max_1, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_2 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty_1, %convert_element_type_5, %arg6_1, %clamp_min_2, %arg7_1, None), kwargs = {})
#   return %max_2,%buf13
triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_4 = async_compile.triton('triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 16384},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*fp32', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 65536}, 'kernel_num_gb': 6.5542e-05, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_4(in_ptr0, out_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    _tmp2 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.broadcast_to(tmp0, [XBLOCK, R0_BLOCK])
        tmp3 = triton_helpers.maximum(_tmp2, tmp1)
        _tmp2 = tl.where(r0_mask, tmp3, _tmp2)
    tmp2 = triton_helpers.max2(_tmp2, 1)[:, None]
    tl.store(out_ptr0 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp2, None)
    tmp4 = tmp2.to(tl.float32)
    tmp5 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp6 = tmp4 * tmp5
    tmp7 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
    tmp8 = triton_helpers.maximum(tmp6, tmp7)
    tl.store(out_ptr1 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp8, None)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/xw/cxwqaiqfum5cnelxy7yg6uol3dxgg27tjnlvknyxipfsdtn4tm6i.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, to_5, unsqueeze_1, to_4, truediv_1, clamp_2, reciprocal_1, mul_1, clamp_3, to_7, cutlass_scaled_mm_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   clamp_2 => clamp_min_2
#   clamp_3 => clamp_max_1, clamp_min_3
#   cutlass_scaled_mm_1 => cutlass_scaled_mm_default_2
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, add_tensor_3, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_7, mean_dim_1, mul_tensor_2, mul_tensor_3, pow_tensor_scalar_1, rsqrt_default_1
#   mul_1 => mul_31
#   reciprocal_1 => reciprocal_1
#   to_4 => convert_element_type_3
#   to_5 => convert_element_type_4
#   to_7 => convert_element_type_5
#   truediv_1 => div_1
#   unsqueeze_1 => unsqueeze_1
# Graph fragment:
#   %buf7 : Tensor  = PlaceHolder[target=buf7]
#   %arg5_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %buf8 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf8]
#   %arg4_1 : Tensor "bf16[3584][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %max_2 : Tensor "bf16[][]cuda:0" = PlaceHolder[target=max_2]
#   %convert_element_type_default_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %pow_tensor_scalar_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_2, 2), kwargs = {})
#   %mean_dim_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_1, [-1], True), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_1, 1e-06), kwargs = {})
#   %rsqrt_default_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_2, %rsqrt_default_1), kwargs = {})
#   %convert_element_type_default_7 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_2, torch.bfloat16), kwargs = {})
#   %mul_tensor_3 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_7, %arg4_1), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_3, torch.float32), kwargs = {})
#   %unsqueeze_1 : Tensor "bf16[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%max_2, -1), kwargs = {})
#   %convert_element_type_3 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_1, torch.float32), kwargs = {})
#   %div_1 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_3, 448.0), kwargs = {})
#   %clamp_min_2 : Tensor "f32[1][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div_1, 4.359654017857143e-06), kwargs = {})
#   %reciprocal_1 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min_2,), kwargs = {})
#   %mul_31 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_4, %reciprocal_1), kwargs = {})
#   %clamp_min_3 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_31, -448.0), kwargs = {})
#   %clamp_max_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_3, 448.0), kwargs = {})
#   %convert_element_type_5 : Tensor "f8e4m3fn[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max_1, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_2 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty_1, %convert_element_type_5, %arg6_1, %clamp_min_2, %arg7_1, None), kwargs = {})
#   return %buf12
triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_mul_reciprocal_unsqueeze_5 = async_compile.triton('triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_mul_reciprocal_unsqueeze_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 67108864}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr0': '*fp8e4nv', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_mul_reciprocal_unsqueeze_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 234953728}, 'kernel_num_gb': 0.176233474, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=2
)
@triton.jit
def triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_mul_reciprocal_unsqueeze_5(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x1 = xindex // 3584
    x0 = (xindex % 3584)
    tmp0 = tl.load(in_ptr0 + (x2), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x2), xmask).to(tl.float32)
    tmp5 = tl.load(in_ptr2 + (x1), xmask, eviction_policy='evict_last')
    tmp13 = tl.load(in_ptr3 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp16 = tl.load(in_ptr4 + (0)).to(tl.float32)
    tmp17 = tl.broadcast_to(tmp16, [XBLOCK])
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 + tmp3
    tmp6 = tl.full([1], 3584.0, tl.float32)
    tmp7 = (tmp5 / tmp6)
    tmp8 = tl.full([1], 1e-06, tl.float32)
    tmp9 = tmp7 + tmp8
    tmp10 = libdevice.rsqrt(tmp9)
    tmp11 = tmp4 * tmp10
    tmp12 = tmp11.to(tl.float32)
    tmp14 = tmp12 * tmp13
    tmp15 = tmp14.to(tl.float32)
    tmp18 = tmp17.to(tl.float32)
    tmp19 = tl.full([1], 0.002232142857142857, tl.float32)
    tmp20 = tmp18 * tmp19
    tmp21 = tl.full([1], 4.359654017857143e-06, tl.float32)
    tmp22 = triton_helpers.maximum(tmp20, tmp21)
    tmp23 = tl.full([1], 1.0, tl.float32)
    tmp24 = (tmp23 / tmp22)
    tmp25 = tmp15 * tmp24
    tmp26 = tl.full([1], -448.0, tl.float32)
    tmp27 = triton_helpers.maximum(tmp25, tmp26)
    tmp28 = tl.full([1], 448.0, tl.float32)
    tmp29 = triton_helpers.minimum(tmp27, tmp28)
    tmp30 = tmp29.to(tl.float8e4nv)
    tl.store(out_ptr0 + (x2), tmp30, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/dq/cdqcllcu3pxeapsaylitflml7seepocmmvzsqa2il7c2a6e42dbx.py
# Topologically Sorted Source Nodes: [silu, mul_2, abs_3, max_3], Original ATen: [aten.slice, aten.silu, aten.mul, aten.abs, aten.max]
# Source node to ATen node mapping:
#   abs_3 => abs_3
#   max_3 => max_3
#   mul_2 => mul_50, slice_4
#   silu => add_72, convert_element_type_6, convert_element_type_7, div_2, exp, neg, slice_2
# Graph fragment:
#   %buf15 : Tensor  = PlaceHolder[target=buf15]
#   %slice_2 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 0, 18944), kwargs = {})
#   %convert_element_type_6 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_2, torch.float32), kwargs = {})
#   %neg : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_6,), kwargs = {})
#   %exp : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_72 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_6, %add_72), kwargs = {})
#   %convert_element_type_7 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_2, torch.bfloat16), kwargs = {})
#   %slice_4 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 18944, 9223372036854775807), kwargs = {})
#   %mul_50 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %slice_4), kwargs = {})
#   %abs_3 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_50,), kwargs = {})
#   %max_3 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_3,), kwargs = {})
#   return %buf18
triton_red_fused_abs_max_mul_silu_slice_6 = async_compile.triton('triton_red_fused_abs_max_mul_silu_slice_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 4096, 'r0_': 131072},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'ks0': 'i64', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_abs_max_mul_silu_slice_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 18944, 'r0_': 0}, 'kernel_num_gb': 9.472e-06, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_abs_max_mul_silu_slice_6(in_ptr0, out_ptr0, ks0, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 2368
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp12 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (37888*((((r0_1 + 8*ks0*x0) // 18944) % ks0)) + (((r0_1 + 8*ks0*x0) % 18944))), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp8 = tl.load(in_ptr0 + (18944 + 37888*((((r0_1 + 8*ks0*x0) // 18944) % ks0)) + (((r0_1 + 8*ks0*x0) % 18944))), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = -tmp1
        tmp3 = libdevice.exp(tmp2)
        tmp4 = tl.full([1, 1], 1.0, tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = (tmp1 / tmp5)
        tmp7 = tmp6.to(tl.float32)
        tmp9 = tmp7 * tmp8
        tmp10 = tl_math.abs(tmp9)
        tmp11 = tl.broadcast_to(tmp10, [XBLOCK, R0_BLOCK])
        tmp13 = triton_helpers.maximum(_tmp12, tmp11)
        _tmp12 = tl.where(r0_mask & xmask, tmp13, _tmp12)
    tmp12 = triton_helpers.max2(_tmp12, 1)[:, None]
    tl.store(out_ptr0 + (x0), tmp12, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/77/c77xjpeqo37eox3cbbc42lzvk3mldqq5ktnpjnhm3k5qa3ntnfvt.py
# Topologically Sorted Source Nodes: [silu, mul_2, to_9, abs_3, max_3, unsqueeze_2, to_8, truediv_2, clamp_4, reciprocal_2, mul_3, clamp_5, to_11, cutlass_scaled_mm_2], Original ATen: [aten.slice, aten.silu, aten.mul, aten._to_copy, aten.abs, aten.max, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   abs_3 => abs_3
#   clamp_4 => clamp_min_4
#   clamp_5 => clamp_max_2, clamp_min_5
#   cutlass_scaled_mm_2 => cutlass_scaled_mm_default_1
#   max_3 => max_3
#   mul_2 => mul_50, slice_4
#   mul_3 => mul_59
#   reciprocal_2 => reciprocal_2
#   silu => add_72, convert_element_type_6, convert_element_type_7, div_2, exp, neg, slice_2
#   to_11 => convert_element_type_10
#   to_8 => convert_element_type_8
#   to_9 => convert_element_type_9
#   truediv_2 => div_3
#   unsqueeze_2 => unsqueeze_2
# Graph fragment:
#   %buf18 : Tensor "f32[2368][1]cuda:0" = PlaceHolder[target=buf18]
#   %max_3 : Tensor "bf16[][]cuda:0" = PlaceHolder[target=max_3]
#   %slice_2 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 0, 18944), kwargs = {})
#   %convert_element_type_6 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_2, torch.float32), kwargs = {})
#   %neg : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_6,), kwargs = {})
#   %exp : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_72 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_6, %add_72), kwargs = {})
#   %convert_element_type_7 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_2, torch.bfloat16), kwargs = {})
#   %slice_4 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 18944, 9223372036854775807), kwargs = {})
#   %mul_50 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %slice_4), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_50, torch.float32), kwargs = {})
#   %abs_3 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_50,), kwargs = {})
#   %max_3 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_3,), kwargs = {})
#   %unsqueeze_2 : Tensor "bf16[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%max_3, -1), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %div_3 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_8, 448.0), kwargs = {})
#   %clamp_min_4 : Tensor "f32[1][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div_3, 4.359654017857143e-06), kwargs = {})
#   %reciprocal_2 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min_4,), kwargs = {})
#   %mul_59 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_9, %reciprocal_2), kwargs = {})
#   %clamp_min_5 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_59, -448.0), kwargs = {})
#   %clamp_max_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_5, 448.0), kwargs = {})
#   %convert_element_type_10 : Tensor "f8e4m3fn[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max_2, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_1 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty_2, %convert_element_type_10, %arg8_1, %clamp_min_4, %arg9_1, None), kwargs = {})
#   return %max_3,%buf21
triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_7 = async_compile.triton('triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 1, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*bf16', 'out_ptr1': '*fp32', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'r0_': 9472}, 'kernel_num_gb': 9.478e-06, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_7(in_ptr0, out_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 2368
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    _tmp2 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_0 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_0), r0_mask, eviction_policy='evict_first', other=0.0)
        tmp1 = tl.broadcast_to(tmp0, [XBLOCK, R0_BLOCK])
        tmp3 = triton_helpers.maximum(_tmp2, tmp1)
        _tmp2 = tl.where(r0_mask, tmp3, _tmp2)
    tmp2 = triton_helpers.max2(_tmp2, 1)[:, None]
    tl.store(out_ptr0 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp2, None)
    tmp4 = tmp2.to(tl.float32)
    tmp5 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp6 = tmp4 * tmp5
    tmp7 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
    tmp8 = triton_helpers.maximum(tmp6, tmp7)
    tl.store(out_ptr1 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp8, None)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/xr/cxr3alzfc6a77cth4z4elak65zlkb2cxflrqpechxsc6ymcum2lt.py
# Topologically Sorted Source Nodes: [silu, mul_2, to_9, unsqueeze_2, to_8, truediv_2, clamp_4, reciprocal_2, mul_3, clamp_5, to_11, cutlass_scaled_mm_2], Original ATen: [aten.slice, aten.silu, aten.mul, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   clamp_4 => clamp_min_4
#   clamp_5 => clamp_max_2, clamp_min_5
#   cutlass_scaled_mm_2 => cutlass_scaled_mm_default_1
#   mul_2 => mul_50, slice_4
#   mul_3 => mul_59
#   reciprocal_2 => reciprocal_2
#   silu => add_72, convert_element_type_6, convert_element_type_7, div_2, exp, neg, slice_2
#   to_11 => convert_element_type_10
#   to_8 => convert_element_type_8
#   to_9 => convert_element_type_9
#   truediv_2 => div_3
#   unsqueeze_2 => unsqueeze_2
# Graph fragment:
#   %buf15 : Tensor  = PlaceHolder[target=buf15]
#   %max_3 : Tensor "bf16[][]cuda:0" = PlaceHolder[target=max_3]
#   %slice_2 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 0, 18944), kwargs = {})
#   %convert_element_type_6 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_2, torch.float32), kwargs = {})
#   %neg : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_6,), kwargs = {})
#   %exp : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_72 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_6, %add_72), kwargs = {})
#   %convert_element_type_7 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_2, torch.bfloat16), kwargs = {})
#   %slice_4 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 18944, 9223372036854775807), kwargs = {})
#   %mul_50 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %slice_4), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_50, torch.float32), kwargs = {})
#   %unsqueeze_2 : Tensor "bf16[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%max_3, -1), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %div_3 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_8, 448.0), kwargs = {})
#   %clamp_min_4 : Tensor "f32[1][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div_3, 4.359654017857143e-06), kwargs = {})
#   %reciprocal_2 : Tensor "f32[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min_4,), kwargs = {})
#   %mul_59 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_9, %reciprocal_2), kwargs = {})
#   %clamp_min_5 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_59, -448.0), kwargs = {})
#   %clamp_max_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_5, 448.0), kwargs = {})
#   %convert_element_type_10 : Tensor "f8e4m3fn[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max_2, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_1 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty_2, %convert_element_type_10, %arg8_1, %clamp_min_4, %arg9_1, None), kwargs = {})
#   return %buf20
triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_silu_slice_unsqueeze_8 = async_compile.triton('triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_silu_slice_unsqueeze_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 536870912}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*fp8e4nv', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_silu_slice_unsqueeze_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 620756992}, 'kernel_num_gb': 0.310378498, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=2
)
@triton.jit
def triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_silu_slice_unsqueeze_8(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 18944)
    x1 = xindex // 18944
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 37888*x1), xmask).to(tl.float32)
    tmp8 = tl.load(in_ptr0 + (18944 + x0 + 37888*x1), xmask).to(tl.float32)
    tmp11 = tl.load(in_ptr1 + (0)).to(tl.float32)
    tmp12 = tl.broadcast_to(tmp11, [XBLOCK])
    tmp1 = tmp0.to(tl.float32)
    tmp2 = -tmp1
    tmp3 = libdevice.exp(tmp2)
    tmp4 = tl.full([1], 1.0, tl.float32)
    tmp5 = tmp3 + tmp4
    tmp6 = (tmp1 / tmp5)
    tmp7 = tmp6.to(tl.float32)
    tmp9 = tmp7 * tmp8
    tmp10 = tmp9.to(tl.float32)
    tmp13 = tmp12.to(tl.float32)
    tmp14 = tl.full([1], 0.002232142857142857, tl.float32)
    tmp15 = tmp13 * tmp14
    tmp16 = tl.full([1], 4.359654017857143e-06, tl.float32)
    tmp17 = triton_helpers.maximum(tmp15, tmp16)
    tmp18 = (tmp4 / tmp17)
    tmp19 = tmp10 * tmp18
    tmp20 = tl.full([1], -448.0, tl.float32)
    tmp21 = triton_helpers.maximum(tmp19, tmp20)
    tmp22 = tl.full([1], 448.0, tl.float32)
    tmp23 = triton_helpers.minimum(tmp21, tmp22)
    tmp24 = tmp23.to(tl.float8e4nv)
    tl.store(out_ptr0 + (x2), tmp24, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/t6/ct643ivnmz6chgkiu345u4glp3fk7xojxi5gxdoyl4h7hzyeb52k.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, fused_add_rms_norm_maybe_inplace_1, abs_4, max_4], Original ATen: [vllm_ir.fused_add_rms_norm, aten.abs, aten.max]
# Source node to ATen node mapping:
#   abs_4 => abs_4
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_6
#   fused_add_rms_norm_maybe_inplace_1 => add_tensor, add_tensor_1, convert_element_type_default, convert_element_type_default_1, convert_element_type_default_2, convert_element_type_default_3, mean_dim, mul_tensor, mul_tensor_1, pow_tensor_scalar, rsqrt_default
#   max_4 => max_4
# Graph fragment:
#   %buf23 : Tensor  = PlaceHolder[target=buf23]
#   %buf7 : Tensor  = PlaceHolder[target=buf7]
#   %arg5_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %buf25 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf25]
#   %arg10_1 : Tensor "bf16[3584][1]cuda:0" = PlaceHolder[target=arg10_1]
#   %mul_tensor_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0" = PlaceHolder[target=mul_tensor_1]
#   %convert_element_type_default_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %convert_element_type_default_6 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor_2, torch.bfloat16), kwargs = {})
#   %convert_element_type_default : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty_2, torch.float32), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%convert_element_type_default_6, torch.float32), kwargs = {})
#   %add_tensor : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default, %convert_element_type_default_1), kwargs = {})
#   %convert_element_type_default_2 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor, torch.bfloat16), kwargs = {})
#   %pow_tensor_scalar : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor, 2), kwargs = {})
#   %mean_dim : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar, [-1], True), kwargs = {})
#   %add_tensor_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim, 1e-06), kwargs = {})
#   %rsqrt_default : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_1,), kwargs = {})
#   %mul_tensor : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor, %rsqrt_default), kwargs = {})
#   %convert_element_type_default_3 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor, torch.bfloat16), kwargs = {})
#   %mul_tensor_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_3, %arg10_1), kwargs = {})
#   %abs_4 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_tensor_1,), kwargs = {})
#   %max_4 : Tensor "bf16[][]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.max.default](args = (%abs_4,), kwargs = {})
#   return %buf25,%convert_element_type_default_2,%mul_tensor_1,%buf28
triton_red_fused_abs_fused_add_rms_norm_max_9 = async_compile.triton('triton_red_fused_abs_fused_add_rms_norm_max_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_abs_fused_add_rms_norm_max_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 3, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 131072, 'r0_': 587209728}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.35239424, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_abs_fused_add_rms_norm_max_9(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, out_ptr2, out_ptr3, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 3584
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp12 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tl.load(in_ptr2 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp3 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp1 + tmp8
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [XBLOCK, R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask & xmask, tmp13, _tmp12)
        tmp14 = tmp9.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 3584*x0), tmp14, r0_mask & xmask)
    tmp12 = tl.sum(_tmp12, 1)[:, None]
    _tmp36 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp15 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp17 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp19 = tl.load(in_ptr2 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp32 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp16 = tmp15.to(tl.float32)
        tmp18 = tmp17.to(tl.float32)
        tmp20 = tmp19.to(tl.float32)
        tmp21 = tmp18 + tmp20
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp16 + tmp23
        tmp25 = tl.full([1, 1], 3584.0, tl.float32)
        tmp26 = (tmp12 / tmp25)
        tmp27 = tl.full([1, 1], 1e-06, tl.float32)
        tmp28 = tmp26 + tmp27
        tmp29 = libdevice.rsqrt(tmp28)
        tmp30 = tmp24 * tmp29
        tmp31 = tmp30.to(tl.float32)
        tmp33 = tmp31 * tmp32
        tmp34 = tl_math.abs(tmp33)
        tmp35 = tl.broadcast_to(tmp34, [XBLOCK, R0_BLOCK])
        tmp37 = triton_helpers.maximum(_tmp36, tmp35)
        _tmp36 = tl.where(r0_mask & xmask, tmp37, _tmp36)
        tl.store(out_ptr2 + (r0_1 + 3584*x0), tmp33, r0_mask & xmask)
    tmp36 = triton_helpers.max2(_tmp36, 1)[:, None]
    tl.store(out_ptr3 + (x0), tmp36, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/t7/ct7xmyznacyon5l62c4gcloxpwrp3kbaq6vzremumetolbme7yp3.py
# Unsorted Source Nodes: [], Original ATen: []
# Source node to ATen node mapping:
triton_poi_fused_10 = async_compile.triton('triton_poi_fused_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 67108864}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*i64', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_10', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'kernel_num_gb': 0.125960192, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_10(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 28)
    x2 = xindex // 3584
    x4 = xindex
    tmp0 = (x0).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 64, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tl.load(in_ptr0 + (128*x1 + 4608*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp8 = tl.load(in_ptr1 + (x2), tmp6 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp10 = tmp8 + tmp9
    tmp11 = tmp8 < 0
    tmp12 = tl.where(tmp11, tmp10, tmp8)
    tl.device_assert(((0 <= tl.broadcast_to(tmp12, [XBLOCK])) & (tl.broadcast_to(tmp12, [XBLOCK]) < 32768)) | ~(tmp6 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp12, [XBLOCK]) < 32768")
    tmp14 = tl.load(in_ptr2 + (128*tmp12 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp15 = tmp7 * tmp14
    tmp16 = tl.load(in_ptr0 + (64 + 128*x1 + 4608*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp17 = tl.load(in_ptr2 + (64 + 128*tmp12 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp18 = tmp16 * tmp17
    tmp19 = tmp15 - tmp18
    tmp20 = tl.full(tmp19.shape, 0.0, tmp19.dtype)
    tmp21 = tl.where(tmp6, tmp19, tmp20)
    tmp22 = tmp0 >= tmp5
    tmp23 = tl.full([1], 128, tl.int64)
    tmp24 = tmp0 < tmp23
    tmp25 = tl.load(in_ptr0 + (64 + 128*x1 + 4608*x2 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp26 = tl.load(in_ptr1 + (x2), tmp22 & xmask, eviction_policy='evict_last', other=0.0)
    tmp27 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp28 = tmp26 + tmp27
    tmp29 = tmp26 < 0
    tmp30 = tl.where(tmp29, tmp28, tmp26)
    tl.device_assert(((0 <= tl.broadcast_to(tmp30, [XBLOCK])) & (tl.broadcast_to(tmp30, [XBLOCK]) < 32768)) | ~(tmp22 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp30, [XBLOCK]) < 32768")
    tmp32 = tl.load(in_ptr2 + (128*tmp30 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp33 = tmp25 * tmp32
    tmp34 = tl.load(in_ptr0 + (128*x1 + 4608*x2 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp35 = tl.load(in_ptr2 + (64 + 128*tmp30 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp36 = tmp34 * tmp35
    tmp37 = tmp33 + tmp36
    tmp38 = tl.full(tmp37.shape, 0.0, tmp37.dtype)
    tmp39 = tl.where(tmp22, tmp37, tmp38)
    tmp40 = tl.where(tmp6, tmp21, tmp39)
    tl.store(out_ptr0 + (x4), tmp40, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/sy/csybsiuhrrrreq74metiuazdakmwnrtst6kgp4mq6hqa5ok4s4h4.py
# Unsorted Source Nodes: [], Original ATen: []
# Source node to ATen node mapping:
triton_poi_fused_11 = async_compile.triton('triton_poi_fused_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8388608}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*i64', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_11', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'kernel_num_gb': 0.025296896, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_11(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 4)
    x2 = xindex // 512
    x4 = xindex
    tmp0 = (x0).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 64, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tl.load(in_ptr0 + (3584 + 128*x1 + 4608*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp8 = tl.load(in_ptr1 + (x2), tmp6 & xmask, eviction_policy='evict_last', other=0.0)
    tmp9 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp10 = tmp8 + tmp9
    tmp11 = tmp8 < 0
    tmp12 = tl.where(tmp11, tmp10, tmp8)
    tl.device_assert(((0 <= tl.broadcast_to(tmp12, [XBLOCK])) & (tl.broadcast_to(tmp12, [XBLOCK]) < 32768)) | ~(tmp6 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp12, [XBLOCK]) < 32768")
    tmp14 = tl.load(in_ptr2 + (128*tmp12 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp15 = tmp7 * tmp14
    tmp16 = tl.load(in_ptr0 + (3648 + 128*x1 + 4608*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp17 = tl.load(in_ptr2 + (64 + 128*tmp12 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp18 = tmp16 * tmp17
    tmp19 = tmp15 - tmp18
    tmp20 = tl.full(tmp19.shape, 0.0, tmp19.dtype)
    tmp21 = tl.where(tmp6, tmp19, tmp20)
    tmp22 = tmp0 >= tmp5
    tmp23 = tl.full([1], 128, tl.int64)
    tmp24 = tmp0 < tmp23
    tmp25 = tl.load(in_ptr0 + (3648 + 128*x1 + 4608*x2 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp26 = tl.load(in_ptr1 + (x2), tmp22 & xmask, eviction_policy='evict_last', other=0.0)
    tmp27 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp28 = tmp26 + tmp27
    tmp29 = tmp26 < 0
    tmp30 = tl.where(tmp29, tmp28, tmp26)
    tl.device_assert(((0 <= tl.broadcast_to(tmp30, [XBLOCK])) & (tl.broadcast_to(tmp30, [XBLOCK]) < 32768)) | ~(tmp22 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp30, [XBLOCK]) < 32768")
    tmp32 = tl.load(in_ptr2 + (128*tmp30 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp33 = tmp25 * tmp32
    tmp34 = tl.load(in_ptr0 + (3584 + 128*x1 + 4608*x2 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp35 = tl.load(in_ptr2 + (64 + 128*tmp30 + ((-64) + x0)), tmp22 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp36 = tmp34 * tmp35
    tmp37 = tmp33 + tmp36
    tmp38 = tl.full(tmp37.shape, 0.0, tmp37.dtype)
    tmp39 = tl.where(tmp22, tmp37, tmp38)
    tmp40 = tl.where(tmp6, tmp21, tmp39)
    tl.store(out_ptr0 + (x4), tmp40, xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1 = args
        args.clear()
        s72 = arg1_1
        s80 = s72
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            buf0 = empty_strided_cuda((s72, 3584), (3584, 1), torch.bfloat16)
            assert_size_stride(arg0_1, (s72, 28, 128), (3584, 128, 1), 'input')
            arg0_1 = copy_if_misaligned(arg0_1)
            buf2 = empty_strided_cuda((512, ), (1, ), torch.float32)
            # Topologically Sorted Source Nodes: [view, abs_1, max_1], Original ATen: [aten.view, aten.abs, aten.max]
            triton_red_fused_abs_max_view_0_r0_numel = 7*s72
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_abs_max_view_0.run(arg0_1, buf2, s72, 512, triton_red_fused_abs_max_view_0_r0_numel, stream=raw_stream0)
            buf3 = empty_strided_cuda((), (), torch.bfloat16)
            buf5 = empty_strided_cuda((1, ), (1, ), torch.float32)
            # Topologically Sorted Source Nodes: [view, to_1, abs_1, max_1, unsqueeze, to, truediv, clamp, reciprocal, mul, clamp_1, to_3, cutlass_scaled_mm], Original ATen: [aten.view, aten._to_copy, aten.abs, aten.max, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
            raw_stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_1.run(buf2, buf3, buf5, 1, 512, stream=raw_stream0)
            del buf2
            buf4 = empty_strided_cuda((s72, 3584), (3584, 1), torch.float8_e4m3fn)
            # Topologically Sorted Source Nodes: [view, to_1, unsqueeze, to, truediv, clamp, reciprocal, mul, clamp_1, to_3, cutlass_scaled_mm], Original ATen: [aten.view, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
            triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2_xnumel = 3584*s72
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2.run(arg0_1, buf3, buf4, triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del arg0_1
            assert_size_stride(arg2_1, (3584, 3584), (1, 3584), 'input')
            assert_size_stride(arg3_1, (1, ), (1, ), 'input')
            arg2_1 = copy_if_misaligned(arg2_1)
            arg3_1 = copy_if_misaligned(arg3_1)
            # Topologically Sorted Source Nodes: [view, to_1, unsqueeze, to, truediv, clamp, reciprocal, mul, clamp_1, to_3, cutlass_scaled_mm], Original ATen: [aten.view, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
            torch.ops._C.cutlass_scaled_mm.default(buf0, buf4, arg2_1, buf5, arg3_1, None)
            del arg2_1
            del arg3_1
            assert_size_stride(arg5_1, (s72, 3584), (3584, 1), 'input')
            assert_size_stride(arg4_1, (3584, ), (1, ), 'input')
            arg5_1 = copy_if_misaligned(arg5_1)
            arg4_1 = copy_if_misaligned(arg4_1)
            buf8 = empty_strided_cuda((s72, 1), (1, s72), torch.float32)
            buf10 = empty_strided_cuda((s72, 1), (1, s72), torch.float32)
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, abs_2, max_2], Original ATen: [vllm_ir.fused_add_rms_norm, aten.abs, aten.max]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_abs_fused_add_rms_norm_max_3.run(buf0, arg5_1, arg4_1, buf8, buf10, s72, 3584, stream=raw_stream0)
            buf9 = empty_strided_cuda((s72, 37888), (37888, 1), torch.bfloat16)
            buf11 = buf3; del buf3  # reuse
            buf13 = buf5; del buf5  # reuse
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, to_5, abs_2, max_2, unsqueeze_1, to_4, truediv_1, clamp_2, reciprocal_1, mul_1, clamp_3, to_7, cutlass_scaled_mm_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten._to_copy, aten.abs, aten.max, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_4.run(buf10, buf11, buf13, 1, s72, stream=raw_stream0)
            del buf10
            buf12 = buf4; del buf4  # reuse
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, to_5, unsqueeze_1, to_4, truediv_1, clamp_2, reciprocal_1, mul_1, clamp_3, to_7, cutlass_scaled_mm_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
            triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_mul_reciprocal_unsqueeze_5_xnumel = 3584*s72
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_mul_reciprocal_unsqueeze_5.run(buf0, arg5_1, buf8, arg4_1, buf11, buf12, triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_mul_reciprocal_unsqueeze_5_xnumel, stream=raw_stream0)
            del arg4_1
            del buf8
            assert_size_stride(arg6_1, (3584, 37888), (1, 3584), 'input')
            assert_size_stride(arg7_1, (1, ), (1, ), 'input')
            arg6_1 = copy_if_misaligned(arg6_1)
            arg7_1 = copy_if_misaligned(arg7_1)
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, to_5, unsqueeze_1, to_4, truediv_1, clamp_2, reciprocal_1, mul_1, clamp_3, to_7, cutlass_scaled_mm_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
            torch.ops._C.cutlass_scaled_mm.default(buf9, buf12, arg6_1, buf13, arg7_1, None)
            del arg6_1
            del arg7_1
            del buf12
            buf16 = empty_strided_cuda((s72, 3584), (3584, 1), torch.bfloat16)
            buf18 = empty_strided_cuda((2368, ), (1, ), torch.float32)
            # Topologically Sorted Source Nodes: [silu, mul_2, abs_3, max_3], Original ATen: [aten.slice, aten.silu, aten.mul, aten.abs, aten.max]
            triton_red_fused_abs_max_mul_silu_slice_6_r0_numel = 8*s72
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_abs_max_mul_silu_slice_6.run(buf9, buf18, s72, 2368, triton_red_fused_abs_max_mul_silu_slice_6_r0_numel, stream=raw_stream0)
            buf19 = buf11; del buf11  # reuse
            buf21 = buf13; del buf13  # reuse
            # Topologically Sorted Source Nodes: [silu, mul_2, to_9, abs_3, max_3, unsqueeze_2, to_8, truediv_2, clamp_4, reciprocal_2, mul_3, clamp_5, to_11, cutlass_scaled_mm_2], Original ATen: [aten.slice, aten.silu, aten.mul, aten._to_copy, aten.abs, aten.max, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, _C.cutlass_scaled_mm]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_7.run(buf18, buf19, buf21, 1, 2368, stream=raw_stream0)
            del buf18
            buf20 = empty_strided_cuda((s72, 18944), (18944, 1), torch.float8_e4m3fn)
            # Topologically Sorted Source Nodes: [silu, mul_2, to_9, unsqueeze_2, to_8, truediv_2, clamp_4, reciprocal_2, mul_3, clamp_5, to_11, cutlass_scaled_mm_2], Original ATen: [aten.slice, aten.silu, aten.mul, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, _C.cutlass_scaled_mm]
            triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_silu_slice_unsqueeze_8_xnumel = 18944*s72
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_silu_slice_unsqueeze_8.run(buf9, buf19, buf20, triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_silu_slice_unsqueeze_8_xnumel, stream=raw_stream0)
            del buf9
            assert_size_stride(arg8_1, (18944, 3584), (1, 18944), 'input')
            assert_size_stride(arg9_1, (1, ), (1, ), 'input')
            arg8_1 = copy_if_misaligned(arg8_1)
            arg9_1 = copy_if_misaligned(arg9_1)
            # Topologically Sorted Source Nodes: [silu, mul_2, to_9, unsqueeze_2, to_8, truediv_2, clamp_4, reciprocal_2, mul_3, clamp_5, to_11, cutlass_scaled_mm_2], Original ATen: [aten.slice, aten.silu, aten.mul, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, _C.cutlass_scaled_mm]
            torch.ops._C.cutlass_scaled_mm.default(buf16, buf20, arg8_1, buf21, arg9_1, None)
            del arg8_1
            del arg9_1
            del buf20
            assert_size_stride(arg10_1, (3584, ), (1, ), 'input')
            arg10_1 = copy_if_misaligned(arg10_1)
            buf24 = empty_strided_cuda((s72, 3584), (3584, 1), torch.bfloat16)
            buf26 = empty_strided_cuda((s72, 3584), (3584, 1), torch.bfloat16)
            buf28 = empty_strided_cuda((s72, 1), (1, s72), torch.float32)
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, fused_add_rms_norm_maybe_inplace_1, abs_4, max_4], Original ATen: [vllm_ir.fused_add_rms_norm, aten.abs, aten.max]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_abs_fused_add_rms_norm_max_9.run(buf16, buf0, arg5_1, arg10_1, buf24, buf26, buf28, s72, 3584, stream=raw_stream0)
            del arg10_1
            del arg5_1
            del buf0
            buf27 = empty_strided_cuda((s72, 4608), (4608, 1), torch.bfloat16)
            buf29 = buf19; del buf19  # reuse
            buf31 = buf21; del buf21  # reuse
            # Topologically Sorted Source Nodes: [to_13, abs_4, max_4, unsqueeze_3, to_12, truediv_3, clamp_6, reciprocal_3, mul_4, clamp_7, to_15, cutlass_scaled_mm_3], Original ATen: [aten._to_copy, aten.abs, aten.max, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_4.run(buf28, buf29, buf31, 1, s72, stream=raw_stream0)
            del buf28
            buf30 = empty_strided_cuda((s72, 3584), (3584, 1), torch.float8_e4m3fn)
            # Topologically Sorted Source Nodes: [to_13, unsqueeze_3, to_12, truediv_3, clamp_6, reciprocal_3, mul_4, clamp_7, to_15, cutlass_scaled_mm_3], Original ATen: [aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
            triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2_xnumel = 3584*s72
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2.run(buf26, buf29, buf30, triton_poi_fused__to_copy_clamp_cutlass_scaled_mm_div_mul_reciprocal_unsqueeze_view_2_xnumel, stream=raw_stream0)
            del buf29
            assert_size_stride(arg11_1, (3584, 4608), (1, 3584), 'input')
            assert_size_stride(arg12_1, (1, ), (1, ), 'input')
            assert_size_stride(arg13_1, (4608, ), (1, ), 'input')
            arg11_1 = copy_if_misaligned(arg11_1)
            arg12_1 = copy_if_misaligned(arg12_1)
            arg13_1 = copy_if_misaligned(arg13_1)
            # Topologically Sorted Source Nodes: [to_13, unsqueeze_3, to_12, truediv_3, clamp_6, reciprocal_3, mul_4, clamp_7, to_15, cutlass_scaled_mm_3], Original ATen: [aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
            torch.ops._C.cutlass_scaled_mm.default(buf27, buf30, arg11_1, buf31, arg12_1, arg13_1)
            del arg11_1
            del arg12_1
            del arg13_1
            del buf30
            del buf31
            assert_size_stride(arg14_1, (s72, ), (1, ), 'input')
            assert_size_stride(arg15_1, (32768, 128), (128, 1), 'input')
            arg14_1 = copy_if_misaligned(arg14_1)
            arg15_1 = copy_if_misaligned(arg15_1)
            buf35 = reinterpret_tensor(buf26, (s72, 28, 128), (3584, 128, 1), 0); del buf26  # reuse
            buf34 = empty_strided_cuda((s72, 4, 128), (512, 128, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [index_select, chunk, mul_5, mul_6, mul_9, mul_10, unsqueeze_6, unsqueeze_7, sub_1, mul_11, mul_12, add_1, cat_2, unsqueeze_4, unsqueeze_5, sub, mul_7, mul_8, add, cat], Original ATen: [aten.index_select, aten.split, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.mul, aten.sub, aten.add, aten.cat]
            triton_poi_fused_10_xnumel = 3584*s72
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_10.run(buf27, arg14_1, arg15_1, buf35, triton_poi_fused_10_xnumel, stream=raw_stream0)
            # Topologically Sorted Source Nodes: [index_select, chunk, mul_5, mul_6, mul_9, mul_10, unsqueeze_6, unsqueeze_7, sub_1, mul_11, mul_12, add_1, cat_2, unsqueeze_4, unsqueeze_5, sub, mul_7, mul_8, add, cat], Original ATen: [aten.index_select, aten.split, aten.split_with_sizes, aten.view, aten.unsqueeze, aten.mul, aten.sub, aten.add, aten.cat]
            triton_poi_fused_11_xnumel = 512*s72
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_11.run(buf27, arg14_1, arg15_1, buf34, triton_poi_fused_11_xnumel, stream=raw_stream0)
            del arg14_1
            del arg15_1
            buf36 = buf16; del buf16  # reuse
        return (buf34, reinterpret_tensor(buf27, (s72, 4, 128), (4608, 128, 1), 4096), buf35, reinterpret_tensor(buf36, (s72, 28, 128), (3584, 128, 1), 0), buf24, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((16384, 28, 128), (3584, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg1_1 = 16384
    arg2_1 = rand_strided((3584, 3584), (1, 3584), device='cuda:0', dtype=torch.float8_e4m3fn)
    arg3_1 = rand_strided((1, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg4_1 = rand_strided((3584, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg5_1 = rand_strided((16384, 3584), (3584, 1), device='cuda:0', dtype=torch.bfloat16)
    arg6_1 = rand_strided((3584, 37888), (1, 3584), device='cuda:0', dtype=torch.float8_e4m3fn)
    arg7_1 = rand_strided((1, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg8_1 = rand_strided((18944, 3584), (1, 18944), device='cuda:0', dtype=torch.float8_e4m3fn)
    arg9_1 = rand_strided((1, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg10_1 = rand_strided((3584, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg11_1 = rand_strided((3584, 4608), (1, 3584), device='cuda:0', dtype=torch.float8_e4m3fn)
    arg12_1 = rand_strided((1, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg13_1 = rand_strided((4608, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg14_1 = rand_strided((16384, ), (1, ), device='cuda:0', dtype=torch.int64)
    arg15_1 = rand_strided((32768, 128), (128, 1), device='cuda:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
