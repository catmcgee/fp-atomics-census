r"""
Compile-time auto-tuning block: 

import torch
from math import inf, nan
from torch._dynamo.testing import rand_strided
from torch._dynamo.utils import preserve_rng_state
from torch._inductor.select_algorithm import AlgorithmSelectorCache
from torch._inductor.async_compile import AsyncCompile

async_compile = AsyncCompile()
generate_example_value = AlgorithmSelectorCache.generate_example_value
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
get_raw_stream = torch._C._cuda_getCurrentRawStream


# kernel path: /tmp/torchinductor_root/qh/cqh52oaeqqqkvytbix7b47mrintqlfkn4vcmowaiwyhm6hvjot4y.py
# Topologically Sorted Source Nodes: [view, abs_1, max_1, to_1, unsqueeze, to, truediv, clamp, reciprocal, mul, clamp_1, to_3, cutlass_scaled_mm], Original ATen: [aten.view, aten.abs, aten.max, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   abs_1 => abs_1
#   clamp => clamp_min
#   clamp_1 => clamp_max, clamp_min_1
#   cutlass_scaled_mm => cutlass_scaled_mm_default_2
#   max_1 => max_1
#   mul => mul_15
#   reciprocal => reciprocal
#   to => convert_element_type
#   to_1 => convert_element_type_1
#   to_3 => convert_element_type_2
#   truediv => div
#   unsqueeze => unsqueeze
#   view => view
# Graph fragment:
#   %arg0_1 : Tensor "bf16[s72, 28, 128][3584, 128, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %getitem : Tensor "bf16[s72][1]cuda:0" = PlaceHolder[target=getitem]
#   %view : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%arg0_1, [-1, 3584]), kwargs = {})
#   %abs_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%view,), kwargs = {})
#   %max_1 : [num_users=1] = call_function[target=torch.ops.aten.max.dim](args = (%abs_1, -1), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.float32), kwargs = {})
#   %unsqueeze : Tensor "bf16[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem, -1), kwargs = {})
#   %convert_element_type : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %div : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type, 448.0), kwargs = {})
#   %clamp_min : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div, 4.359654017857143e-06), kwargs = {})
#   %reciprocal : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min,), kwargs = {})
#   %mul_15 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_1, %reciprocal), kwargs = {})
#   %clamp_min_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_15, -448.0), kwargs = {})
#   %clamp_max : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_1, 448.0), kwargs = {})
#   %convert_element_type_2 : Tensor "f8e4m3fn[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_2 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty, %convert_element_type_2, %arg2_1, %clamp_min, %arg3_1, None), kwargs = {})
#   return %getitem,%buf3,%buf4
triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_0 = async_compile.triton('triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr1': '*fp8e4nv', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 131072, 'r0_': 234881024}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.176226304, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_0(in_ptr0, out_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 3584
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp3 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    _tmp3_index = tl.full([XBLOCK, R0_BLOCK], 2147483647, tl.int32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl_math.abs(tmp0)
        tmp2 = tl.broadcast_to(tmp1, [XBLOCK, R0_BLOCK])
        _tmp3_next, _tmp3_index_next = triton_helpers.maximum_with_index(
            _tmp3, _tmp3_index, tmp2, rindex
        )
        _tmp3 = tl.where(r0_mask & xmask, _tmp3_next, _tmp3)
        _tmp3_index = tl.where(r0_mask & xmask, _tmp3_index_next, _tmp3_index)
    tmp3_val, tmp3_idx = triton_helpers.max_with_index(_tmp3, _tmp3_index, 1)
    tmp3 = tmp3_val[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp4 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp3.to(tl.float32)
        tmp7 = tl.full([1, 1], 0.002232142857142857, tl.float32)
        tmp8 = tmp6 * tmp7
        tmp9 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
        tmp10 = triton_helpers.maximum(tmp8, tmp9)
        tmp11 = tl.full([1, 1], 1.0, tl.float32)
        tmp12 = (tmp11 / tmp10)
        tmp13 = tmp5 * tmp12
        tmp14 = tl.full([1, 1], -448.0, tl.float32)
        tmp15 = triton_helpers.maximum(tmp13, tmp14)
        tmp16 = tl.full([1, 1], 448.0, tl.float32)
        tmp17 = triton_helpers.minimum(tmp15, tmp16)
        tmp18 = tmp17.to(tl.float8e4nv)
        tl.store(out_ptr1 + (r0_1 + 3584*x0), tmp18, r0_mask & xmask)
    tmp19 = tmp3.to(tl.float32)
    tmp20 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp21 = tmp19 * tmp20
    tmp22 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
    tmp23 = triton_helpers.maximum(tmp21, tmp22)
    tl.store(out_ptr2 + (x0), tmp23, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/tp/ctpopedl5m4bk6tko2zwqilus5bzedmvjhndji7hajshvb3jqm3l.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, abs_2, max_2, to_5, unsqueeze_1, to_4, truediv_1, clamp_2, reciprocal_1, mul_1, clamp_3, to_7, cutlass_scaled_mm_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten.abs, aten.max, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   abs_2 => abs_2
#   clamp_2 => clamp_min_2
#   clamp_3 => clamp_max_1, clamp_min_3
#   cutlass_scaled_mm_1 => cutlass_scaled_mm_default_1
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, add_tensor_3, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_7, mean_dim_1, mul_tensor_2, mul_tensor_3, pow_tensor_scalar_1, rsqrt_default_1
#   max_2 => max_2
#   mul_1 => mul_45
#   reciprocal_1 => reciprocal_1
#   to_4 => convert_element_type_3
#   to_5 => convert_element_type_4
#   to_7 => convert_element_type_5
#   truediv_1 => div_1
#   unsqueeze_1 => unsqueeze_1
# Graph fragment:
#   %buf6 : Tensor  = PlaceHolder[target=buf6]
#   %arg5_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %buf7 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf7]
#   %arg4_1 : Tensor "bf16[3584][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %getitem_6 : Tensor "bf16[s72][1]cuda:0" = PlaceHolder[target=getitem_6]
#   %convert_element_type_default_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %pow_tensor_scalar_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_2, 2), kwargs = {})
#   %mean_dim_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_1, [-1], True), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_1, 1e-06), kwargs = {})
#   %rsqrt_default_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_2, %rsqrt_default_1), kwargs = {})
#   %convert_element_type_default_7 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_2, torch.bfloat16), kwargs = {})
#   %mul_tensor_3 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_7, %arg4_1), kwargs = {})
#   %abs_2 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_tensor_3,), kwargs = {})
#   %max_2 : [num_users=1] = call_function[target=torch.ops.aten.max.dim](args = (%abs_2, -1), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_3, torch.float32), kwargs = {})
#   %unsqueeze_1 : Tensor "bf16[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem_6, -1), kwargs = {})
#   %convert_element_type_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_1, torch.float32), kwargs = {})
#   %div_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_3, 448.0), kwargs = {})
#   %clamp_min_2 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div_1, 4.359654017857143e-06), kwargs = {})
#   %reciprocal_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min_2,), kwargs = {})
#   %mul_45 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_4, %reciprocal_1), kwargs = {})
#   %clamp_min_3 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_45, -448.0), kwargs = {})
#   %clamp_max_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_3, 448.0), kwargs = {})
#   %convert_element_type_5 : Tensor "f8e4m3fn[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max_1, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_1 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty_1, %convert_element_type_5, %arg6_1, %clamp_min_2, %arg7_1, None), kwargs = {})
#   return %buf7,%getitem_6,%buf11,%buf12
triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_1 = async_compile.triton('triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr2': '*fp8e4nv', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 131072, 'r0_': 234888192}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.176233472, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_1(in_ptr0, in_ptr1, in_ptr2, out_ptr2, out_ptr3, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 3584
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp1 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    _tmp25 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    _tmp25_index = tl.full([XBLOCK, R0_BLOCK], 2147483647, tl.int32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp21 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tmp9.to(tl.float32)
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tmp10 + tmp12
        tmp14 = tl.full([1, 1], 3584.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1, 1], 1e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp20 = tmp19.to(tl.float32)
        tmp22 = tmp20 * tmp21
        tmp23 = tl_math.abs(tmp22)
        tmp24 = tl.broadcast_to(tmp23, [XBLOCK, R0_BLOCK])
        _tmp25_next, _tmp25_index_next = triton_helpers.maximum_with_index(
            _tmp25, _tmp25_index, tmp24, rindex
        )
        _tmp25 = tl.where(r0_mask & xmask, _tmp25_next, _tmp25)
        _tmp25_index = tl.where(r0_mask & xmask, _tmp25_index_next, _tmp25_index)
    tmp25_val, tmp25_idx = triton_helpers.max_with_index(_tmp25, _tmp25_index, 1)
    tmp25 = tmp25_val[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp26 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp28 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp38 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp27 = tmp26.to(tl.float32)
        tmp29 = tmp28.to(tl.float32)
        tmp30 = tmp27 + tmp29
        tmp31 = tl.full([1, 1], 3584.0, tl.float32)
        tmp32 = (tmp7 / tmp31)
        tmp33 = tl.full([1, 1], 1e-06, tl.float32)
        tmp34 = tmp32 + tmp33
        tmp35 = libdevice.rsqrt(tmp34)
        tmp36 = tmp30 * tmp35
        tmp37 = tmp36.to(tl.float32)
        tmp39 = tmp37 * tmp38
        tmp40 = tmp39.to(tl.float32)
        tmp41 = tmp25.to(tl.float32)
        tmp42 = tl.full([1, 1], 0.002232142857142857, tl.float32)
        tmp43 = tmp41 * tmp42
        tmp44 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
        tmp45 = triton_helpers.maximum(tmp43, tmp44)
        tmp46 = tl.full([1, 1], 1.0, tl.float32)
        tmp47 = (tmp46 / tmp45)
        tmp48 = tmp40 * tmp47
        tmp49 = tl.full([1, 1], -448.0, tl.float32)
        tmp50 = triton_helpers.maximum(tmp48, tmp49)
        tmp51 = tl.full([1, 1], 448.0, tl.float32)
        tmp52 = triton_helpers.minimum(tmp50, tmp51)
        tmp53 = tmp52.to(tl.float8e4nv)
        tl.store(out_ptr2 + (r0_1 + 3584*x0), tmp53, r0_mask & xmask)
    tmp54 = tmp25.to(tl.float32)
    tmp55 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp56 = tmp54 * tmp55
    tmp57 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
    tmp58 = triton_helpers.maximum(tmp56, tmp57)
    tl.store(out_ptr3 + (x0), tmp58, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/3z/c3zt47byvwinrbxzhb45rlzgz3iujvgayzpqpqedxjc3xnmcqqvg.py
# Topologically Sorted Source Nodes: [silu, mul_2, abs_3, max_3, to_9, unsqueeze_2, to_8, truediv_2, clamp_4, reciprocal_2, mul_3, clamp_5, to_11, cutlass_scaled_mm_2], Original ATen: [aten.slice, aten.silu, aten.mul, aten.abs, aten.max, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   abs_3 => abs_3
#   clamp_4 => clamp_min_4
#   clamp_5 => clamp_max_2, clamp_min_5
#   cutlass_scaled_mm_2 => cutlass_scaled_mm_default
#   max_3 => max_3
#   mul_2 => mul_64, slice_4
#   mul_3 => mul_80
#   reciprocal_2 => reciprocal_2
#   silu => add_110, convert_element_type_6, convert_element_type_7, div_2, exp, neg, slice_2
#   to_11 => convert_element_type_10
#   to_8 => convert_element_type_8
#   to_9 => convert_element_type_9
#   truediv_2 => div_3
#   unsqueeze_2 => unsqueeze_2
# Graph fragment:
#   %buf14 : Tensor  = PlaceHolder[target=buf14]
#   %getitem_10 : Tensor "bf16[s72][1]cuda:0" = PlaceHolder[target=getitem_10]
#   %slice_2 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 0, 18944), kwargs = {})
#   %convert_element_type_6 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_2, torch.float32), kwargs = {})
#   %neg : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_6,), kwargs = {})
#   %exp : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_110 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_6, %add_110), kwargs = {})
#   %convert_element_type_7 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_2, torch.bfloat16), kwargs = {})
#   %slice_4 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 18944, 9223372036854775807), kwargs = {})
#   %mul_64 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %slice_4), kwargs = {})
#   %abs_3 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_64,), kwargs = {})
#   %max_3 : [num_users=1] = call_function[target=torch.ops.aten.max.dim](args = (%abs_3, -1), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_64, torch.float32), kwargs = {})
#   %unsqueeze_2 : Tensor "bf16[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem_10, -1), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %div_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_8, 448.0), kwargs = {})
#   %clamp_min_4 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div_3, 4.359654017857143e-06), kwargs = {})
#   %reciprocal_2 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min_4,), kwargs = {})
#   %mul_80 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_9, %reciprocal_2), kwargs = {})
#   %clamp_min_5 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_80, -448.0), kwargs = {})
#   %clamp_max_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_5, 448.0), kwargs = {})
#   %convert_element_type_10 : Tensor "f8e4m3fn[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max_2, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty_2, %convert_element_type_10, %arg8_1, %clamp_min_4, %arg9_1, None), kwargs = {})
#   return %getitem_10,%buf18,%buf19
triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_2 = async_compile.triton('triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 32768},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr1': '*fp8e4nv', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 131072, 'r0_': 620756992}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.310444032, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_2(in_ptr0, out_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 18944
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp12 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    _tmp12_index = tl.full([XBLOCK, R0_BLOCK], 2147483647, tl.int32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 37888*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp8 = tl.load(in_ptr0 + (18944 + r0_1 + 37888*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = -tmp1
        tmp3 = libdevice.exp(tmp2)
        tmp4 = tl.full([1, 1], 1.0, tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = (tmp1 / tmp5)
        tmp7 = tmp6.to(tl.float32)
        tmp9 = tmp7 * tmp8
        tmp10 = tl_math.abs(tmp9)
        tmp11 = tl.broadcast_to(tmp10, [XBLOCK, R0_BLOCK])
        _tmp12_next, _tmp12_index_next = triton_helpers.maximum_with_index(
            _tmp12, _tmp12_index, tmp11, rindex
        )
        _tmp12 = tl.where(r0_mask & xmask, _tmp12_next, _tmp12)
        _tmp12_index = tl.where(r0_mask & xmask, _tmp12_index_next, _tmp12_index)
    tmp12_val, tmp12_idx = triton_helpers.max_with_index(_tmp12, _tmp12_index, 1)
    tmp12 = tmp12_val[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr0 + (r0_1 + 37888*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp21 = tl.load(in_ptr0 + (18944 + r0_1 + 37888*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = -tmp14
        tmp16 = libdevice.exp(tmp15)
        tmp17 = tl.full([1, 1], 1.0, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = (tmp14 / tmp18)
        tmp20 = tmp19.to(tl.float32)
        tmp22 = tmp20 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp12.to(tl.float32)
        tmp25 = tl.full([1, 1], 0.002232142857142857, tl.float32)
        tmp26 = tmp24 * tmp25
        tmp27 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
        tmp28 = triton_helpers.maximum(tmp26, tmp27)
        tmp29 = (tmp17 / tmp28)
        tmp30 = tmp23 * tmp29
        tmp31 = tl.full([1, 1], -448.0, tl.float32)
        tmp32 = triton_helpers.maximum(tmp30, tmp31)
        tmp33 = tl.full([1, 1], 448.0, tl.float32)
        tmp34 = triton_helpers.minimum(tmp32, tmp33)
        tmp35 = tmp34.to(tl.float8e4nv)
        tl.store(out_ptr1 + (r0_1 + 18944*x0), tmp35, r0_mask & xmask)
    tmp36 = tmp12.to(tl.float32)
    tmp37 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp38 = tmp36 * tmp37
    tmp39 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
    tmp40 = triton_helpers.maximum(tmp38, tmp39)
    tl.store(out_ptr2 + (x0), tmp40, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/6g/c6gdha5n7vmxfd66fhcrjfnbc3lkfzazti5k6t52q4h4okqkuhq7.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, fused_add_rms_norm_maybe_inplace_1], Original ATen: [vllm_ir.fused_add_rms_norm]
# Source node to ATen node mapping:
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_6
#   fused_add_rms_norm_maybe_inplace_1 => add_tensor, add_tensor_1, convert_element_type_default, convert_element_type_default_1, convert_element_type_default_3, mean_dim, mul_tensor, mul_tensor_1, pow_tensor_scalar, rsqrt_default
# Graph fragment:
#   %buf21 : Tensor  = PlaceHolder[target=buf21]
#   %buf6 : Tensor  = PlaceHolder[target=buf6]
#   %arg5_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %buf22 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf22]
#   %arg10_1 : Tensor "bf16[3584][1]cuda:0" = PlaceHolder[target=arg10_1]
#   %convert_element_type_default_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %convert_element_type_default_6 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor_2, torch.bfloat16), kwargs = {})
#   %convert_element_type_default : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty_2, torch.float32), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%convert_element_type_default_6, torch.float32), kwargs = {})
#   %add_tensor : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default, %convert_element_type_default_1), kwargs = {})
#   %pow_tensor_scalar : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor, 2), kwargs = {})
#   %mean_dim : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar, [-1], True), kwargs = {})
#   %add_tensor_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim, 1e-06), kwargs = {})
#   %rsqrt_default : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_1,), kwargs = {})
#   %mul_tensor : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor, %rsqrt_default), kwargs = {})
#   %convert_element_type_default_3 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor, torch.bfloat16), kwargs = {})
#   %mul_tensor_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_3, %arg10_1), kwargs = {})
#   return %buf22,%mul_tensor_1
triton_red_fused_fused_add_rms_norm_3 = async_compile.triton('triton_red_fused_fused_add_rms_norm_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_fused_add_rms_norm_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 352328704}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.234888192, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_fused_add_rms_norm_3(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 3584
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp12 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tl.load(in_ptr2 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp3 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp1 + tmp8
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [XBLOCK, R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask & xmask, tmp13, _tmp12)
    tmp12 = tl.sum(_tmp12, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp14 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp18 = tl.load(in_ptr2 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp31 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp15 = tmp14.to(tl.float32)
        tmp17 = tmp16.to(tl.float32)
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp17 + tmp19
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp15 + tmp22
        tmp24 = tl.full([1, 1], 3584.0, tl.float32)
        tmp25 = (tmp12 / tmp24)
        tmp26 = tl.full([1, 1], 1e-06, tl.float32)
        tmp27 = tmp25 + tmp26
        tmp28 = libdevice.rsqrt(tmp27)
        tmp29 = tmp23 * tmp28
        tmp30 = tmp29.to(tl.float32)
        tmp32 = tmp30 * tmp31
        tl.store(out_ptr1 + (r0_1 + 3584*x0), tmp32, r0_mask & xmask)
''', device_str='cuda')

async_compile.wait(globals())
del async_compile

import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
with torch.cuda._DeviceGuard(0):
    raw_stream0 = get_raw_stream(0)
raw_stream0 = get_raw_stream(0)
arg0_1 = generate_example_value((16384, 28, 128), (3584, 128, 1), 'cuda:0', torch.bfloat16, 0, (16384, 28, 128))
buf3 = generate_example_value((16384, 3584), (3584, 1), 'cuda:0', torch.float8_e4m3fn, 0, (16384, 3584))
buf4 = generate_example_value((16384, 1), (1, 1), 'cuda:0', torch.float32, 0, (16384, 1))
with torch.cuda._DeviceGuard(0):
    triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_0.run(arg0_1, buf3, buf4, 16384, 3584, stream=raw_stream0)
del arg0_1, buf3, buf4

raw_stream0 = get_raw_stream(0)
buf2 = generate_example_value((16384, 3584), (3584, 1), 'cuda:0', torch.bfloat16, 0, (16384, 3584))
arg5_1 = generate_example_value((16384, 3584), (3584, 1), 'cuda:0', torch.bfloat16, 0, (16384, 3584))
arg4_1 = generate_example_value((3584,), (1,), 'cuda:0', torch.bfloat16, 0, (3584,))
buf11 = generate_example_value((16384, 3584), (3584, 1), 'cuda:0', torch.float8_e4m3fn, 0, (16384, 3584))
buf12 = generate_example_value((16384, 1), (1, 1), 'cuda:0', torch.float32, 0, (16384, 1))
with torch.cuda._DeviceGuard(0):
    triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_1.run(buf2, arg5_1, arg4_1, buf11, buf12, 16384, 3584, stream=raw_stream0)
del arg4_1, buf11, buf12

raw_stream0 = get_raw_stream(0)
buf10 = generate_example_value((16384, 37888), (37888, 1), 'cuda:0', torch.bfloat16, 0, (16384, 37888))
buf18 = generate_example_value((16384, 18944), (18944, 1), 'cuda:0', torch.float8_e4m3fn, 0, (16384, 18944))
buf19 = generate_example_value((16384, 1), (1, 1), 'cuda:0', torch.float32, 0, (16384, 1))
with torch.cuda._DeviceGuard(0):
    triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_2.run(buf10, buf18, buf19, 16384, 18944, stream=raw_stream0)
del buf10, buf18, buf19

raw_stream0 = get_raw_stream(0)
buf17 = generate_example_value((16384, 3584), (3584, 1), 'cuda:0', torch.bfloat16, 0, (16384, 3584))
arg10_1 = generate_example_value((3584,), (1,), 'cuda:0', torch.bfloat16, 0, (3584,))
buf23 = generate_example_value((16384, 3584), (3584, 1), 'cuda:0', torch.bfloat16, 0, (16384, 3584))
with torch.cuda._DeviceGuard(0):
    triton_red_fused_fused_add_rms_norm_3.run(buf17, buf2, arg5_1, arg10_1, buf23, 16384, 3584, stream=raw_stream0)
del buf2, arg5_1, buf17, arg10_1, buf23

"""
# AOT ID: ['28_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /tmp/torchinductor_root/qh/cqh52oaeqqqkvytbix7b47mrintqlfkn4vcmowaiwyhm6hvjot4y.py
# Topologically Sorted Source Nodes: [view, abs_1, max_1, to_1, unsqueeze, to, truediv, clamp, reciprocal, mul, clamp_1, to_3, cutlass_scaled_mm], Original ATen: [aten.view, aten.abs, aten.max, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   abs_1 => abs_1
#   clamp => clamp_min
#   clamp_1 => clamp_max, clamp_min_1
#   cutlass_scaled_mm => cutlass_scaled_mm_default_2
#   max_1 => max_1
#   mul => mul_15
#   reciprocal => reciprocal
#   to => convert_element_type
#   to_1 => convert_element_type_1
#   to_3 => convert_element_type_2
#   truediv => div
#   unsqueeze => unsqueeze
#   view => view
# Graph fragment:
#   %arg0_1 : Tensor "bf16[s72, 28, 128][3584, 128, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %getitem : Tensor "bf16[s72][1]cuda:0" = PlaceHolder[target=getitem]
#   %view : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.reshape.default](args = (%arg0_1, [-1, 3584]), kwargs = {})
#   %abs_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%view,), kwargs = {})
#   %max_1 : [num_users=1] = call_function[target=torch.ops.aten.max.dim](args = (%abs_1, -1), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view, torch.float32), kwargs = {})
#   %unsqueeze : Tensor "bf16[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem, -1), kwargs = {})
#   %convert_element_type : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %div : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type, 448.0), kwargs = {})
#   %clamp_min : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div, 4.359654017857143e-06), kwargs = {})
#   %reciprocal : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min,), kwargs = {})
#   %mul_15 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_1, %reciprocal), kwargs = {})
#   %clamp_min_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_15, -448.0), kwargs = {})
#   %clamp_max : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_1, 448.0), kwargs = {})
#   %convert_element_type_2 : Tensor "f8e4m3fn[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_2 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty, %convert_element_type_2, %arg2_1, %clamp_min, %arg3_1, None), kwargs = {})
#   return %getitem,%buf3,%buf4
triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_0 = async_compile.triton('triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr1': '*fp8e4nv', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 131072, 'r0_': 234881024}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.176226304, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_0(in_ptr0, out_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 3584
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp3 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    _tmp3_index = tl.full([XBLOCK, R0_BLOCK], 2147483647, tl.int32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tl_math.abs(tmp0)
        tmp2 = tl.broadcast_to(tmp1, [XBLOCK, R0_BLOCK])
        _tmp3_next, _tmp3_index_next = triton_helpers.maximum_with_index(
            _tmp3, _tmp3_index, tmp2, rindex
        )
        _tmp3 = tl.where(r0_mask & xmask, _tmp3_next, _tmp3)
        _tmp3_index = tl.where(r0_mask & xmask, _tmp3_index_next, _tmp3_index)
    tmp3_val, tmp3_idx = triton_helpers.max_with_index(_tmp3, _tmp3_index, 1)
    tmp3 = tmp3_val[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp4 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp3.to(tl.float32)
        tmp7 = tl.full([1, 1], 0.002232142857142857, tl.float32)
        tmp8 = tmp6 * tmp7
        tmp9 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
        tmp10 = triton_helpers.maximum(tmp8, tmp9)
        tmp11 = tl.full([1, 1], 1.0, tl.float32)
        tmp12 = (tmp11 / tmp10)
        tmp13 = tmp5 * tmp12
        tmp14 = tl.full([1, 1], -448.0, tl.float32)
        tmp15 = triton_helpers.maximum(tmp13, tmp14)
        tmp16 = tl.full([1, 1], 448.0, tl.float32)
        tmp17 = triton_helpers.minimum(tmp15, tmp16)
        tmp18 = tmp17.to(tl.float8e4nv)
        tl.store(out_ptr1 + (r0_1 + 3584*x0), tmp18, r0_mask & xmask)
    tmp19 = tmp3.to(tl.float32)
    tmp20 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp21 = tmp19 * tmp20
    tmp22 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
    tmp23 = triton_helpers.maximum(tmp21, tmp22)
    tl.store(out_ptr2 + (x0), tmp23, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/tp/ctpopedl5m4bk6tko2zwqilus5bzedmvjhndji7hajshvb3jqm3l.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, abs_2, max_2, to_5, unsqueeze_1, to_4, truediv_1, clamp_2, reciprocal_1, mul_1, clamp_3, to_7, cutlass_scaled_mm_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten.abs, aten.max, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   abs_2 => abs_2
#   clamp_2 => clamp_min_2
#   clamp_3 => clamp_max_1, clamp_min_3
#   cutlass_scaled_mm_1 => cutlass_scaled_mm_default_1
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, add_tensor_3, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_7, mean_dim_1, mul_tensor_2, mul_tensor_3, pow_tensor_scalar_1, rsqrt_default_1
#   max_2 => max_2
#   mul_1 => mul_45
#   reciprocal_1 => reciprocal_1
#   to_4 => convert_element_type_3
#   to_5 => convert_element_type_4
#   to_7 => convert_element_type_5
#   truediv_1 => div_1
#   unsqueeze_1 => unsqueeze_1
# Graph fragment:
#   %buf6 : Tensor  = PlaceHolder[target=buf6]
#   %arg5_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %buf7 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf7]
#   %arg4_1 : Tensor "bf16[3584][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %getitem_6 : Tensor "bf16[s72][1]cuda:0" = PlaceHolder[target=getitem_6]
#   %convert_element_type_default_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %pow_tensor_scalar_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_2, 2), kwargs = {})
#   %mean_dim_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_1, [-1], True), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_1, 1e-06), kwargs = {})
#   %rsqrt_default_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_2, %rsqrt_default_1), kwargs = {})
#   %convert_element_type_default_7 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_2, torch.bfloat16), kwargs = {})
#   %mul_tensor_3 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_7, %arg4_1), kwargs = {})
#   %abs_2 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_tensor_3,), kwargs = {})
#   %max_2 : [num_users=1] = call_function[target=torch.ops.aten.max.dim](args = (%abs_2, -1), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_3, torch.float32), kwargs = {})
#   %unsqueeze_1 : Tensor "bf16[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem_6, -1), kwargs = {})
#   %convert_element_type_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_1, torch.float32), kwargs = {})
#   %div_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_3, 448.0), kwargs = {})
#   %clamp_min_2 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div_1, 4.359654017857143e-06), kwargs = {})
#   %reciprocal_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min_2,), kwargs = {})
#   %mul_45 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_4, %reciprocal_1), kwargs = {})
#   %clamp_min_3 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_45, -448.0), kwargs = {})
#   %clamp_max_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_3, 448.0), kwargs = {})
#   %convert_element_type_5 : Tensor "f8e4m3fn[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max_1, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default_1 : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty_1, %convert_element_type_5, %arg6_1, %clamp_min_2, %arg7_1, None), kwargs = {})
#   return %buf7,%getitem_6,%buf11,%buf12
triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_1 = async_compile.triton('triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr2': '*fp8e4nv', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 2, 'autotune_hints': set(), 'tiling_scores': {'x': 131072, 'r0_': 234888192}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.176233472, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_1(in_ptr0, in_ptr1, in_ptr2, out_ptr2, out_ptr3, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 3584
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp1 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    _tmp25 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    _tmp25_index = tl.full([XBLOCK, R0_BLOCK], 2147483647, tl.int32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp21 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tmp9.to(tl.float32)
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tmp10 + tmp12
        tmp14 = tl.full([1, 1], 3584.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1, 1], 1e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp20 = tmp19.to(tl.float32)
        tmp22 = tmp20 * tmp21
        tmp23 = tl_math.abs(tmp22)
        tmp24 = tl.broadcast_to(tmp23, [XBLOCK, R0_BLOCK])
        _tmp25_next, _tmp25_index_next = triton_helpers.maximum_with_index(
            _tmp25, _tmp25_index, tmp24, rindex
        )
        _tmp25 = tl.where(r0_mask & xmask, _tmp25_next, _tmp25)
        _tmp25_index = tl.where(r0_mask & xmask, _tmp25_index_next, _tmp25_index)
    tmp25_val, tmp25_idx = triton_helpers.max_with_index(_tmp25, _tmp25_index, 1)
    tmp25 = tmp25_val[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp26 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp28 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp38 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp27 = tmp26.to(tl.float32)
        tmp29 = tmp28.to(tl.float32)
        tmp30 = tmp27 + tmp29
        tmp31 = tl.full([1, 1], 3584.0, tl.float32)
        tmp32 = (tmp7 / tmp31)
        tmp33 = tl.full([1, 1], 1e-06, tl.float32)
        tmp34 = tmp32 + tmp33
        tmp35 = libdevice.rsqrt(tmp34)
        tmp36 = tmp30 * tmp35
        tmp37 = tmp36.to(tl.float32)
        tmp39 = tmp37 * tmp38
        tmp40 = tmp39.to(tl.float32)
        tmp41 = tmp25.to(tl.float32)
        tmp42 = tl.full([1, 1], 0.002232142857142857, tl.float32)
        tmp43 = tmp41 * tmp42
        tmp44 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
        tmp45 = triton_helpers.maximum(tmp43, tmp44)
        tmp46 = tl.full([1, 1], 1.0, tl.float32)
        tmp47 = (tmp46 / tmp45)
        tmp48 = tmp40 * tmp47
        tmp49 = tl.full([1, 1], -448.0, tl.float32)
        tmp50 = triton_helpers.maximum(tmp48, tmp49)
        tmp51 = tl.full([1, 1], 448.0, tl.float32)
        tmp52 = triton_helpers.minimum(tmp50, tmp51)
        tmp53 = tmp52.to(tl.float8e4nv)
        tl.store(out_ptr2 + (r0_1 + 3584*x0), tmp53, r0_mask & xmask)
    tmp54 = tmp25.to(tl.float32)
    tmp55 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp56 = tmp54 * tmp55
    tmp57 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
    tmp58 = triton_helpers.maximum(tmp56, tmp57)
    tl.store(out_ptr3 + (x0), tmp58, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/3z/c3zt47byvwinrbxzhb45rlzgz3iujvgayzpqpqedxjc3xnmcqqvg.py
# Topologically Sorted Source Nodes: [silu, mul_2, abs_3, max_3, to_9, unsqueeze_2, to_8, truediv_2, clamp_4, reciprocal_2, mul_3, clamp_5, to_11, cutlass_scaled_mm_2], Original ATen: [aten.slice, aten.silu, aten.mul, aten.abs, aten.max, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, _C.cutlass_scaled_mm]
# Source node to ATen node mapping:
#   abs_3 => abs_3
#   clamp_4 => clamp_min_4
#   clamp_5 => clamp_max_2, clamp_min_5
#   cutlass_scaled_mm_2 => cutlass_scaled_mm_default
#   max_3 => max_3
#   mul_2 => mul_64, slice_4
#   mul_3 => mul_80
#   reciprocal_2 => reciprocal_2
#   silu => add_110, convert_element_type_6, convert_element_type_7, div_2, exp, neg, slice_2
#   to_11 => convert_element_type_10
#   to_8 => convert_element_type_8
#   to_9 => convert_element_type_9
#   truediv_2 => div_3
#   unsqueeze_2 => unsqueeze_2
# Graph fragment:
#   %buf14 : Tensor  = PlaceHolder[target=buf14]
#   %getitem_10 : Tensor "bf16[s72][1]cuda:0" = PlaceHolder[target=getitem_10]
#   %slice_2 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 0, 18944), kwargs = {})
#   %convert_element_type_6 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%slice_2, torch.float32), kwargs = {})
#   %neg : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_6,), kwargs = {})
#   %exp : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg,), kwargs = {})
#   %add_110 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp, 1), kwargs = {})
#   %div_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_6, %add_110), kwargs = {})
#   %convert_element_type_7 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_2, torch.bfloat16), kwargs = {})
#   %slice_4 : Tensor "bf16[s72, 18944][37888, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%empty_1, 1, 18944, 9223372036854775807), kwargs = {})
#   %mul_64 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %slice_4), kwargs = {})
#   %abs_3 : Tensor "bf16[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.abs.default](args = (%mul_64,), kwargs = {})
#   %max_3 : [num_users=1] = call_function[target=torch.ops.aten.max.dim](args = (%abs_3, -1), kwargs = {})
#   %convert_element_type_9 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_64, torch.float32), kwargs = {})
#   %unsqueeze_2 : Tensor "bf16[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem_10, -1), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze_2, torch.float32), kwargs = {})
#   %div_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_8, 448.0), kwargs = {})
#   %clamp_min_4 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.clamp_min.default](args = (%div_3, 4.359654017857143e-06), kwargs = {})
#   %reciprocal_2 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reciprocal.default](args = (%clamp_min_4,), kwargs = {})
#   %mul_80 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_9, %reciprocal_2), kwargs = {})
#   %clamp_min_5 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_min.default](args = (%mul_80, -448.0), kwargs = {})
#   %clamp_max_2 : Tensor "f32[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clamp_max.default](args = (%clamp_min_5, 448.0), kwargs = {})
#   %convert_element_type_10 : Tensor "f8e4m3fn[s72, 18944][18944, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%clamp_max_2, torch.float8_e4m3fn), kwargs = {})
#   %cutlass_scaled_mm_default : [num_users=0] = call_function[target=torch.ops._C.cutlass_scaled_mm.default](args = (%empty_2, %convert_element_type_10, %arg8_1, %clamp_min_4, %arg9_1, None), kwargs = {})
#   return %getitem_10,%buf18,%buf19
triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_2 = async_compile.triton('triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 32768},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr1': '*fp8e4nv', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 131072, 'r0_': 620756992}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.310444032, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_2(in_ptr0, out_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 18944
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp12 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    _tmp12_index = tl.full([XBLOCK, R0_BLOCK], 2147483647, tl.int32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 37888*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp8 = tl.load(in_ptr0 + (18944 + r0_1 + 37888*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = -tmp1
        tmp3 = libdevice.exp(tmp2)
        tmp4 = tl.full([1, 1], 1.0, tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = (tmp1 / tmp5)
        tmp7 = tmp6.to(tl.float32)
        tmp9 = tmp7 * tmp8
        tmp10 = tl_math.abs(tmp9)
        tmp11 = tl.broadcast_to(tmp10, [XBLOCK, R0_BLOCK])
        _tmp12_next, _tmp12_index_next = triton_helpers.maximum_with_index(
            _tmp12, _tmp12_index, tmp11, rindex
        )
        _tmp12 = tl.where(r0_mask & xmask, _tmp12_next, _tmp12)
        _tmp12_index = tl.where(r0_mask & xmask, _tmp12_index_next, _tmp12_index)
    tmp12_val, tmp12_idx = triton_helpers.max_with_index(_tmp12, _tmp12_index, 1)
    tmp12 = tmp12_val[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr0 + (r0_1 + 37888*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp21 = tl.load(in_ptr0 + (18944 + r0_1 + 37888*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = -tmp14
        tmp16 = libdevice.exp(tmp15)
        tmp17 = tl.full([1, 1], 1.0, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = (tmp14 / tmp18)
        tmp20 = tmp19.to(tl.float32)
        tmp22 = tmp20 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp12.to(tl.float32)
        tmp25 = tl.full([1, 1], 0.002232142857142857, tl.float32)
        tmp26 = tmp24 * tmp25
        tmp27 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
        tmp28 = triton_helpers.maximum(tmp26, tmp27)
        tmp29 = (tmp17 / tmp28)
        tmp30 = tmp23 * tmp29
        tmp31 = tl.full([1, 1], -448.0, tl.float32)
        tmp32 = triton_helpers.maximum(tmp30, tmp31)
        tmp33 = tl.full([1, 1], 448.0, tl.float32)
        tmp34 = triton_helpers.minimum(tmp32, tmp33)
        tmp35 = tmp34.to(tl.float8e4nv)
        tl.store(out_ptr1 + (r0_1 + 18944*x0), tmp35, r0_mask & xmask)
    tmp36 = tmp12.to(tl.float32)
    tmp37 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp38 = tmp36 * tmp37
    tmp39 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
    tmp40 = triton_helpers.maximum(tmp38, tmp39)
    tl.store(out_ptr2 + (x0), tmp40, xmask)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/6g/c6gdha5n7vmxfd66fhcrjfnbc3lkfzazti5k6t52q4h4okqkuhq7.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, fused_add_rms_norm_maybe_inplace_1], Original ATen: [vllm_ir.fused_add_rms_norm]
# Source node to ATen node mapping:
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_6
#   fused_add_rms_norm_maybe_inplace_1 => add_tensor, add_tensor_1, convert_element_type_default, convert_element_type_default_1, convert_element_type_default_3, mean_dim, mul_tensor, mul_tensor_1, pow_tensor_scalar, rsqrt_default
# Graph fragment:
#   %buf21 : Tensor  = PlaceHolder[target=buf21]
#   %buf6 : Tensor  = PlaceHolder[target=buf6]
#   %arg5_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %buf22 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf22]
#   %arg10_1 : Tensor "bf16[3584][1]cuda:0" = PlaceHolder[target=arg10_1]
#   %convert_element_type_default_4 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %convert_element_type_default_6 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor_2, torch.bfloat16), kwargs = {})
#   %convert_element_type_default : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty_2, torch.float32), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%convert_element_type_default_6, torch.float32), kwargs = {})
#   %add_tensor : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default, %convert_element_type_default_1), kwargs = {})
#   %pow_tensor_scalar : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor, 2), kwargs = {})
#   %mean_dim : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar, [-1], True), kwargs = {})
#   %add_tensor_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim, 1e-06), kwargs = {})
#   %rsqrt_default : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_1,), kwargs = {})
#   %mul_tensor : Tensor "f32[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor, %rsqrt_default), kwargs = {})
#   %convert_element_type_default_3 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor, torch.bfloat16), kwargs = {})
#   %mul_tensor_1 : Tensor "bf16[s72, 3584][3584, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_3, %arg10_1), kwargs = {})
#   return %buf22,%mul_tensor_1
triton_red_fused_fused_add_rms_norm_3 = async_compile.triton('triton_red_fused_fused_add_rms_norm_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 4096},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_fused_add_rms_norm_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 7, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 352328704}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.234888192, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_fused_add_rms_norm_3(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 3584
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp12 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp4 = tl.load(in_ptr2 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp3 + tmp5
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp1 + tmp8
        tmp10 = tmp9 * tmp9
        tmp11 = tl.broadcast_to(tmp10, [XBLOCK, R0_BLOCK])
        tmp13 = _tmp12 + tmp11
        _tmp12 = tl.where(r0_mask & xmask, tmp13, _tmp12)
    tmp12 = tl.sum(_tmp12, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp14 = tl.load(in_ptr0 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp16 = tl.load(in_ptr1 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp18 = tl.load(in_ptr2 + (r0_1 + 3584*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp31 = tl.load(in_ptr3 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp15 = tmp14.to(tl.float32)
        tmp17 = tmp16.to(tl.float32)
        tmp19 = tmp18.to(tl.float32)
        tmp20 = tmp17 + tmp19
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tmp21.to(tl.float32)
        tmp23 = tmp15 + tmp22
        tmp24 = tl.full([1, 1], 3584.0, tl.float32)
        tmp25 = (tmp12 / tmp24)
        tmp26 = tl.full([1, 1], 1e-06, tl.float32)
        tmp27 = tmp25 + tmp26
        tmp28 = libdevice.rsqrt(tmp27)
        tmp29 = tmp23 * tmp28
        tmp30 = tmp29.to(tl.float32)
        tmp32 = tmp30 * tmp31
        tl.store(out_ptr1 + (r0_1 + 3584*x0), tmp32, r0_mask & xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1 = args
        args.clear()
        s72 = arg1_1
        s80 = s72
        assert_size_stride(arg0_1, (s72, 28, 128), (3584, 128, 1), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            buf3 = empty_strided_cuda((s72, 3584), (3584, 1), torch.float8_e4m3fn)
            buf4 = empty_strided_cuda((s72, 1), (1, 1), torch.float32)
            # Topologically Sorted Source Nodes: [view, abs_1, max_1, to_1, unsqueeze, to, truediv, clamp, reciprocal, mul, clamp_1, to_3, cutlass_scaled_mm], Original ATen: [aten.view, aten.abs, aten.max, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_unsqueeze_view_0.run(arg0_1, buf3, buf4, s72, 3584, stream=raw_stream0)
            del arg0_1
            buf2 = empty_strided_cuda((s72, 3584), (3584, 1), torch.bfloat16)
            assert_size_stride(arg2_1, (3584, 3584), (1, 3584), 'input')
            assert_size_stride(arg3_1, (1, ), (1, ), 'input')
            arg2_1 = copy_if_misaligned(arg2_1)
            arg3_1 = copy_if_misaligned(arg3_1)
            # Topologically Sorted Source Nodes: [view, to_1, unsqueeze, to, truediv, clamp, reciprocal, mul, clamp_1, to_3, cutlass_scaled_mm], Original ATen: [aten.view, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
            torch.ops._C.cutlass_scaled_mm.default(buf2, buf3, arg2_1, buf4, arg3_1, None)
            del arg2_1
            del arg3_1
            assert_size_stride(arg5_1, (s72, 3584), (3584, 1), 'input')
            assert_size_stride(arg4_1, (3584, ), (1, ), 'input')
            arg5_1 = copy_if_misaligned(arg5_1)
            arg4_1 = copy_if_misaligned(arg4_1)
            buf11 = buf3; del buf3  # reuse
            buf12 = buf4; del buf4  # reuse
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, abs_2, max_2, to_5, unsqueeze_1, to_4, truediv_1, clamp_2, reciprocal_1, mul_1, clamp_3, to_7, cutlass_scaled_mm_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten.abs, aten.max, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_fused_add_rms_norm_max_mul_reciprocal_unsqueeze_1.run(buf2, arg5_1, arg4_1, buf11, buf12, s72, 3584, stream=raw_stream0)
            del arg4_1
            buf10 = empty_strided_cuda((s72, 37888), (37888, 1), torch.bfloat16)
            assert_size_stride(arg6_1, (3584, 37888), (1, 3584), 'input')
            assert_size_stride(arg7_1, (1, ), (1, ), 'input')
            arg6_1 = copy_if_misaligned(arg6_1)
            arg7_1 = copy_if_misaligned(arg7_1)
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, to_5, unsqueeze_1, to_4, truediv_1, clamp_2, reciprocal_1, mul_1, clamp_3, to_7, cutlass_scaled_mm_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, aten.mul, _C.cutlass_scaled_mm]
            torch.ops._C.cutlass_scaled_mm.default(buf10, buf11, arg6_1, buf12, arg7_1, None)
            del arg6_1
            del arg7_1
            del buf11
            buf18 = empty_strided_cuda((s72, 18944), (18944, 1), torch.float8_e4m3fn)
            buf19 = buf12; del buf12  # reuse
            # Topologically Sorted Source Nodes: [silu, mul_2, abs_3, max_3, to_9, unsqueeze_2, to_8, truediv_2, clamp_4, reciprocal_2, mul_3, clamp_5, to_11, cutlass_scaled_mm_2], Original ATen: [aten.slice, aten.silu, aten.mul, aten.abs, aten.max, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, _C.cutlass_scaled_mm]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_2.run(buf10, buf18, buf19, s72, 18944, stream=raw_stream0)
            del buf10
            buf17 = empty_strided_cuda((s72, 3584), (3584, 1), torch.bfloat16)
            assert_size_stride(arg8_1, (18944, 3584), (1, 18944), 'input')
            assert_size_stride(arg9_1, (1, ), (1, ), 'input')
            arg8_1 = copy_if_misaligned(arg8_1)
            arg9_1 = copy_if_misaligned(arg9_1)
            # Topologically Sorted Source Nodes: [silu, mul_2, to_9, unsqueeze_2, to_8, truediv_2, clamp_4, reciprocal_2, mul_3, clamp_5, to_11, cutlass_scaled_mm_2], Original ATen: [aten.slice, aten.silu, aten.mul, aten._to_copy, aten.unsqueeze, aten.div, aten.clamp, aten.reciprocal, _C.cutlass_scaled_mm]
            torch.ops._C.cutlass_scaled_mm.default(buf17, buf18, arg8_1, buf19, arg9_1, None)
            del arg8_1
            del arg9_1
            del buf18
            del buf19
            assert_size_stride(arg10_1, (3584, ), (1, ), 'input')
            arg10_1 = copy_if_misaligned(arg10_1)
            buf23 = empty_strided_cuda((s72, 3584), (3584, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, fused_add_rms_norm_maybe_inplace_1], Original ATen: [vllm_ir.fused_add_rms_norm]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_fused_add_rms_norm_3.run(buf17, buf2, arg5_1, arg10_1, buf23, s72, 3584, stream=raw_stream0)
            del arg10_1
            del arg5_1
            del buf17
            del buf2
        return (buf23, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((16384, 28, 128), (3584, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg1_1 = 16384
    arg2_1 = rand_strided((3584, 3584), (1, 3584), device='cuda:0', dtype=torch.float8_e4m3fn)
    arg3_1 = rand_strided((1, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg4_1 = rand_strided((3584, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg5_1 = rand_strided((16384, 3584), (3584, 1), device='cuda:0', dtype=torch.bfloat16)
    arg6_1 = rand_strided((3584, 37888), (1, 3584), device='cuda:0', dtype=torch.float8_e4m3fn)
    arg7_1 = rand_strided((1, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg8_1 = rand_strided((18944, 3584), (1, 18944), device='cuda:0', dtype=torch.float8_e4m3fn)
    arg9_1 = rand_strided((1, ), (1, ), device='cuda:0', dtype=torch.float32)
    arg10_1 = rand_strided((3584, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
