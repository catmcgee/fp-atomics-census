
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 32768},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr1': '*fp8e4nv', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 131072, 'r0_': 620756992}, 'add_persistent_rblock': True, 'kernel_num_gb': 0.310444032, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused__to_copy_abs_clamp_cutlass_scaled_mm_div_max_mul_reciprocal_silu_slice_unsqueeze_2(in_ptr0, out_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 18944
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp12 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    _tmp12_index = tl.full([XBLOCK, R0_BLOCK], 2147483647, tl.int32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 37888*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp8 = tl.load(in_ptr0 + (18944 + r0_1 + 37888*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = -tmp1
        tmp3 = libdevice.exp(tmp2)
        tmp4 = tl.full([1, 1], 1.0, tl.float32)
        tmp5 = tmp3 + tmp4
        tmp6 = (tmp1 / tmp5)
        tmp7 = tmp6.to(tl.float32)
        tmp9 = tmp7 * tmp8
        tmp10 = tl_math.abs(tmp9)
        tmp11 = tl.broadcast_to(tmp10, [XBLOCK, R0_BLOCK])
        _tmp12_next, _tmp12_index_next = triton_helpers.maximum_with_index(
            _tmp12, _tmp12_index, tmp11, rindex
        )
        _tmp12 = tl.where(r0_mask & xmask, _tmp12_next, _tmp12)
        _tmp12_index = tl.where(r0_mask & xmask, _tmp12_index_next, _tmp12_index)
    tmp12_val, tmp12_idx = triton_helpers.max_with_index(_tmp12, _tmp12_index, 1)
    tmp12 = tmp12_val[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp13 = tl.load(in_ptr0 + (r0_1 + 37888*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp21 = tl.load(in_ptr0 + (18944 + r0_1 + 37888*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = -tmp14
        tmp16 = libdevice.exp(tmp15)
        tmp17 = tl.full([1, 1], 1.0, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = (tmp14 / tmp18)
        tmp20 = tmp19.to(tl.float32)
        tmp22 = tmp20 * tmp21
        tmp23 = tmp22.to(tl.float32)
        tmp24 = tmp12.to(tl.float32)
        tmp25 = tl.full([1, 1], 0.002232142857142857, tl.float32)
        tmp26 = tmp24 * tmp25
        tmp27 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
        tmp28 = triton_helpers.maximum(tmp26, tmp27)
        tmp29 = (tmp17 / tmp28)
        tmp30 = tmp23 * tmp29
        tmp31 = tl.full([1, 1], -448.0, tl.float32)
        tmp32 = triton_helpers.maximum(tmp30, tmp31)
        tmp33 = tl.full([1, 1], 448.0, tl.float32)
        tmp34 = triton_helpers.minimum(tmp32, tmp33)
        tmp35 = tmp34.to(tl.float8e4nv)
        tl.store(out_ptr1 + (r0_1 + 18944*x0), tmp35, r0_mask & xmask)
    tmp36 = tmp12.to(tl.float32)
    tmp37 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp38 = tmp36 * tmp37
    tmp39 = tl.full([1, 1], 4.359654017857143e-06, tl.float32)
    tmp40 = triton_helpers.maximum(tmp38, tmp39)
    tl.store(out_ptr2 + (x0), tmp40, xmask)
