
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

from torch._dynamo.testing import rand_strided
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import torch

@triton_heuristics.reduction(
    size_hints={'x': 524288, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*i64', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'out_ptr3': '*bf16', 'xnumel_0': 'i32', 'xnumel_1': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'SequentialComboKernelGrid', 'combo_grid_meta': {'num_kernels': 2, 'min_blocks': None, 'autotune_grouping': True, 'default_config': None, 'no_x_dim_0': False, 'xnumel_0': None, 'no_x_dim_1': False, 'xnumel_1': None}, 'kernel_name': 'triton_red_fused_1', 'mutated_arg_names': [], 'optimize_mem': True, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_1(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, out_ptr3, xnumel_0, xnumel_1, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    pid = tl.program_id(0)
    num_xblocks_0 = tl.cdiv(xnumel_0, XBLOCK)
    num_xblocks_1 = num_xblocks_0 + tl.cdiv(xnumel_1, XBLOCK)
    if pid < num_xblocks_0:
        pid_offset = pid
        r0_numel = 128
        rnumel = r0_numel
        RBLOCK: tl.constexpr = R0_BLOCK
        xoffset = pid_offset * XBLOCK
        xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
        xmask = xindex < xnumel_0
        r0_base = tl.arange(0, R0_BLOCK)[None, :]
        rbase = r0_base
        x0 = (xindex % 32)
        x1 = xindex // 32
        _tmp4 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
        x3 = xindex
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_2 = r0_index
            tmp0 = tl.load(in_ptr0 + (r0_2 + 128*x0 + 6144*x1), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp1 = tmp0.to(tl.float32)
            tmp2 = tmp1 * tmp1
            tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
            tmp5 = _tmp4 + tmp3
            _tmp4 = tl.where(r0_mask & xmask, tmp5, _tmp4)
        tmp4 = tl.sum(_tmp4, 1)[:, None]
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_2 = r0_index
            tmp6 = (r0_2).to(tl.int32)
            tmp7 = tl.full([1, 1], 0, tl.int64)
            tmp8 = tmp6 >= tmp7
            tmp9 = (r0_2).to(tl.int64)
            tmp10 = (tmp9).to(tl.int64)
            tmp11 = tl.full([1, 1], 64, tl.int64)
            tmp12 = tmp10 < tmp11
            tmp13 = tl.load(in_ptr0 + (128*x0 + 6144*x1 + (r0_2)), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp14 = tmp13.to(tl.float32)
            tmp15 = tl.full([1, 1], 128.0, tl.float32)
            tmp16 = (tmp4 / tmp15)
            tmp17 = tl.full([1, 1], 1e-06, tl.float32)
            tmp18 = tmp16 + tmp17
            tmp19 = libdevice.rsqrt(tmp18)
            tmp20 = tmp14 * tmp19
            tmp21 = tmp20.to(tl.float32)
            tmp22 = tl.load(in_ptr1 + (tl.broadcast_to(r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp23 = tmp21 * tmp22
            tmp24 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0)
            tmp25 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp26 = tmp24 + tmp25
            tmp27 = tmp24 < 0
            tmp28 = tl.where(tmp27, tmp26, tmp24)
            tl.device_assert(((0 <= tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp12 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK]) < 40960")
            tmp30 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp28 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp31 = tmp23 * tmp30
            tmp32 = tl.load(in_ptr0 + (64 + 128*x0 + 6144*x1 + (r0_2)), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp33 = tmp32.to(tl.float32)
            tmp34 = tmp33 * tmp19
            tmp35 = tmp34.to(tl.float32)
            tmp36 = tl.load(in_ptr1 + (tl.broadcast_to(64 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp37 = tmp35 * tmp36
            tmp38 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp28 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp39 = tmp37 * tmp38
            tmp40 = tmp31 - tmp39
            tmp41 = tl.full(tmp40.shape, 0.0, tmp40.dtype)
            tmp42 = tl.where(tmp12, tmp40, tmp41)
            tmp43 = tmp6 >= tmp11
            tmp44 = tl.full([1, 1], 128, tl.int64)
            tmp45 = tmp6 < tmp44
            tmp46 = tl.load(in_ptr0 + (64 + 128*x0 + 6144*x1 + ((-64) + r0_2)), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp47 = tmp46.to(tl.float32)
            tmp48 = tl.full([1, 1], 128.0, tl.float32)
            tmp49 = (tmp4 / tmp48)
            tmp50 = tl.full([1, 1], 1e-06, tl.float32)
            tmp51 = tmp49 + tmp50
            tmp52 = libdevice.rsqrt(tmp51)
            tmp53 = tmp47 * tmp52
            tmp54 = tmp53.to(tl.float32)
            tmp55 = tl.load(in_ptr1 + (tl.broadcast_to(64 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp56 = tmp54 * tmp55
            tmp57 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0)
            tmp58 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp59 = tmp57 + tmp58
            tmp60 = tmp57 < 0
            tmp61 = tl.where(tmp60, tmp59, tmp57)
            tl.device_assert(((0 <= tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp43 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK]) < 40960")
            tmp63 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp61 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp64 = tmp56 * tmp63
            tmp65 = tl.load(in_ptr0 + (128*x0 + 6144*x1 + ((-64) + r0_2)), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp66 = tmp65.to(tl.float32)
            tmp67 = tmp66 * tmp52
            tmp68 = tmp67.to(tl.float32)
            tmp69 = tl.load(in_ptr1 + (tl.broadcast_to((-64) + r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp70 = tmp68 * tmp69
            tmp71 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp61 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp72 = tmp70 * tmp71
            tmp73 = tmp64 + tmp72
            tmp74 = tl.full(tmp73.shape, 0.0, tmp73.dtype)
            tmp75 = tl.where(tmp43, tmp73, tmp74)
            tmp76 = tl.where(tmp12, tmp42, tmp75)
            tl.store(out_ptr1 + (r0_2 + 128*x3), tmp76, r0_mask & xmask)
    elif pid < num_xblocks_1:
        pid_offset = pid - num_xblocks_0
        r0_numel = 128
        rnumel = r0_numel
        RBLOCK: tl.constexpr = R0_BLOCK
        xoffset = pid_offset * XBLOCK
        xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
        xmask = xindex < xnumel_1
        r0_base = tl.arange(0, R0_BLOCK)[None, :]
        rbase = r0_base
        x4 = (xindex % 8)
        x5 = xindex // 8
        _tmp81 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
        x7 = xindex
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_6 = r0_index
            tmp77 = tl.load(in_ptr0 + (4096 + r0_6 + 128*x4 + 6144*x5), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp78 = tmp77.to(tl.float32)
            tmp79 = tmp78 * tmp78
            tmp80 = tl.broadcast_to(tmp79, [XBLOCK, R0_BLOCK])
            tmp82 = _tmp81 + tmp80
            _tmp81 = tl.where(r0_mask & xmask, tmp82, _tmp81)
        tmp81 = tl.sum(_tmp81, 1)[:, None]
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_6 = r0_index
            tmp83 = (r0_6).to(tl.int32)
            tmp84 = tl.full([1, 1], 0, tl.int64)
            tmp85 = tmp83 >= tmp84
            tmp86 = (r0_6).to(tl.int64)
            tmp87 = (tmp86).to(tl.int64)
            tmp88 = tl.full([1, 1], 64, tl.int64)
            tmp89 = tmp87 < tmp88
            tmp90 = tl.load(in_ptr0 + (4096 + 128*x4 + 6144*x5 + (r0_6)), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp91 = tmp90.to(tl.float32)
            tmp92 = tl.full([1, 1], 128.0, tl.float32)
            tmp93 = (tmp81 / tmp92)
            tmp94 = tl.full([1, 1], 1e-06, tl.float32)
            tmp95 = tmp93 + tmp94
            tmp96 = libdevice.rsqrt(tmp95)
            tmp97 = tmp91 * tmp96
            tmp98 = tmp97.to(tl.float32)
            tmp99 = tl.load(in_ptr4 + (tl.broadcast_to(r0_6, [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp100 = tmp98 * tmp99
            tmp101 = tl.load(in_ptr2 + (tl.broadcast_to(x5, [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0)
            tmp102 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp103 = tmp101 + tmp102
            tmp104 = tmp101 < 0
            tmp105 = tl.where(tmp104, tmp103, tmp101)
            tl.device_assert(((0 <= tl.broadcast_to(tmp105, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp105, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp89 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp105, [XBLOCK, R0_BLOCK]) < 40960")
            tmp107 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp105 + (r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp108 = tmp100 * tmp107
            tmp109 = tl.load(in_ptr0 + (4160 + 128*x4 + 6144*x5 + (r0_6)), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp110 = tmp109.to(tl.float32)
            tmp111 = tmp110 * tmp96
            tmp112 = tmp111.to(tl.float32)
            tmp113 = tl.load(in_ptr4 + (tl.broadcast_to(64 + (r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp114 = tmp112 * tmp113
            tmp115 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp105 + (r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp116 = tmp114 * tmp115
            tmp117 = tmp108 - tmp116
            tmp118 = tl.full(tmp117.shape, 0.0, tmp117.dtype)
            tmp119 = tl.where(tmp89, tmp117, tmp118)
            tmp120 = tmp83 >= tmp88
            tmp121 = tl.full([1, 1], 128, tl.int64)
            tmp122 = tmp83 < tmp121
            tmp123 = tl.load(in_ptr0 + (4160 + 128*x4 + 6144*x5 + ((-64) + r0_6)), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp124 = tmp123.to(tl.float32)
            tmp125 = tl.full([1, 1], 128.0, tl.float32)
            tmp126 = (tmp81 / tmp125)
            tmp127 = tl.full([1, 1], 1e-06, tl.float32)
            tmp128 = tmp126 + tmp127
            tmp129 = libdevice.rsqrt(tmp128)
            tmp130 = tmp124 * tmp129
            tmp131 = tmp130.to(tl.float32)
            tmp132 = tl.load(in_ptr4 + (tl.broadcast_to(64 + ((-64) + r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp133 = tmp131 * tmp132
            tmp134 = tl.load(in_ptr2 + (tl.broadcast_to(x5, [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0)
            tmp135 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp136 = tmp134 + tmp135
            tmp137 = tmp134 < 0
            tmp138 = tl.where(tmp137, tmp136, tmp134)
            tl.device_assert(((0 <= tl.broadcast_to(tmp138, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp138, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp120 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp138, [XBLOCK, R0_BLOCK]) < 40960")
            tmp140 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp138 + ((-64) + r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp141 = tmp133 * tmp140
            tmp142 = tl.load(in_ptr0 + (4096 + 128*x4 + 6144*x5 + ((-64) + r0_6)), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp143 = tmp142.to(tl.float32)
            tmp144 = tmp143 * tmp129
            tmp145 = tmp144.to(tl.float32)
            tmp146 = tl.load(in_ptr4 + (tl.broadcast_to((-64) + r0_6, [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp147 = tmp145 * tmp146
            tmp148 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp138 + ((-64) + r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp149 = tmp147 * tmp148
            tmp150 = tmp141 + tmp149
            tmp151 = tl.full(tmp150.shape, 0.0, tmp150.dtype)
            tmp152 = tl.where(tmp120, tmp150, tmp151)
            tmp153 = tl.where(tmp89, tmp119, tmp152)
            tl.store(out_ptr3 + (r0_6 + 128*x7), tmp153, r0_mask & xmask)
    else:
        pass


def get_args():
    arg_0 = rand_strided((16384, 6144), (6144, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_1 = rand_strided((128,), (1,), device='cuda:0', dtype=torch.bfloat16)
    arg_2 = rand_strided((16384,), (1,), device='cuda:0', dtype=torch.int64)
    arg_3 = rand_strided((40960, 128), (128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_4 = rand_strided((128,), (1,), device='cuda:0', dtype=torch.bfloat16)
    arg_5 = rand_strided((16384, 32, 128), (4096, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_6 = rand_strided((16384, 8, 128), (1024, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    return arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, 524288, 131072,


def call(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_1.run(*args, stream=raw_stream0)


def benchmark_all_configs(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        return triton_red_fused_1.benchmark_all_configs(*args)


if __name__ == '__main__':
    from torch._inductor.runtime.benchmarking import benchmarker

    args = get_args()
    ms = benchmarker.benchmark(call, fn_args=(args,), device='cuda',rep=40)
    num_gb = 0.189006336
    gb_per_s = num_gb / (ms / 1e3)
    print(f"{ms:.3f}ms    {num_gb:.3f}GB    {gb_per_s:.2f}GB/s")
