
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

from torch._dynamo.testing import rand_strided
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import torch

@triton_heuristics.reduction(
    size_hints={'x': 131072, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*i64', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'Placeholder.DESCRIPTIVE_NAME', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 11, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'kernel_num_gb': 0.04417152, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 128
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = (xindex % 8)
    x1 = xindex // 8
    _tmp4 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    x3 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp0 = tl.load(in_ptr0 + (4096 + r0_2 + 128*x0 + 6144*x1), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp2 = tmp1 * tmp1
        tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
        tmp5 = _tmp4 + tmp3
        _tmp4 = tl.where(r0_mask & xmask, tmp5, _tmp4)
    tmp4 = tl.sum(_tmp4, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_2 = r0_index
        tmp6 = (r0_2).to(tl.int32)
        tmp7 = tl.full([1, 1], 0, tl.int64)
        tmp8 = tmp6 >= tmp7
        tmp9 = (r0_2).to(tl.int64)
        tmp10 = (tmp9).to(tl.int64)
        tmp11 = tl.full([1, 1], 64, tl.int64)
        tmp12 = tmp10 < tmp11
        tmp13 = tl.load(in_ptr0 + (4096 + 128*x0 + 6144*x1 + (r0_2)), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp14 = tmp13.to(tl.float32)
        tmp15 = tl.full([1, 1], 128.0, tl.float32)
        tmp16 = (tmp4 / tmp15)
        tmp17 = tl.full([1, 1], 1e-06, tl.float32)
        tmp18 = tmp16 + tmp17
        tmp19 = libdevice.rsqrt(tmp18)
        tmp20 = tmp14 * tmp19
        tmp21 = tmp20.to(tl.float32)
        tmp22 = tl.load(in_ptr1 + (tl.broadcast_to(r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp23 = tmp21 * tmp22
        tmp24 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0)
        tmp25 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
        tmp26 = tmp24 + tmp25
        tmp27 = tmp24 < 0
        tmp28 = tl.where(tmp27, tmp26, tmp24)
        tl.device_assert(((0 <= tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp12 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK]) < 40960")
        tmp30 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp28 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp31 = tmp23 * tmp30
        tmp32 = tl.load(in_ptr0 + (4160 + 128*x0 + 6144*x1 + (r0_2)), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp33 = tmp32.to(tl.float32)
        tmp34 = tmp33 * tmp19
        tmp35 = tmp34.to(tl.float32)
        tmp36 = tl.load(in_ptr1 + (tl.broadcast_to(64 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp37 = tmp35 * tmp36
        tmp38 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp28 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp39 = tmp37 * tmp38
        tmp40 = tmp31 - tmp39
        tmp41 = tl.full(tmp40.shape, 0.0, tmp40.dtype)
        tmp42 = tl.where(tmp12, tmp40, tmp41)
        tmp43 = tmp6 >= tmp11
        tmp44 = tl.full([1, 1], 128, tl.int64)
        tmp45 = tmp6 < tmp44
        tmp46 = tl.load(in_ptr0 + (4160 + 128*x0 + 6144*x1 + ((-64) + r0_2)), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp47 = tmp46.to(tl.float32)
        tmp48 = tl.full([1, 1], 128.0, tl.float32)
        tmp49 = (tmp4 / tmp48)
        tmp50 = tl.full([1, 1], 1e-06, tl.float32)
        tmp51 = tmp49 + tmp50
        tmp52 = libdevice.rsqrt(tmp51)
        tmp53 = tmp47 * tmp52
        tmp54 = tmp53.to(tl.float32)
        tmp55 = tl.load(in_ptr1 + (tl.broadcast_to(64 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp56 = tmp54 * tmp55
        tmp57 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0)
        tmp58 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
        tmp59 = tmp57 + tmp58
        tmp60 = tmp57 < 0
        tmp61 = tl.where(tmp60, tmp59, tmp57)
        tl.device_assert(((0 <= tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp43 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK]) < 40960")
        tmp63 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp61 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp64 = tmp56 * tmp63
        tmp65 = tl.load(in_ptr0 + (4096 + 128*x0 + 6144*x1 + ((-64) + r0_2)), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp66 = tmp65.to(tl.float32)
        tmp67 = tmp66 * tmp52
        tmp68 = tmp67.to(tl.float32)
        tmp69 = tl.load(in_ptr1 + (tl.broadcast_to((-64) + r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp70 = tmp68 * tmp69
        tmp71 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp61 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp72 = tmp70 * tmp71
        tmp73 = tmp64 + tmp72
        tmp74 = tl.full(tmp73.shape, 0.0, tmp73.dtype)
        tmp75 = tl.where(tmp43, tmp73, tmp74)
        tmp76 = tl.where(tmp12, tmp42, tmp75)
        tl.store(out_ptr1 + (r0_2 + 128*x3), tmp76, r0_mask & xmask)


def get_args():
    arg_0 = rand_strided((16384, 6144), (6144, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_1 = rand_strided((128,), (1,), device='cuda:0', dtype=torch.bfloat16)
    arg_2 = rand_strided((16384,), (1,), device='cuda:0', dtype=torch.int64)
    arg_3 = rand_strided((40960, 128), (128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_4 = rand_strided((16384, 8, 128), (1024, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    return arg_0, arg_1, arg_2, arg_3, arg_4, 131072, 128,


def call(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        raw_stream0 = get_raw_stream(0)
        triton_.run(*args, stream=raw_stream0)


def benchmark_all_configs(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        return triton_.benchmark_all_configs(*args)


if __name__ == '__main__':
    from torch._inductor.runtime.benchmarking import benchmarker

    args = get_args()
    ms = benchmarker.benchmark(lambda: call(args), device='cuda', rep=40)
    num_gb = 0.04417152
    gb_per_s = num_gb / (ms / 1e3)
    print(f"{ms:.3f}ms    {num_gb:.3f}GB    {gb_per_s:.2f}GB/s")
