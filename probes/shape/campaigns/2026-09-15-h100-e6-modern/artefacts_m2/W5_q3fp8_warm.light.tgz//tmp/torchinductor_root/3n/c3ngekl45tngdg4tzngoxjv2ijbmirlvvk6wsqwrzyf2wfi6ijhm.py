
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 33554432}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp8e4nv', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'ks3': 'i64', 'ks4': 'i64', 'ks5': 'i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_view_zeros_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 151001088}, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=2
)
@triton.jit
def triton_poi_fused__to_copy_abs_ceil_clamp_div_log2_mul_pow_reciprocal_view_zeros_1(in_ptr0, in_ptr1, out_ptr0, ks0, ks1, ks2, ks3, ks4, ks5, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x5 = xindex // ks0
    x4 = (xindex % ks0)
    x1 = ((xindex // ks4) % ks3)
    x3 = xindex // ks5
    x6 = xindex
    tmp8 = tl.load(in_ptr1 + (x1 + (-1)*x3*(triton_helpers.div_floor_integer(ks2,  (-1)*ks4))), xmask, eviction_policy='evict_last')
    tmp0 = (x5).to(tl.int64)
    tmp1 = (tmp0).to(tl.int64)
    tmp2 = (ks1).to(tl.int64)
    tmp3 = (tmp2).to(tl.int64)
    tmp4 = tmp1 < tmp3
    tmp5 = tl.load(in_ptr0 + (x4 + ks2*x5), tmp4 & xmask, eviction_policy='evict_last', other=0.0)
    tmp6 = tl.full([1], 0.0, tl.float32)
    tmp7 = tl.where(tmp4, tmp5, tmp6)
    tmp9 = tl.full([1], 0.0001, tl.float32)
    tmp10 = triton_helpers.maximum(tmp8, tmp9)
    tmp11 = tl.full([1], 0.002232142857142857, tl.float32)
    tmp12 = tmp10 * tmp11
    tmp13 = tl_math.abs(tmp12)
    tmp14 = libdevice.log2(tmp13)
    tmp15 = libdevice.ceil(tmp14)
    tmp16 = libdevice.exp2(tmp15)
    tmp17 = tl.full([1], 1.0, tl.float32)
    tmp18 = (tmp17 / tmp16)
    tmp19 = tmp18 * tmp17
    tmp20 = tmp7 * tmp19
    tmp21 = tmp20.to(tl.float8e4nv)
    tl.store(out_ptr0 + (x6), tmp21, xmask)
