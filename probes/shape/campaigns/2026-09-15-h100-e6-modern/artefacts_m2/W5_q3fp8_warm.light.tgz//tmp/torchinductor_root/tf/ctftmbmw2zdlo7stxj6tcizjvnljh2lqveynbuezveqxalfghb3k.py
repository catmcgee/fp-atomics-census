r"""
Compile-time auto-tuning block: 

import torch
from math import inf, nan
from torch._dynamo.testing import rand_strided
from torch._dynamo.utils import preserve_rng_state
from torch._inductor.select_algorithm import AlgorithmSelectorCache
from torch._inductor.async_compile import AsyncCompile

async_compile = AsyncCompile()
generate_example_value = AlgorithmSelectorCache.generate_example_value
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
get_raw_stream = torch._C._cuda_getCurrentRawStream


# kernel path: /tmp/torchinductor_root/m7/cm7vbnnz3w77nj4xjh375vhstvjl3nqp7bqvjwrhvzuwbo433nh7.py
# Topologically Sorted Source Nodes: [long, embedding], Original ATen: [aten._to_copy, aten.embedding]
# Source node to ATen node mapping:
#   embedding => embedding
#   long => convert_element_type
# Graph fragment:
#   %arg0_1 : Tensor "i32[s72][1]cuda:0" = PlaceHolder[target=arg0_1]
#   %arg2_1 : Tensor "bf16[151936, 4096][4096, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %convert_element_type : Tensor "i64[s72][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.int64), kwargs = {})
#   %embedding : Tensor "bf16[s72, 4096][4096, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %convert_element_type), kwargs = {})
#   return %embedding
triton_poi_fused__to_copy_embedding_0 = async_compile.triton('triton_poi_fused__to_copy_embedding_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 67108864}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i32', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_embedding_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 268500992}, 'kernel_num_gb': 0.268500992, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_embedding_0(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = xindex // 4096
    x0 = (xindex % 4096)
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last')
    tmp1 = tmp0.to(tl.int64)
    tl.device_assert((0 <= tmp1) & (tmp1 < 151936), "index out of bounds: 0 <= tmp1 < 151936")
    tmp3 = tl.load(in_ptr1 + (x0 + 4096*tmp1), None).to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp3, None)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/aq/caqz2v2cty5sj5phwbcavkgv7a34rjku62ckj5yddhdzkhwefvca.py
# Unsorted Source Nodes: [], Original ATen: []
# Source node to ATen node mapping:
triton_red_fused_1 = async_compile.triton('triton_red_fused_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

from torch._dynamo.testing import rand_strided
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import torch

@triton_heuristics.reduction(
    size_hints={'x': 524288, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*i64', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'out_ptr3': '*bf16', 'xnumel_0': 'i32', 'xnumel_1': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'SequentialComboKernelGrid', 'combo_grid_meta': {'num_kernels': 2, 'min_blocks': None, 'autotune_grouping': True, 'default_config': None, 'no_x_dim_0': False, 'xnumel_0': None, 'no_x_dim_1': False, 'xnumel_1': None}, 'kernel_name': 'triton_red_fused_1', 'mutated_arg_names': [], 'optimize_mem': True, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_1(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, out_ptr3, xnumel_0, xnumel_1, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    pid = tl.program_id(0)
    num_xblocks_0 = tl.cdiv(xnumel_0, XBLOCK)
    num_xblocks_1 = num_xblocks_0 + tl.cdiv(xnumel_1, XBLOCK)
    if pid < num_xblocks_0:
        pid_offset = pid
        r0_numel = 128
        rnumel = r0_numel
        RBLOCK: tl.constexpr = R0_BLOCK
        xoffset = pid_offset * XBLOCK
        xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
        xmask = xindex < xnumel_0
        r0_base = tl.arange(0, R0_BLOCK)[None, :]
        rbase = r0_base
        x0 = (xindex % 32)
        x1 = xindex // 32
        _tmp4 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
        x3 = xindex
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_2 = r0_index
            tmp0 = tl.load(in_ptr0 + (r0_2 + 128*x0 + 6144*x1), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp1 = tmp0.to(tl.float32)
            tmp2 = tmp1 * tmp1
            tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
            tmp5 = _tmp4 + tmp3
            _tmp4 = tl.where(r0_mask & xmask, tmp5, _tmp4)
        tmp4 = tl.sum(_tmp4, 1)[:, None]
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_2 = r0_index
            tmp6 = (r0_2).to(tl.int32)
            tmp7 = tl.full([1, 1], 0, tl.int64)
            tmp8 = tmp6 >= tmp7
            tmp9 = (r0_2).to(tl.int64)
            tmp10 = (tmp9).to(tl.int64)
            tmp11 = tl.full([1, 1], 64, tl.int64)
            tmp12 = tmp10 < tmp11
            tmp13 = tl.load(in_ptr0 + (128*x0 + 6144*x1 + (r0_2)), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp14 = tmp13.to(tl.float32)
            tmp15 = tl.full([1, 1], 128.0, tl.float32)
            tmp16 = (tmp4 / tmp15)
            tmp17 = tl.full([1, 1], 1e-06, tl.float32)
            tmp18 = tmp16 + tmp17
            tmp19 = libdevice.rsqrt(tmp18)
            tmp20 = tmp14 * tmp19
            tmp21 = tmp20.to(tl.float32)
            tmp22 = tl.load(in_ptr1 + (tl.broadcast_to(r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp23 = tmp21 * tmp22
            tmp24 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0)
            tmp25 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp26 = tmp24 + tmp25
            tmp27 = tmp24 < 0
            tmp28 = tl.where(tmp27, tmp26, tmp24)
            tl.device_assert(((0 <= tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp12 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK]) < 40960")
            tmp30 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp28 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp31 = tmp23 * tmp30
            tmp32 = tl.load(in_ptr0 + (64 + 128*x0 + 6144*x1 + (r0_2)), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp33 = tmp32.to(tl.float32)
            tmp34 = tmp33 * tmp19
            tmp35 = tmp34.to(tl.float32)
            tmp36 = tl.load(in_ptr1 + (tl.broadcast_to(64 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp37 = tmp35 * tmp36
            tmp38 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp28 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp39 = tmp37 * tmp38
            tmp40 = tmp31 - tmp39
            tmp41 = tl.full(tmp40.shape, 0.0, tmp40.dtype)
            tmp42 = tl.where(tmp12, tmp40, tmp41)
            tmp43 = tmp6 >= tmp11
            tmp44 = tl.full([1, 1], 128, tl.int64)
            tmp45 = tmp6 < tmp44
            tmp46 = tl.load(in_ptr0 + (64 + 128*x0 + 6144*x1 + ((-64) + r0_2)), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp47 = tmp46.to(tl.float32)
            tmp48 = tl.full([1, 1], 128.0, tl.float32)
            tmp49 = (tmp4 / tmp48)
            tmp50 = tl.full([1, 1], 1e-06, tl.float32)
            tmp51 = tmp49 + tmp50
            tmp52 = libdevice.rsqrt(tmp51)
            tmp53 = tmp47 * tmp52
            tmp54 = tmp53.to(tl.float32)
            tmp55 = tl.load(in_ptr1 + (tl.broadcast_to(64 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp56 = tmp54 * tmp55
            tmp57 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0)
            tmp58 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp59 = tmp57 + tmp58
            tmp60 = tmp57 < 0
            tmp61 = tl.where(tmp60, tmp59, tmp57)
            tl.device_assert(((0 <= tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp43 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK]) < 40960")
            tmp63 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp61 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp64 = tmp56 * tmp63
            tmp65 = tl.load(in_ptr0 + (128*x0 + 6144*x1 + ((-64) + r0_2)), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp66 = tmp65.to(tl.float32)
            tmp67 = tmp66 * tmp52
            tmp68 = tmp67.to(tl.float32)
            tmp69 = tl.load(in_ptr1 + (tl.broadcast_to((-64) + r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp70 = tmp68 * tmp69
            tmp71 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp61 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp72 = tmp70 * tmp71
            tmp73 = tmp64 + tmp72
            tmp74 = tl.full(tmp73.shape, 0.0, tmp73.dtype)
            tmp75 = tl.where(tmp43, tmp73, tmp74)
            tmp76 = tl.where(tmp12, tmp42, tmp75)
            tl.store(out_ptr1 + (r0_2 + 128*x3), tmp76, r0_mask & xmask)
    elif pid < num_xblocks_1:
        pid_offset = pid - num_xblocks_0
        r0_numel = 128
        rnumel = r0_numel
        RBLOCK: tl.constexpr = R0_BLOCK
        xoffset = pid_offset * XBLOCK
        xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
        xmask = xindex < xnumel_1
        r0_base = tl.arange(0, R0_BLOCK)[None, :]
        rbase = r0_base
        x4 = (xindex % 8)
        x5 = xindex // 8
        _tmp81 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
        x7 = xindex
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_6 = r0_index
            tmp77 = tl.load(in_ptr0 + (4096 + r0_6 + 128*x4 + 6144*x5), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp78 = tmp77.to(tl.float32)
            tmp79 = tmp78 * tmp78
            tmp80 = tl.broadcast_to(tmp79, [XBLOCK, R0_BLOCK])
            tmp82 = _tmp81 + tmp80
            _tmp81 = tl.where(r0_mask & xmask, tmp82, _tmp81)
        tmp81 = tl.sum(_tmp81, 1)[:, None]
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_6 = r0_index
            tmp83 = (r0_6).to(tl.int32)
            tmp84 = tl.full([1, 1], 0, tl.int64)
            tmp85 = tmp83 >= tmp84
            tmp86 = (r0_6).to(tl.int64)
            tmp87 = (tmp86).to(tl.int64)
            tmp88 = tl.full([1, 1], 64, tl.int64)
            tmp89 = tmp87 < tmp88
            tmp90 = tl.load(in_ptr0 + (4096 + 128*x4 + 6144*x5 + (r0_6)), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp91 = tmp90.to(tl.float32)
            tmp92 = tl.full([1, 1], 128.0, tl.float32)
            tmp93 = (tmp81 / tmp92)
            tmp94 = tl.full([1, 1], 1e-06, tl.float32)
            tmp95 = tmp93 + tmp94
            tmp96 = libdevice.rsqrt(tmp95)
            tmp97 = tmp91 * tmp96
            tmp98 = tmp97.to(tl.float32)
            tmp99 = tl.load(in_ptr4 + (tl.broadcast_to(r0_6, [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp100 = tmp98 * tmp99
            tmp101 = tl.load(in_ptr2 + (tl.broadcast_to(x5, [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0)
            tmp102 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp103 = tmp101 + tmp102
            tmp104 = tmp101 < 0
            tmp105 = tl.where(tmp104, tmp103, tmp101)
            tl.device_assert(((0 <= tl.broadcast_to(tmp105, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp105, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp89 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp105, [XBLOCK, R0_BLOCK]) < 40960")
            tmp107 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp105 + (r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp108 = tmp100 * tmp107
            tmp109 = tl.load(in_ptr0 + (4160 + 128*x4 + 6144*x5 + (r0_6)), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp110 = tmp109.to(tl.float32)
            tmp111 = tmp110 * tmp96
            tmp112 = tmp111.to(tl.float32)
            tmp113 = tl.load(in_ptr4 + (tl.broadcast_to(64 + (r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp114 = tmp112 * tmp113
            tmp115 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp105 + (r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp116 = tmp114 * tmp115
            tmp117 = tmp108 - tmp116
            tmp118 = tl.full(tmp117.shape, 0.0, tmp117.dtype)
            tmp119 = tl.where(tmp89, tmp117, tmp118)
            tmp120 = tmp83 >= tmp88
            tmp121 = tl.full([1, 1], 128, tl.int64)
            tmp122 = tmp83 < tmp121
            tmp123 = tl.load(in_ptr0 + (4160 + 128*x4 + 6144*x5 + ((-64) + r0_6)), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp124 = tmp123.to(tl.float32)
            tmp125 = tl.full([1, 1], 128.0, tl.float32)
            tmp126 = (tmp81 / tmp125)
            tmp127 = tl.full([1, 1], 1e-06, tl.float32)
            tmp128 = tmp126 + tmp127
            tmp129 = libdevice.rsqrt(tmp128)
            tmp130 = tmp124 * tmp129
            tmp131 = tmp130.to(tl.float32)
            tmp132 = tl.load(in_ptr4 + (tl.broadcast_to(64 + ((-64) + r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp133 = tmp131 * tmp132
            tmp134 = tl.load(in_ptr2 + (tl.broadcast_to(x5, [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0)
            tmp135 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp136 = tmp134 + tmp135
            tmp137 = tmp134 < 0
            tmp138 = tl.where(tmp137, tmp136, tmp134)
            tl.device_assert(((0 <= tl.broadcast_to(tmp138, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp138, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp120 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp138, [XBLOCK, R0_BLOCK]) < 40960")
            tmp140 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp138 + ((-64) + r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp141 = tmp133 * tmp140
            tmp142 = tl.load(in_ptr0 + (4096 + 128*x4 + 6144*x5 + ((-64) + r0_6)), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp143 = tmp142.to(tl.float32)
            tmp144 = tmp143 * tmp129
            tmp145 = tmp144.to(tl.float32)
            tmp146 = tl.load(in_ptr4 + (tl.broadcast_to((-64) + r0_6, [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp147 = tmp145 * tmp146
            tmp148 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp138 + ((-64) + r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp149 = tmp147 * tmp148
            tmp150 = tmp141 + tmp149
            tmp151 = tl.full(tmp150.shape, 0.0, tmp150.dtype)
            tmp152 = tl.where(tmp120, tmp150, tmp151)
            tmp153 = tl.where(tmp89, tmp119, tmp152)
            tl.store(out_ptr3 + (r0_6 + 128*x7), tmp153, r0_mask & xmask)
    else:
        pass


def get_args():
    arg_0 = rand_strided((16384, 6144), (6144, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_1 = rand_strided((128,), (1,), device='cuda:0', dtype=torch.bfloat16)
    arg_2 = rand_strided((16384,), (1,), device='cuda:0', dtype=torch.int64)
    arg_3 = rand_strided((40960, 128), (128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_4 = rand_strided((128,), (1,), device='cuda:0', dtype=torch.bfloat16)
    arg_5 = rand_strided((16384, 32, 128), (4096, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_6 = rand_strided((16384, 8, 128), (1024, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    return arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, 524288, 131072,


def call(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_1.run(*args, stream=raw_stream0)


def benchmark_all_configs(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        return triton_red_fused_1.benchmark_all_configs(*args)


if __name__ == '__main__':
    from torch._inductor.runtime.benchmarking import benchmarker

    args = get_args()
    ms = benchmarker.benchmark(call, fn_args=(args,), device='cuda',rep=40)
    num_gb = 0.189006336
    gb_per_s = num_gb / (ms / 1e3)
    print(f"{ms:.3f}ms    {num_gb:.3f}GB    {gb_per_s:.2f}GB/s")
''', device_str='cuda')

async_compile.wait(globals())
del async_compile

import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
with torch.cuda._DeviceGuard(0):
    raw_stream0 = get_raw_stream(0)
raw_stream0 = get_raw_stream(0)
arg0_1 = generate_example_value((16384,), (1,), 'cuda:0', torch.int32, 0, (16384,))
arg2_1 = generate_example_value((151936, 4096), (4096, 1), 'cuda:0', torch.bfloat16, 0, (151936, 4096))
buf0 = generate_example_value((16384, 4096), (4096, 1), 'cuda:0', torch.bfloat16, 0, (16384, 4096))
with torch.cuda._DeviceGuard(0):
    triton_poi_fused__to_copy_embedding_0.run(arg0_1, arg2_1, buf0, 67108864, stream=raw_stream0)
del arg0_1, arg2_1, buf0

raw_stream0 = get_raw_stream(0)
buf6 = generate_example_value((16384, 6144), (6144, 1), 'cuda:0', torch.bfloat16, 0, (16384, 6144))
arg6_1 = generate_example_value((128,), (1,), 'cuda:0', torch.bfloat16, 0, (128,))
arg8_1 = generate_example_value((16384,), (1,), 'cuda:0', torch.int64, 0, (16384,))
arg9_1 = generate_example_value((40960, 128), (128, 1), 'cuda:0', torch.bfloat16, 0, (40960, 128))
arg7_1 = generate_example_value((128,), (1,), 'cuda:0', torch.bfloat16, 0, (128,))
buf12 = generate_example_value((16384, 32, 128), (4096, 128, 1), 'cuda:0', torch.bfloat16, 0, (16384, 32, 128))
buf11 = generate_example_value((16384, 8, 128), (1024, 128, 1), 'cuda:0', torch.bfloat16, 0, (16384, 8, 128))
with torch.cuda._DeviceGuard(0):
    triton_red_fused_1.run(buf6, arg6_1, arg8_1, arg9_1, arg7_1, buf12, buf11, 524288, 131072, stream=raw_stream0)
del buf6, arg6_1, arg8_1, arg9_1, arg7_1, buf12, buf11

"""
# AOT ID: ['1_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /tmp/torchinductor_root/m7/cm7vbnnz3w77nj4xjh375vhstvjl3nqp7bqvjwrhvzuwbo433nh7.py
# Topologically Sorted Source Nodes: [long, embedding], Original ATen: [aten._to_copy, aten.embedding]
# Source node to ATen node mapping:
#   embedding => embedding
#   long => convert_element_type
# Graph fragment:
#   %arg0_1 : Tensor "i32[s72][1]cuda:0" = PlaceHolder[target=arg0_1]
#   %arg2_1 : Tensor "bf16[151936, 4096][4096, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %convert_element_type : Tensor "i64[s72][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg0_1, torch.int64), kwargs = {})
#   %embedding : Tensor "bf16[s72, 4096][4096, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.embedding.default](args = (%arg2_1, %convert_element_type), kwargs = {})
#   return %embedding
triton_poi_fused__to_copy_embedding_0 = async_compile.triton('triton_poi_fused__to_copy_embedding_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 67108864}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i32', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused__to_copy_embedding_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 268500992}, 'kernel_num_gb': 0.268500992, 'kernel_flop': 0, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_embedding_0(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = xindex // 4096
    x0 = (xindex % 4096)
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x1), None, eviction_policy='evict_last')
    tmp1 = tmp0.to(tl.int64)
    tl.device_assert((0 <= tmp1) & (tmp1 < 151936), "index out of bounds: 0 <= tmp1 < 151936")
    tmp3 = tl.load(in_ptr1 + (x0 + 4096*tmp1), None).to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp3, None)
''', device_str='cuda')


# kernel path: /tmp/torchinductor_root/aq/caqz2v2cty5sj5phwbcavkgv7a34rjku62ckj5yddhdzkhwefvca.py
# Unsorted Source Nodes: [], Original ATen: []
# Source node to ATen node mapping:
triton_red_fused_1 = async_compile.triton('triton_red_fused_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

from torch._dynamo.testing import rand_strided
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
import torch

@triton_heuristics.reduction(
    size_hints={'x': 524288, 'r0_': 128},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*i64', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'out_ptr3': '*bf16', 'xnumel_0': 'i32', 'xnumel_1': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'SequentialComboKernelGrid', 'combo_grid_meta': {'num_kernels': 2, 'min_blocks': None, 'autotune_grouping': True, 'default_config': None, 'no_x_dim_0': False, 'xnumel_0': None, 'no_x_dim_1': False, 'xnumel_1': None}, 'kernel_name': 'triton_red_fused_1', 'mutated_arg_names': [], 'optimize_mem': True, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_1(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, out_ptr3, xnumel_0, xnumel_1, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    pid = tl.program_id(0)
    num_xblocks_0 = tl.cdiv(xnumel_0, XBLOCK)
    num_xblocks_1 = num_xblocks_0 + tl.cdiv(xnumel_1, XBLOCK)
    if pid < num_xblocks_0:
        pid_offset = pid
        r0_numel = 128
        rnumel = r0_numel
        RBLOCK: tl.constexpr = R0_BLOCK
        xoffset = pid_offset * XBLOCK
        xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
        xmask = xindex < xnumel_0
        r0_base = tl.arange(0, R0_BLOCK)[None, :]
        rbase = r0_base
        x0 = (xindex % 32)
        x1 = xindex // 32
        _tmp4 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
        x3 = xindex
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_2 = r0_index
            tmp0 = tl.load(in_ptr0 + (r0_2 + 128*x0 + 6144*x1), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp1 = tmp0.to(tl.float32)
            tmp2 = tmp1 * tmp1
            tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
            tmp5 = _tmp4 + tmp3
            _tmp4 = tl.where(r0_mask & xmask, tmp5, _tmp4)
        tmp4 = tl.sum(_tmp4, 1)[:, None]
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_2 = r0_index
            tmp6 = (r0_2).to(tl.int32)
            tmp7 = tl.full([1, 1], 0, tl.int64)
            tmp8 = tmp6 >= tmp7
            tmp9 = (r0_2).to(tl.int64)
            tmp10 = (tmp9).to(tl.int64)
            tmp11 = tl.full([1, 1], 64, tl.int64)
            tmp12 = tmp10 < tmp11
            tmp13 = tl.load(in_ptr0 + (128*x0 + 6144*x1 + (r0_2)), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp14 = tmp13.to(tl.float32)
            tmp15 = tl.full([1, 1], 128.0, tl.float32)
            tmp16 = (tmp4 / tmp15)
            tmp17 = tl.full([1, 1], 1e-06, tl.float32)
            tmp18 = tmp16 + tmp17
            tmp19 = libdevice.rsqrt(tmp18)
            tmp20 = tmp14 * tmp19
            tmp21 = tmp20.to(tl.float32)
            tmp22 = tl.load(in_ptr1 + (tl.broadcast_to(r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp23 = tmp21 * tmp22
            tmp24 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0)
            tmp25 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp26 = tmp24 + tmp25
            tmp27 = tmp24 < 0
            tmp28 = tl.where(tmp27, tmp26, tmp24)
            tl.device_assert(((0 <= tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp12 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp28, [XBLOCK, R0_BLOCK]) < 40960")
            tmp30 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp28 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp31 = tmp23 * tmp30
            tmp32 = tl.load(in_ptr0 + (64 + 128*x0 + 6144*x1 + (r0_2)), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp33 = tmp32.to(tl.float32)
            tmp34 = tmp33 * tmp19
            tmp35 = tmp34.to(tl.float32)
            tmp36 = tl.load(in_ptr1 + (tl.broadcast_to(64 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp37 = tmp35 * tmp36
            tmp38 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp28 + (r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp12 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp39 = tmp37 * tmp38
            tmp40 = tmp31 - tmp39
            tmp41 = tl.full(tmp40.shape, 0.0, tmp40.dtype)
            tmp42 = tl.where(tmp12, tmp40, tmp41)
            tmp43 = tmp6 >= tmp11
            tmp44 = tl.full([1, 1], 128, tl.int64)
            tmp45 = tmp6 < tmp44
            tmp46 = tl.load(in_ptr0 + (64 + 128*x0 + 6144*x1 + ((-64) + r0_2)), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp47 = tmp46.to(tl.float32)
            tmp48 = tl.full([1, 1], 128.0, tl.float32)
            tmp49 = (tmp4 / tmp48)
            tmp50 = tl.full([1, 1], 1e-06, tl.float32)
            tmp51 = tmp49 + tmp50
            tmp52 = libdevice.rsqrt(tmp51)
            tmp53 = tmp47 * tmp52
            tmp54 = tmp53.to(tl.float32)
            tmp55 = tl.load(in_ptr1 + (tl.broadcast_to(64 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp56 = tmp54 * tmp55
            tmp57 = tl.load(in_ptr2 + (tl.broadcast_to(x1, [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0)
            tmp58 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp59 = tmp57 + tmp58
            tmp60 = tmp57 < 0
            tmp61 = tl.where(tmp60, tmp59, tmp57)
            tl.device_assert(((0 <= tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp43 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp61, [XBLOCK, R0_BLOCK]) < 40960")
            tmp63 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp61 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp64 = tmp56 * tmp63
            tmp65 = tl.load(in_ptr0 + (128*x0 + 6144*x1 + ((-64) + r0_2)), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp66 = tmp65.to(tl.float32)
            tmp67 = tmp66 * tmp52
            tmp68 = tmp67.to(tl.float32)
            tmp69 = tl.load(in_ptr1 + (tl.broadcast_to((-64) + r0_2, [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp70 = tmp68 * tmp69
            tmp71 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp61 + ((-64) + r0_2), [XBLOCK, R0_BLOCK])), r0_mask & tmp43 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp72 = tmp70 * tmp71
            tmp73 = tmp64 + tmp72
            tmp74 = tl.full(tmp73.shape, 0.0, tmp73.dtype)
            tmp75 = tl.where(tmp43, tmp73, tmp74)
            tmp76 = tl.where(tmp12, tmp42, tmp75)
            tl.store(out_ptr1 + (r0_2 + 128*x3), tmp76, r0_mask & xmask)
    elif pid < num_xblocks_1:
        pid_offset = pid - num_xblocks_0
        r0_numel = 128
        rnumel = r0_numel
        RBLOCK: tl.constexpr = R0_BLOCK
        xoffset = pid_offset * XBLOCK
        xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
        xmask = xindex < xnumel_1
        r0_base = tl.arange(0, R0_BLOCK)[None, :]
        rbase = r0_base
        x4 = (xindex % 8)
        x5 = xindex // 8
        _tmp81 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
        x7 = xindex
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_6 = r0_index
            tmp77 = tl.load(in_ptr0 + (4096 + r0_6 + 128*x4 + 6144*x5), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp78 = tmp77.to(tl.float32)
            tmp79 = tmp78 * tmp78
            tmp80 = tl.broadcast_to(tmp79, [XBLOCK, R0_BLOCK])
            tmp82 = _tmp81 + tmp80
            _tmp81 = tl.where(r0_mask & xmask, tmp82, _tmp81)
        tmp81 = tl.sum(_tmp81, 1)[:, None]
        for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
            r0_index = r0_offset + r0_base
            r0_mask = r0_index < r0_numel
            roffset = r0_offset
            rindex = r0_index
            r0_6 = r0_index
            tmp83 = (r0_6).to(tl.int32)
            tmp84 = tl.full([1, 1], 0, tl.int64)
            tmp85 = tmp83 >= tmp84
            tmp86 = (r0_6).to(tl.int64)
            tmp87 = (tmp86).to(tl.int64)
            tmp88 = tl.full([1, 1], 64, tl.int64)
            tmp89 = tmp87 < tmp88
            tmp90 = tl.load(in_ptr0 + (4096 + 128*x4 + 6144*x5 + (r0_6)), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp91 = tmp90.to(tl.float32)
            tmp92 = tl.full([1, 1], 128.0, tl.float32)
            tmp93 = (tmp81 / tmp92)
            tmp94 = tl.full([1, 1], 1e-06, tl.float32)
            tmp95 = tmp93 + tmp94
            tmp96 = libdevice.rsqrt(tmp95)
            tmp97 = tmp91 * tmp96
            tmp98 = tmp97.to(tl.float32)
            tmp99 = tl.load(in_ptr4 + (tl.broadcast_to(r0_6, [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp100 = tmp98 * tmp99
            tmp101 = tl.load(in_ptr2 + (tl.broadcast_to(x5, [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0)
            tmp102 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp103 = tmp101 + tmp102
            tmp104 = tmp101 < 0
            tmp105 = tl.where(tmp104, tmp103, tmp101)
            tl.device_assert(((0 <= tl.broadcast_to(tmp105, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp105, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp89 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp105, [XBLOCK, R0_BLOCK]) < 40960")
            tmp107 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp105 + (r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp108 = tmp100 * tmp107
            tmp109 = tl.load(in_ptr0 + (4160 + 128*x4 + 6144*x5 + (r0_6)), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp110 = tmp109.to(tl.float32)
            tmp111 = tmp110 * tmp96
            tmp112 = tmp111.to(tl.float32)
            tmp113 = tl.load(in_ptr4 + (tl.broadcast_to(64 + (r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp114 = tmp112 * tmp113
            tmp115 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp105 + (r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp89 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp116 = tmp114 * tmp115
            tmp117 = tmp108 - tmp116
            tmp118 = tl.full(tmp117.shape, 0.0, tmp117.dtype)
            tmp119 = tl.where(tmp89, tmp117, tmp118)
            tmp120 = tmp83 >= tmp88
            tmp121 = tl.full([1, 1], 128, tl.int64)
            tmp122 = tmp83 < tmp121
            tmp123 = tl.load(in_ptr0 + (4160 + 128*x4 + 6144*x5 + ((-64) + r0_6)), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp124 = tmp123.to(tl.float32)
            tmp125 = tl.full([1, 1], 128.0, tl.float32)
            tmp126 = (tmp81 / tmp125)
            tmp127 = tl.full([1, 1], 1e-06, tl.float32)
            tmp128 = tmp126 + tmp127
            tmp129 = libdevice.rsqrt(tmp128)
            tmp130 = tmp124 * tmp129
            tmp131 = tmp130.to(tl.float32)
            tmp132 = tl.load(in_ptr4 + (tl.broadcast_to(64 + ((-64) + r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp133 = tmp131 * tmp132
            tmp134 = tl.load(in_ptr2 + (tl.broadcast_to(x5, [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0)
            tmp135 = (tl.full([1, 1], 40960, tl.int32)).to(tl.int32)
            tmp136 = tmp134 + tmp135
            tmp137 = tmp134 < 0
            tmp138 = tl.where(tmp137, tmp136, tmp134)
            tl.device_assert(((0 <= tl.broadcast_to(tmp138, [XBLOCK, R0_BLOCK])) & (tl.broadcast_to(tmp138, [XBLOCK, R0_BLOCK]) < 40960)) | ~(r0_mask & tmp120 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp138, [XBLOCK, R0_BLOCK]) < 40960")
            tmp140 = tl.load(in_ptr3 + (tl.broadcast_to(128*tmp138 + ((-64) + r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp141 = tmp133 * tmp140
            tmp142 = tl.load(in_ptr0 + (4096 + 128*x4 + 6144*x5 + ((-64) + r0_6)), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp143 = tmp142.to(tl.float32)
            tmp144 = tmp143 * tmp129
            tmp145 = tmp144.to(tl.float32)
            tmp146 = tl.load(in_ptr4 + (tl.broadcast_to((-64) + r0_6, [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp147 = tmp145 * tmp146
            tmp148 = tl.load(in_ptr3 + (tl.broadcast_to(64 + 128*tmp138 + ((-64) + r0_6), [XBLOCK, R0_BLOCK])), r0_mask & tmp120 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
            tmp149 = tmp147 * tmp148
            tmp150 = tmp141 + tmp149
            tmp151 = tl.full(tmp150.shape, 0.0, tmp150.dtype)
            tmp152 = tl.where(tmp120, tmp150, tmp151)
            tmp153 = tl.where(tmp89, tmp119, tmp152)
            tl.store(out_ptr3 + (r0_6 + 128*x7), tmp153, r0_mask & xmask)
    else:
        pass


def get_args():
    arg_0 = rand_strided((16384, 6144), (6144, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_1 = rand_strided((128,), (1,), device='cuda:0', dtype=torch.bfloat16)
    arg_2 = rand_strided((16384,), (1,), device='cuda:0', dtype=torch.int64)
    arg_3 = rand_strided((40960, 128), (128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_4 = rand_strided((128,), (1,), device='cuda:0', dtype=torch.bfloat16)
    arg_5 = rand_strided((16384, 32, 128), (4096, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg_6 = rand_strided((16384, 8, 128), (1024, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    return arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, 524288, 131072,


def call(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        raw_stream0 = get_raw_stream(0)
        triton_red_fused_1.run(*args, stream=raw_stream0)


def benchmark_all_configs(args):
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        return triton_red_fused_1.benchmark_all_configs(*args)


if __name__ == '__main__':
    from torch._inductor.runtime.benchmarking import benchmarker

    args = get_args()
    ms = benchmarker.benchmark(call, fn_args=(args,), device='cuda',rep=40)
    num_gb = 0.189006336
    gb_per_s = num_gb / (ms / 1e3)
    print(f"{ms:.3f}ms    {num_gb:.3f}GB    {gb_per_s:.2f}GB/s")
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1 = args
        args.clear()
        s72 = arg1_1
        s80 = s72
        assert_size_stride(arg0_1, (s72, ), (1, ), 'input')
        assert_size_stride(arg2_1, (151936, 4096), (4096, 1), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            arg2_1 = copy_if_misaligned(arg2_1)
            buf0 = empty_strided_cuda((s72, 4096), (4096, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [long, embedding], Original ATen: [aten._to_copy, aten.embedding]
            triton_poi_fused__to_copy_embedding_0_xnumel = 4096*s72
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_embedding_0.run(arg0_1, arg2_1, buf0, triton_poi_fused__to_copy_embedding_0_xnumel, stream=raw_stream0)
            del arg0_1
            del arg2_1
            buf1 = empty_strided_cuda((s72, 32), (1, (-4)*(s72 // (-4))), torch.float32)
            buf2 = empty_strided_cuda((s72, 4096), (4096, 1), torch.float8_e4m3fn)
            assert_size_stride(arg3_1, (4096, ), (1, ), 'input')
            arg3_1 = copy_if_misaligned(arg3_1)
            # Topologically Sorted Source Nodes: [], Original ATen: []
            torch.ops._C.rms_norm_per_block_quant.default(buf2, buf0, arg3_1, buf1, 1e-06, None, None, 128, True)
            del arg3_1
            buf6 = empty_strided_cuda((s72, 6144), (6144, 1), torch.bfloat16)
            assert_size_stride(arg4_1, (6144, 4096), (4096, 1), 'input')
            assert_size_stride(arg5_1, (48, 32), (32, 1), 'input')
            arg4_1 = copy_if_misaligned(arg4_1)
            arg5_1 = copy_if_misaligned(arg5_1)
            # Topologically Sorted Source Nodes: [fp8_gemm_nt_op], Original ATen: [vllm.fp8_gemm_nt_op]
            torch.ops.vllm.fp8_gemm_nt_op.default(buf2, buf1, arg4_1, arg5_1, buf6, True)
            del arg4_1
            del arg5_1
            del buf1
            del buf2
            assert_size_stride(arg6_1, (128, ), (1, ), 'input')
            assert_size_stride(arg8_1, (s72, ), (1, ), 'input')
            assert_size_stride(arg9_1, (40960, 128), (128, 1), 'input')
            assert_size_stride(arg7_1, (128, ), (1, ), 'input')
            arg6_1 = copy_if_misaligned(arg6_1)
            arg8_1 = copy_if_misaligned(arg8_1)
            arg9_1 = copy_if_misaligned(arg9_1)
            arg7_1 = copy_if_misaligned(arg7_1)
            buf12 = empty_strided_cuda((s72, 32, 128), (4096, 128, 1), torch.bfloat16)
            buf11 = empty_strided_cuda((s72, 8, 128), (1024, 128, 1), torch.bfloat16)
            # Unsorted Source Nodes: [], Original ATen: []
            triton_red_fused_1_xnumel_0 = 32*s72
            triton_red_fused_1_xnumel_1 = 8*s72
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_1.run(buf6, arg6_1, arg8_1, arg9_1, arg7_1, buf12, buf11, triton_red_fused_1_xnumel_0, triton_red_fused_1_xnumel_1, stream=raw_stream0)
            del arg6_1
            del arg7_1
            del arg8_1
            del arg9_1
            buf13 = empty_strided_cuda((s72, 4096), (4096, 1), torch.bfloat16)
        return (buf11, reinterpret_tensor(buf6, (s72, 8, 128), (6144, 128, 1), 5120), buf12, reinterpret_tensor(buf13, (s72, 32, 128), (4096, 128, 1), 0), (-4)*(s72 // (-4)), buf0, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((16384, ), (1, ), device='cuda:0', dtype=torch.int32)
    arg1_1 = 16384
    arg2_1 = rand_strided((151936, 4096), (4096, 1), device='cuda:0', dtype=torch.bfloat16)
    arg3_1 = rand_strided((4096, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg4_1 = rand_strided((6144, 4096), (4096, 1), device='cuda:0', dtype=torch.float8_e4m3fn)
    arg5_1 = rand_strided((48, 32), (32, 1), device='cuda:0', dtype=torch.float32)
    arg6_1 = rand_strided((128, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg7_1 = rand_strided((128, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg8_1 = rand_strided((16384, ), (1, ), device='cuda:0', dtype=torch.int64)
    arg9_1 = rand_strided((40960, 128), (128, 1), device='cuda:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
