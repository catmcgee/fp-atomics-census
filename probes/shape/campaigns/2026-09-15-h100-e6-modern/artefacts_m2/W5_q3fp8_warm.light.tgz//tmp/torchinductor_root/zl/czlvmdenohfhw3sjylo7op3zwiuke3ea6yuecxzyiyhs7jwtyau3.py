
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2048, 'r0_': 16384},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'ks0': 'i64', 'ks1': 'i64', 'ks2': 'i64', 'ks3': 'i64', 'ks4': 'i64', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_abs_amax_ceil_clamp_div_log2_pow_view_zeros_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 24576, 'r0_': 100663296}, 'backend_hash': 'B1F9651A75F5D2DD6203FECC047C63B4DA82AA1EC10FE90B895553194611C6F8', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_abs_amax_ceil_clamp_div_log2_pow_view_zeros_0(in_ptr0, out_ptr0, out_ptr1, ks0, ks1, ks2, ks3, ks4, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x1 = xindex // ks1
    x0 = (xindex % ks1)
    _tmp10 = tl.full([XBLOCK, R0_BLOCK], float("-inf"), tl.float32)
    x4 = xindex
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_3 = triton_helpers.div_floor_integer(r0_index,  ks0)
        r0_2 = (r0_index % ks0)
        tmp0 = (r0_3 + ks2*x1).to(tl.int64)
        tmp1 = (tmp0).to(tl.int64)
        tmp2 = (ks3).to(tl.int64)
        tmp3 = (tmp2).to(tl.int64)
        tmp4 = tmp1 < tmp3
        tmp5 = tl.load(in_ptr0 + (r0_2 + ks0*x0 + ks4*r0_3 + ks2*ks4*x1), r0_mask & tmp4 & xmask, eviction_policy='evict_last', other=0.0)
        tmp6 = tl.full([1, 1], 0.0, tl.float32)
        tmp7 = tl.where(tmp4, tmp5, tmp6)
        tmp8 = tl_math.abs(tmp7)
        tmp9 = tl.broadcast_to(tmp8, [XBLOCK, R0_BLOCK])
        tmp11 = triton_helpers.maximum(_tmp10, tmp9)
        _tmp10 = tl.where(r0_mask & xmask, tmp11, _tmp10)
    tmp10 = triton_helpers.max2(_tmp10, 1)[:, None]
    tl.store(out_ptr0 + (x4), tmp10, xmask)
    tmp12 = tl.full([1, 1], 0.0001, tl.float32)
    tmp13 = triton_helpers.maximum(tmp10, tmp12)
    tmp14 = tl.full([1, 1], 0.002232142857142857, tl.float32)
    tmp15 = tmp13 * tmp14
    tmp16 = tl_math.abs(tmp15)
    tmp17 = libdevice.log2(tmp16)
    tmp18 = libdevice.ceil(tmp17)
    tmp19 = libdevice.exp2(tmp18)
    tl.store(out_ptr1 + (x4), tmp19, xmask)
