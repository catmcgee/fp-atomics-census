// Includes' hash value: 1be83c7ee3df928835d695a7de7b0cd8

#include <deep_gemm/impls/sm90_fp8_gemm_1d2d.cuh>

using namespace deep_gemm;

static void __instantiate_kernel() {
    auto ptr = reinterpret_cast<void*>(&sm90_fp8_gemm_1d2d_impl<
        cute::UMMA::Major::K,
        0, 24576, 4096,
        1,
        64, 96, 128,
        128, 128, 64,
        10,
        128, 128,
        2, false,
        132, GemmType::Normal,
        cutlass::bfloat16_t,
        epilogue::transform::EpilogueIdentity
    >);
};
