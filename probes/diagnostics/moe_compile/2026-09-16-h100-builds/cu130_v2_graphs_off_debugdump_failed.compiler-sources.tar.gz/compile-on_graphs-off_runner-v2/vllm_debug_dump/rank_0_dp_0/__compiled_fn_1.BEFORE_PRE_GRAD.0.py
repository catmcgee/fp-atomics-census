from __future__ import annotations
import torch
from torch import device
class GraphModule(torch.nn.Module):
    def forward(self, l_input_ids_: "i32[s72]", s72: "Sym(s72)", l_self_modules_embed_tokens_parameters_weight_: "bf16[151936, 2048]", l_self_modules_layers_modules_0_modules_input_layernorm_parameters_weight_: "bf16[2048]", l_self_modules_layers_modules_0_modules_self_attn_modules_qkv_proj_parameters_weight_: "bf16[6144, 2048]", l_self_modules_layers_modules_0_modules_self_attn_modules_qkv_proj_parameters_bias_: "bf16[6144]", l_positions_: "i64[s72]", l_self_modules_layers_modules_0_modules_self_attn_modules_rotary_emb_buffers_cos_sin_cache_: "bf16[32768, 128]"):
        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/vocab_parallel_embedding.py:501 in forward, code: output_parallel = self.quant_method.embedding(self, masked_input.long())
        long: "i64[s72]" = l_input_ids_.long();  l_input_ids_ = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/vocab_parallel_embedding.py:78 in embedding, code: return F.embedding(input_, layer.weight)
        embedding: "bf16[s72, 2048]" = torch.nn.functional.embedding(long, l_self_modules_embed_tokens_parameters_weight_);  long = l_self_modules_embed_tokens_parameters_weight_ = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/layernorm.py:83 in forward_native, code: self.weight.data if self.pass_weight else None,
        _get_data_attr: "bf16[2048]" = torch._C._autograd._get_data_attr(l_self_modules_layers_modules_0_modules_input_layernorm_parameters_weight_);  l_self_modules_layers_modules_0_modules_input_layernorm_parameters_weight_ = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/ir/op.py:372 in __call__, code: return self.torch_op(*args, **kwargs)
        rms_norm_default: "bf16[s72, 2048]" = torch.ops.vllm_ir.rms_norm.default(embedding, _get_data_attr, 1e-06, None);  _get_data_attr = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/parameter.py:126 in __torch_function__, code: return super().__torch_function__(func, types, args, kwargs)
        linear: "bf16[s72, 6144]" = torch._C._nn.linear(rms_norm_default, l_self_modules_layers_modules_0_modules_self_attn_modules_qkv_proj_parameters_weight_, l_self_modules_layers_modules_0_modules_self_attn_modules_qkv_proj_parameters_bias_);  rms_norm_default = l_self_modules_layers_modules_0_modules_self_attn_modules_qkv_proj_parameters_weight_ = l_self_modules_layers_modules_0_modules_self_attn_modules_qkv_proj_parameters_bias_ = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/models/qwen2_moe.py:274 in forward, code: q, k, v = qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)
        split = linear.split([2048, 2048, 2048], dim = -1);  linear = None
        getitem: "bf16[s72, 2048]" = split[0]

        # No stacktrace found for following nodes
        sym_size_int: "Sym(s72)" = torch.ops.aten.sym_size.int(getitem, 0)

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/models/qwen2_moe.py:274 in forward, code: q, k, v = qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)
        getitem_1: "bf16[s72, 2048]" = split[1]

        # No stacktrace found for following nodes
        sym_size_int_1: "Sym(s72)" = torch.ops.aten.sym_size.int(getitem_1, 0)

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/models/qwen2_moe.py:274 in forward, code: q, k, v = qkv.split([self.q_size, self.kv_size, self.kv_size], dim=-1)
        getitem_2: "bf16[s72, 2048]" = split[2];  split = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/base.py:171 in forward_static, code: positions = positions.flatten()
        flatten: "i64[s72]" = l_positions_.flatten();  l_positions_ = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/base.py:173 in forward_static, code: cos_sin = cos_sin_cache.index_select(0, positions)
        index_select: "bf16[s72, 128]" = l_self_modules_layers_modules_0_modules_self_attn_modules_rotary_emb_buffers_cos_sin_cache_.index_select(0, flatten);  l_self_modules_layers_modules_0_modules_self_attn_modules_rotary_emb_buffers_cos_sin_cache_ = flatten = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/base.py:174 in forward_static, code: cos, sin = cos_sin.chunk(2, dim=-1)
        chunk = index_select.chunk(2, dim = -1);  index_select = None
        getitem_3: "bf16[s72, 64]" = chunk[0]
        getitem_4: "bf16[s72, 64]" = chunk[1];  chunk = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/base.py:177 in forward_static, code: query = query.view(num_tokens, -1, head_size)
        view: "bf16[s72, 16, 128]" = getitem.view(s72, -1, 128);  getitem = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/base.py:178 in forward_static, code: query_rot = query[..., :rotary_dim]
        getitem_5: "bf16[s72, 16, 128]" = view[(Ellipsis, slice(None, 128, None))]

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/base.py:179 in forward_static, code: query_pass = query[..., rotary_dim:]
        getitem_6: "bf16[s72, 16, 0]" = view[(Ellipsis, slice(128, None, None))];  view = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/common.py:166 in forward_static, code: cos = cos.unsqueeze(-2).to(x.dtype)
        unsqueeze: "bf16[s72, 1, 64]" = getitem_3.unsqueeze(-2)
        to: "bf16[s72, 1, 64]" = unsqueeze.to(torch.bfloat16);  unsqueeze = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/common.py:167 in forward_static, code: sin = sin.unsqueeze(-2).to(x.dtype)
        unsqueeze_1: "bf16[s72, 1, 64]" = getitem_4.unsqueeze(-2)
        to_1: "bf16[s72, 1, 64]" = unsqueeze_1.to(torch.bfloat16);  unsqueeze_1 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/common.py:170 in forward_static, code: x1, x2 = torch.chunk(x, 2, dim=-1)
        chunk_1 = torch.chunk(getitem_5, 2, dim = -1);  getitem_5 = None
        getitem_7: "bf16[s72, 16, 64]" = chunk_1[0]
        getitem_8: "bf16[s72, 16, 64]" = chunk_1[1];  chunk_1 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/common.py:175 in forward_static, code: o1 = x1 * cos - x2 * sin
        mul: "bf16[s72, 16, 64]" = getitem_7 * to
        mul_1: "bf16[s72, 16, 64]" = getitem_8 * to_1
        sub: "bf16[s72, 16, 64]" = mul - mul_1;  mul = mul_1 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/common.py:176 in forward_static, code: o2 = x2 * cos + x1 * sin
        mul_2: "bf16[s72, 16, 64]" = getitem_8 * to;  getitem_8 = to = None
        mul_3: "bf16[s72, 16, 64]" = getitem_7 * to_1;  getitem_7 = to_1 = None
        add: "bf16[s72, 16, 64]" = mul_2 + mul_3;  mul_2 = mul_3 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/common.py:179 in forward_static, code: output = torch.cat((o1, o2), dim=-1)
        cat: "bf16[s72, 16, 128]" = torch.cat((sub, add), dim = -1);  sub = add = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/base.py:186 in forward_static, code: query = torch.cat((query_rot, query_pass), dim=-1).reshape(query_shape)
        cat_1: "bf16[s72, 16, 128]" = torch.cat((cat, getitem_6), dim = -1);  cat = getitem_6 = None
        reshape: "bf16[s72, 2048]" = cat_1.reshape(sym_size_int, 2048);  cat_1 = sym_size_int = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/base.py:191 in forward_static, code: key = key.view(num_tokens, -1, head_size)
        view_1: "bf16[s72, 16, 128]" = getitem_1.view(s72, -1, 128);  getitem_1 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/base.py:192 in forward_static, code: key_rot = key[..., :rotary_dim]
        getitem_9: "bf16[s72, 16, 128]" = view_1[(Ellipsis, slice(None, 128, None))]

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/base.py:193 in forward_static, code: key_pass = key[..., rotary_dim:]
        getitem_10: "bf16[s72, 16, 0]" = view_1[(Ellipsis, slice(128, None, None))];  view_1 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/common.py:166 in forward_static, code: cos = cos.unsqueeze(-2).to(x.dtype)
        unsqueeze_2: "bf16[s72, 1, 64]" = getitem_3.unsqueeze(-2);  getitem_3 = None
        to_2: "bf16[s72, 1, 64]" = unsqueeze_2.to(torch.bfloat16);  unsqueeze_2 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/common.py:167 in forward_static, code: sin = sin.unsqueeze(-2).to(x.dtype)
        unsqueeze_3: "bf16[s72, 1, 64]" = getitem_4.unsqueeze(-2);  getitem_4 = None
        to_3: "bf16[s72, 1, 64]" = unsqueeze_3.to(torch.bfloat16);  unsqueeze_3 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/common.py:170 in forward_static, code: x1, x2 = torch.chunk(x, 2, dim=-1)
        chunk_2 = torch.chunk(getitem_9, 2, dim = -1);  getitem_9 = None
        getitem_11: "bf16[s72, 16, 64]" = chunk_2[0]
        getitem_12: "bf16[s72, 16, 64]" = chunk_2[1];  chunk_2 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/common.py:175 in forward_static, code: o1 = x1 * cos - x2 * sin
        mul_4: "bf16[s72, 16, 64]" = getitem_11 * to_2
        mul_5: "bf16[s72, 16, 64]" = getitem_12 * to_3
        sub_1: "bf16[s72, 16, 64]" = mul_4 - mul_5;  mul_4 = mul_5 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/common.py:176 in forward_static, code: o2 = x2 * cos + x1 * sin
        mul_6: "bf16[s72, 16, 64]" = getitem_12 * to_2;  getitem_12 = to_2 = None
        mul_7: "bf16[s72, 16, 64]" = getitem_11 * to_3;  getitem_11 = to_3 = None
        add_1: "bf16[s72, 16, 64]" = mul_6 + mul_7;  mul_6 = mul_7 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/common.py:179 in forward_static, code: output = torch.cat((o1, o2), dim=-1)
        cat_2: "bf16[s72, 16, 128]" = torch.cat((sub_1, add_1), dim = -1);  sub_1 = add_1 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/rotary_embedding/base.py:200 in forward_static, code: key = torch.cat((key_rot, key_pass), dim=-1).reshape(key_shape)
        cat_3: "bf16[s72, 16, 128]" = torch.cat((cat_2, getitem_10), dim = -1);  cat_2 = getitem_10 = None
        reshape_1: "bf16[s72, 2048]" = cat_3.reshape(sym_size_int_1, 2048);  cat_3 = sym_size_int_1 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/attention/attention.py:519 in forward, code: output = torch.empty(output_shape, dtype=output_dtype, device=query.device)
        size = torch.Size([s72, 2048]);  s72 = None
        empty: "bf16[s72, 2048]" = torch.empty(size, dtype = torch.bfloat16, device = device(type='cuda', index=0));  size = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/attention/attention.py:524 in forward, code: query = query.view(-1, self.num_heads, self.head_size)
        view_2: "bf16[s72, 16, 128]" = reshape.view(-1, 16, 128);  reshape = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/attention/attention.py:525 in forward, code: output = output.view(-1, self.num_heads, self.head_size_v)
        view_3: "bf16[s72, 16, 128]" = empty.view(-1, 16, 128);  empty = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/attention/attention.py:527 in forward, code: key = key.view(-1, self.num_kv_heads, self.head_size)
        view_4: "bf16[s72, 16, 128]" = reshape_1.view(-1, 16, 128);  reshape_1 = None

        # File: /opt/issue56900/cu130/lib/python3.12/site-packages/vllm/model_executor/layers/attention/attention.py:529 in forward, code: value = value.view(-1, self.num_kv_heads, self.head_size_v)
        view_5: "bf16[s72, 16, 128]" = getitem_2.view(-1, 16, 128);  getitem_2 = None
        return (view_4, view_5, view_2, view_3, embedding)
