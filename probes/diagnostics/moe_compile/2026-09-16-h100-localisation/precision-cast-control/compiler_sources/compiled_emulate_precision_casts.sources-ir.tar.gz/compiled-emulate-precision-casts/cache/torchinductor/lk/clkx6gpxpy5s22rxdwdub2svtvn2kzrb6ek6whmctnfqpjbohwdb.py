
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 33554432}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*i64', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': False, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 10, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 671219712}, 'kernel_num_gb': 0.67960832, 'kernel_flop': 0, 'backend_hash': '12CB7AF2462FDF7F0782918BFFA38096B8D56EE547964A5304EFBEAD2F02B50A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 16)
    x2 = xindex // 2048
    x4 = xindex
    tmp0 = (x0).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 64, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tl.load(in_ptr0 + (2048 + 128*x1 + 6144*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp8 = tmp7.to(tl.bfloat16)
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tl.load(in_ptr1 + (x2), tmp6 & xmask, eviction_policy='evict_last', other=0.0)
    tmp11 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp10 < 0
    tmp14 = tl.where(tmp13, tmp12, tmp10)
    tl.device_assert(((0 <= tl.broadcast_to(tmp14, [XBLOCK])) & (tl.broadcast_to(tmp14, [XBLOCK]) < 32768)) | ~(tmp6 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp14, [XBLOCK]) < 32768")
    tmp16 = tl.load(in_ptr2 + (128*tmp14 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp17 = tmp16.to(tl.bfloat16)
    tmp18 = tmp17.to(tl.float32)
    tmp19 = tmp9 * tmp18
    tmp20 = tmp19.to(tl.bfloat16)
    tmp21 = tmp20.to(tl.float32)
    tmp22 = tmp21.to(tl.bfloat16)
    tmp23 = tmp22.to(tl.float32)
    tmp24 = tl.load(in_ptr0 + (2112 + 128*x1 + 6144*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp25 = tmp24.to(tl.bfloat16)
    tmp26 = tmp25.to(tl.float32)
    tmp27 = tl.load(in_ptr2 + (64 + 128*tmp14 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp28 = tmp27.to(tl.bfloat16)
    tmp29 = tmp28.to(tl.float32)
    tmp30 = tmp26 * tmp29
    tmp31 = tmp30.to(tl.bfloat16)
    tmp32 = tmp31.to(tl.float32)
    tmp33 = tmp32.to(tl.bfloat16)
    tmp34 = tmp33.to(tl.float32)
    tmp35 = tmp23 - tmp34
    tmp36 = tmp35.to(tl.bfloat16)
    tmp37 = tmp36.to(tl.float32)
    tmp38 = tl.full(tmp37.shape, 0.0, tmp37.dtype)
    tmp39 = tl.where(tmp6, tmp37, tmp38)
    tmp40 = tmp0 >= tmp5
    tmp41 = tl.full([1], 128, tl.int64)
    tmp42 = tmp0 < tmp41
    tmp43 = tl.load(in_ptr0 + (2112 + 128*x1 + 6144*x2 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp44 = tmp43.to(tl.bfloat16)
    tmp45 = tmp44.to(tl.float32)
    tmp46 = tl.load(in_ptr1 + (x2), tmp40 & xmask, eviction_policy='evict_last', other=0.0)
    tmp47 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp48 = tmp46 + tmp47
    tmp49 = tmp46 < 0
    tmp50 = tl.where(tmp49, tmp48, tmp46)
    tl.device_assert(((0 <= tl.broadcast_to(tmp50, [XBLOCK])) & (tl.broadcast_to(tmp50, [XBLOCK]) < 32768)) | ~(tmp40 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp50, [XBLOCK]) < 32768")
    tmp52 = tl.load(in_ptr2 + (128*tmp50 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp53 = tmp52.to(tl.bfloat16)
    tmp54 = tmp53.to(tl.float32)
    tmp55 = tmp45 * tmp54
    tmp56 = tmp55.to(tl.bfloat16)
    tmp57 = tmp56.to(tl.float32)
    tmp58 = tmp57.to(tl.bfloat16)
    tmp59 = tmp58.to(tl.float32)
    tmp60 = tl.load(in_ptr0 + (2048 + 128*x1 + 6144*x2 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp61 = tmp60.to(tl.bfloat16)
    tmp62 = tmp61.to(tl.float32)
    tmp63 = tl.load(in_ptr2 + (64 + 128*tmp50 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp64 = tmp63.to(tl.bfloat16)
    tmp65 = tmp64.to(tl.float32)
    tmp66 = tmp62 * tmp65
    tmp67 = tmp66.to(tl.bfloat16)
    tmp68 = tmp67.to(tl.float32)
    tmp69 = tmp68.to(tl.bfloat16)
    tmp70 = tmp69.to(tl.float32)
    tmp71 = tmp59 + tmp70
    tmp72 = tmp71.to(tl.bfloat16)
    tmp73 = tmp72.to(tl.float32)
    tmp74 = tl.full(tmp73.shape, 0.0, tmp73.dtype)
    tmp75 = tl.where(tmp40, tmp73, tmp74)
    tmp76 = tl.where(tmp6, tmp39, tmp75)
    tmp77 = tl.load(in_ptr0 + (128*x1 + 6144*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp78 = tmp77.to(tl.bfloat16)
    tmp79 = tmp78.to(tl.float32)
    tmp80 = tmp79 * tmp18
    tmp81 = tmp80.to(tl.bfloat16)
    tmp82 = tmp81.to(tl.float32)
    tmp83 = tmp82.to(tl.bfloat16)
    tmp84 = tmp83.to(tl.float32)
    tmp85 = tl.load(in_ptr0 + (64 + 128*x1 + 6144*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp86 = tmp85.to(tl.bfloat16)
    tmp87 = tmp86.to(tl.float32)
    tmp88 = tmp87 * tmp29
    tmp89 = tmp88.to(tl.bfloat16)
    tmp90 = tmp89.to(tl.float32)
    tmp91 = tmp90.to(tl.bfloat16)
    tmp92 = tmp91.to(tl.float32)
    tmp93 = tmp84 - tmp92
    tmp94 = tmp93.to(tl.bfloat16)
    tmp95 = tmp94.to(tl.float32)
    tmp96 = tl.full(tmp95.shape, 0.0, tmp95.dtype)
    tmp97 = tl.where(tmp6, tmp95, tmp96)
    tmp98 = tl.load(in_ptr0 + (64 + 128*x1 + 6144*x2 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp99 = tmp98.to(tl.bfloat16)
    tmp100 = tmp99.to(tl.float32)
    tmp101 = tmp100 * tmp54
    tmp102 = tmp101.to(tl.bfloat16)
    tmp103 = tmp102.to(tl.float32)
    tmp104 = tmp103.to(tl.bfloat16)
    tmp105 = tmp104.to(tl.float32)
    tmp106 = tl.load(in_ptr0 + (128*x1 + 6144*x2 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp107 = tmp106.to(tl.bfloat16)
    tmp108 = tmp107.to(tl.float32)
    tmp109 = tmp108 * tmp65
    tmp110 = tmp109.to(tl.bfloat16)
    tmp111 = tmp110.to(tl.float32)
    tmp112 = tmp111.to(tl.bfloat16)
    tmp113 = tmp112.to(tl.float32)
    tmp114 = tmp105 + tmp113
    tmp115 = tmp114.to(tl.bfloat16)
    tmp116 = tmp115.to(tl.float32)
    tmp117 = tl.full(tmp116.shape, 0.0, tmp116.dtype)
    tmp118 = tl.where(tmp40, tmp116, tmp117)
    tmp119 = tl.where(tmp6, tmp97, tmp118)
    tl.store(out_ptr0 + (x4), tmp76, xmask)
    tl.store(out_ptr1 + (x4), tmp119, xmask)
