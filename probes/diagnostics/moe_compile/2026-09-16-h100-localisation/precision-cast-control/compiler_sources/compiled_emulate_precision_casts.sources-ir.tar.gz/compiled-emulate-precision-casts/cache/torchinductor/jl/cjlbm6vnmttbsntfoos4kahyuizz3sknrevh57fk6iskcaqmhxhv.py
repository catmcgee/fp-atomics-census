r"""
Compile-time auto-tuning block: 

import torch
from math import inf, nan
from torch._dynamo.testing import rand_strided
from torch._dynamo.utils import preserve_rng_state
from torch._inductor.select_algorithm import AlgorithmSelectorCache
from torch._inductor.async_compile import AsyncCompile

async_compile = AsyncCompile()
generate_example_value = AlgorithmSelectorCache.generate_example_value
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
get_raw_stream = torch._C._cuda_getCurrentRawStream


# kernel path: /root/causal/moe-precision-casts/compiled-emulate-precision-casts/cache/torchinductor/lu/clu55lqocaloii6ksgckte6j7fia52vabb5xdl6bgmwb3l5ccldd.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace], Original ATen: [vllm_ir.fused_add_rms_norm]
# Source node to ATen node mapping:
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, add_tensor_3, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_7, mean_dim_1, mul_tensor_2, mul_tensor_3, pow_tensor_scalar_1, rsqrt_default_1
# Graph fragment:
#   %mm : Tensor "bf16[s72, 2048][2048, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg4_1 : Tensor "bf16[s72, 2048][2048, 1]cuda:0" = PlaceHolder[target=arg4_1]
#   %buf1 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf1]
#   %arg3_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg3_1]
#   %convert_element_type_default_4 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mm, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %pow_tensor_scalar_1 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_2, 2), kwargs = {})
#   %mean_dim_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_1, [-1], True), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_1, 1e-06), kwargs = {})
#   %rsqrt_default_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_tensor_2 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_2, %rsqrt_default_1), kwargs = {})
#   %convert_element_type_default_7 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_2, torch.bfloat16), kwargs = {})
#   %mul_tensor_3 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_7, %arg3_1), kwargs = {})
#   return %buf1,%mul_tensor_3
triton_red_fused_fused_add_rms_norm_0 = async_compile.triton('triton_red_fused_fused_add_rms_norm_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': False, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_fused_add_rms_norm_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 268439552}, 'kernel_num_gb': 0.201330688, 'kernel_flop': 0, 'backend_hash': '12CB7AF2462FDF7F0782918BFFA38096B8D56EE547964A5304EFBEAD2F02B50A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_fused_add_rms_norm_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp1 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp22 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tmp9.to(tl.float32)
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tmp10 + tmp12
        tmp14 = tl.full([1, 1], 2048.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1, 1], 1e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp20 = tmp19.to(tl.bfloat16)
        tmp21 = tmp20.to(tl.float32)
        tmp23 = tmp21 * tmp22
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp23, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /root/causal/moe-precision-casts/compiled-emulate-precision-casts/cache/torchinductor/je/cjepwc2b2f7blgpglpblzmjcqqoeg3qaldks2kdlhr4dtokw2e6a.py
# Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_1 => constant_pad_nd_default, permute_1
# Graph fragment:
#   %arg5_1 : Tensor "bf16[60, 2048][2048, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %permute_1 : Tensor "bf16[2048, 60][1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg5_1, [1, 0]), kwargs = {})
#   %constant_pad_nd_default : Tensor "bf16[2048, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.constant_pad_nd.default](args = (%permute_1, [0, 4, 0, 0]), kwargs = {})
#   return %constant_pad_nd_default
triton_poi_fused_mm_t_1 = async_compile.triton('triton_poi_fused_mm_t_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': False, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_mm_t_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 770048}, 'kernel_num_gb': 0.000507904, 'kernel_flop': 0, 'backend_hash': '12CB7AF2462FDF7F0782918BFFA38096B8D56EE547964A5304EFBEAD2F02B50A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_mm_t_1(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 131072
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = xindex // 2048
    x0 = (xindex % 2048)
    x2 = xindex
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 60, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tl.load(in_ptr0 + (x0 + 2048*(x1)), tmp6, other=0.0).to(tl.float32)
    tmp8 = tmp0 >= tmp5
    tmp9 = tl.full([1], 64, tl.int64)
    tmp10 = tmp0 < tmp9
    tmp11 = tl.full([1], 0.0, tl.float32)
    tmp12 = tl.full(tmp11.shape, 0.0, tmp11.dtype)
    tmp13 = tl.where(tmp8, tmp11, tmp12)
    tmp14 = tl.where(tmp6, tmp7, tmp13)
    tl.store(out_ptr0 + (x2), tmp14, None)
''', device_str='cuda')


# kernel path: /root/causal/moe-precision-casts/compiled-emulate-precision-casts/cache/torchinductor/4r/c4r4c7tovi2agspfoyfqqvxgh43aamu2ll2ddm4xvej6pblusnsw.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, add, fused_add_rms_norm_maybe_inplace_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten.add]
# Source node to ATen node mapping:
#   add => add_24
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_6
#   fused_add_rms_norm_maybe_inplace_1 => add_tensor, add_tensor_1, convert_element_type_default, convert_element_type_default_1, convert_element_type_default_2, convert_element_type_default_3, mean_dim, mul_tensor, mul_tensor_1, pow_tensor_scalar, rsqrt_default
# Graph fragment:
#   %getitem_2 : Tensor "bf16[s72, 2048][2048, 1]cuda:0" = PlaceHolder[target=getitem_2]
#   %getitem_3 : Tensor "bf16[s72, 2048][2048, 1]cuda:0" = PlaceHolder[target=getitem_3]
#   %mm : Tensor "bf16[s72, 2048][2048, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg4_1 : Tensor "bf16[s72, 2048][2048, 1]cuda:0" = PlaceHolder[target=arg4_1]
#   %buf9 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf9]
#   %arg7_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg7_1]
#   %convert_element_type_default_4 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mm, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %convert_element_type_default_6 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor_2, torch.bfloat16), kwargs = {})
#   %add_24 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%getitem_2, %getitem_3), kwargs = {})
#   %convert_element_type_default : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_24, torch.float32), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%convert_element_type_default_6, torch.float32), kwargs = {})
#   %add_tensor : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default, %convert_element_type_default_1), kwargs = {})
#   %convert_element_type_default_2 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor, torch.bfloat16), kwargs = {})
#   %pow_tensor_scalar : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor, 2), kwargs = {})
#   %mean_dim : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar, [-1], True), kwargs = {})
#   %add_tensor_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim, 1e-06), kwargs = {})
#   %rsqrt_default : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_1,), kwargs = {})
#   %mul_tensor : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor, %rsqrt_default), kwargs = {})
#   %convert_element_type_default_3 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor, torch.bfloat16), kwargs = {})
#   %mul_tensor_1 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_3, %arg7_1), kwargs = {})
#   return %buf9,%convert_element_type_default_2,%mul_tensor_1
triton_red_fused_add_fused_add_rms_norm_2 = async_compile.triton('triton_red_fused_add_fused_add_rms_norm_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': False, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_add_fused_add_rms_norm_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 536875008}, 'kernel_num_gb': 0.40265728, 'kernel_flop': 0, 'backend_hash': '12CB7AF2462FDF7F0782918BFFA38096B8D56EE547964A5304EFBEAD2F02B50A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_add_fused_add_rms_norm_2(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp21 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp3 = tl.load(in_ptr1 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tl.load(in_ptr2 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp12 = tl.load(in_ptr3 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.bfloat16)
        tmp2 = tmp1.to(tl.float32)
        tmp4 = tmp3.to(tl.bfloat16)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp2 + tmp5
        tmp7 = tmp6.to(tl.bfloat16)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp8.to(tl.float32)
        tmp11 = tmp10.to(tl.float32)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tmp11 + tmp13
        tmp15 = tmp14.to(tl.bfloat16)
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tmp9 + tmp17
        tmp19 = tmp18 * tmp18
        tmp20 = tl.broadcast_to(tmp19, [XBLOCK, R0_BLOCK])
        tmp22 = _tmp21 + tmp20
        _tmp21 = tl.where(r0_mask & xmask, tmp22, _tmp21)
        tmp23 = tmp18.to(tl.bfloat16)
        tmp24 = tmp23.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp24, r0_mask & xmask)
    tmp21 = tl.sum(_tmp21, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp25 = tl.load(in_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp28 = tl.load(in_ptr1 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp35 = tl.load(in_ptr2 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp37 = tl.load(in_ptr3 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp52 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp26 = tmp25.to(tl.bfloat16)
        tmp27 = tmp26.to(tl.float32)
        tmp29 = tmp28.to(tl.bfloat16)
        tmp30 = tmp29.to(tl.float32)
        tmp31 = tmp27 + tmp30
        tmp32 = tmp31.to(tl.bfloat16)
        tmp33 = tmp32.to(tl.float32)
        tmp34 = tmp33.to(tl.float32)
        tmp36 = tmp35.to(tl.float32)
        tmp38 = tmp37.to(tl.float32)
        tmp39 = tmp36 + tmp38
        tmp40 = tmp39.to(tl.bfloat16)
        tmp41 = tmp40.to(tl.float32)
        tmp42 = tmp41.to(tl.float32)
        tmp43 = tmp34 + tmp42
        tmp44 = tl.full([1, 1], 2048.0, tl.float32)
        tmp45 = (tmp21 / tmp44)
        tmp46 = tl.full([1, 1], 1e-06, tl.float32)
        tmp47 = tmp45 + tmp46
        tmp48 = libdevice.rsqrt(tmp47)
        tmp49 = tmp43 * tmp48
        tmp50 = tmp49.to(tl.bfloat16)
        tmp51 = tmp50.to(tl.float32)
        tmp53 = tmp51 * tmp52
        tl.store(out_ptr2 + (r0_1 + 2048*x0), tmp53, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /root/causal/moe-precision-casts/compiled-emulate-precision-casts/cache/torchinductor/lk/clkx6gpxpy5s22rxdwdub2svtvn2kzrb6ek6whmctnfqpjbohwdb.py
# Topologically Sorted Source Nodes: [split, index_select, chunk, view_3, chunk_1, view_4, chunk_2, unsqueeze_2, mul_4, unsqueeze_3, mul_5, sub_1, mul_6, mul_7, add_2, cat_2, unsqueeze, mul, unsqueeze_1, mul_1, sub, mul_2, mul_3, add_1, cat], Original ATen: [aten.split_with_sizes, aten.index_select, aten.split, aten.view, aten.unsqueeze, aten.mul, aten.sub, aten.add, aten.cat]
# Source node to ATen node mapping:
#   add_1 => add_104
#   add_2 => add_166
#   cat => cat
#   cat_2 => cat_1
#   chunk => split
#   chunk_1 => split_1
#   chunk_2 => split_2
#   index_select => index
#   mul => mul_53
#   mul_1 => mul_56
#   mul_2 => mul_61
#   mul_3 => mul_64
#   mul_4 => mul_92
#   mul_5 => mul_95
#   mul_6 => mul_100
#   mul_7 => mul_103
#   split => split_with_sizes
#   sub => sub_28
#   sub_1 => sub_45
#   unsqueeze => unsqueeze
#   unsqueeze_1 => unsqueeze_1
#   unsqueeze_2 => unsqueeze_2
#   unsqueeze_3 => unsqueeze_3
#   view_3 => view_3
#   view_4 => view_5
# Graph fragment:
#   %addmm : Tensor "bf16[s72, 6144][6144, 1]cuda:0" = PlaceHolder[target=addmm]
#   %arg10_1 : Tensor "i64[s72][1]cuda:0" = PlaceHolder[target=arg10_1]
#   %arg11_1 : Tensor "bf16[32768, 128][128, 1]cuda:0" = PlaceHolder[target=arg11_1]
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%addmm, [2048, 2048, 2048], -1), kwargs = {})
#   %index : Tensor "bf16[s72, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg11_1, [%arg10_1]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%index, 64, -1), kwargs = {})
#   %view_3 : Tensor "bf16[s72, 16, 128][6144, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_6, [%arg1_1, -1, 128]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_3, 64, -1), kwargs = {})
#   %view_5 : Tensor "bf16[s72, 16, 128][6144, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_7, [%arg1_1, -1, 128]), kwargs = {})
#   %split_2 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_5, 64, -1), kwargs = {})
#   %unsqueeze_2 : Tensor "bf16[s72, 1, 64][128, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem_9, -2), kwargs = {})
#   %mul_92 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_13, %unsqueeze_2), kwargs = {})
#   %unsqueeze_3 : Tensor "bf16[s72, 1, 64][128, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem_10, -2), kwargs = {})
#   %mul_95 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_14, %unsqueeze_3), kwargs = {})
#   %sub_45 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%mul_92, %mul_95), kwargs = {})
#   %mul_100 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_14, %unsqueeze_2), kwargs = {})
#   %mul_103 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_13, %unsqueeze_3), kwargs = {})
#   %add_166 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_100, %mul_103), kwargs = {})
#   %cat_1 : Tensor "bf16[s72, 16, 128][2048, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%sub_45, %add_166], -1), kwargs = {})
#   %unsqueeze : Tensor "bf16[s72, 1, 64][128, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem_9, -2), kwargs = {})
#   %mul_53 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_11, %unsqueeze), kwargs = {})
#   %unsqueeze_1 : Tensor "bf16[s72, 1, 64][128, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem_10, -2), kwargs = {})
#   %mul_56 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_12, %unsqueeze_1), kwargs = {})
#   %sub_28 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%mul_53, %mul_56), kwargs = {})
#   %mul_61 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_12, %unsqueeze), kwargs = {})
#   %mul_64 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_11, %unsqueeze_1), kwargs = {})
#   %add_104 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_61, %mul_64), kwargs = {})
#   %cat : Tensor "bf16[s72, 16, 128][2048, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%sub_28, %add_104], -1), kwargs = {})
#   return %cat_1,%cat
triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3 = async_compile.triton('triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 33554432}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*i64', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': False, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 10, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 671219712}, 'kernel_num_gb': 0.67960832, 'kernel_flop': 0, 'backend_hash': '12CB7AF2462FDF7F0782918BFFA38096B8D56EE547964A5304EFBEAD2F02B50A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 16)
    x2 = xindex // 2048
    x4 = xindex
    tmp0 = (x0).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 64, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tl.load(in_ptr0 + (2048 + 128*x1 + 6144*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp8 = tmp7.to(tl.bfloat16)
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tl.load(in_ptr1 + (x2), tmp6 & xmask, eviction_policy='evict_last', other=0.0)
    tmp11 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp10 < 0
    tmp14 = tl.where(tmp13, tmp12, tmp10)
    tl.device_assert(((0 <= tl.broadcast_to(tmp14, [XBLOCK])) & (tl.broadcast_to(tmp14, [XBLOCK]) < 32768)) | ~(tmp6 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp14, [XBLOCK]) < 32768")
    tmp16 = tl.load(in_ptr2 + (128*tmp14 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp17 = tmp16.to(tl.bfloat16)
    tmp18 = tmp17.to(tl.float32)
    tmp19 = tmp9 * tmp18
    tmp20 = tmp19.to(tl.bfloat16)
    tmp21 = tmp20.to(tl.float32)
    tmp22 = tmp21.to(tl.bfloat16)
    tmp23 = tmp22.to(tl.float32)
    tmp24 = tl.load(in_ptr0 + (2112 + 128*x1 + 6144*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp25 = tmp24.to(tl.bfloat16)
    tmp26 = tmp25.to(tl.float32)
    tmp27 = tl.load(in_ptr2 + (64 + 128*tmp14 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp28 = tmp27.to(tl.bfloat16)
    tmp29 = tmp28.to(tl.float32)
    tmp30 = tmp26 * tmp29
    tmp31 = tmp30.to(tl.bfloat16)
    tmp32 = tmp31.to(tl.float32)
    tmp33 = tmp32.to(tl.bfloat16)
    tmp34 = tmp33.to(tl.float32)
    tmp35 = tmp23 - tmp34
    tmp36 = tmp35.to(tl.bfloat16)
    tmp37 = tmp36.to(tl.float32)
    tmp38 = tl.full(tmp37.shape, 0.0, tmp37.dtype)
    tmp39 = tl.where(tmp6, tmp37, tmp38)
    tmp40 = tmp0 >= tmp5
    tmp41 = tl.full([1], 128, tl.int64)
    tmp42 = tmp0 < tmp41
    tmp43 = tl.load(in_ptr0 + (2112 + 128*x1 + 6144*x2 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp44 = tmp43.to(tl.bfloat16)
    tmp45 = tmp44.to(tl.float32)
    tmp46 = tl.load(in_ptr1 + (x2), tmp40 & xmask, eviction_policy='evict_last', other=0.0)
    tmp47 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp48 = tmp46 + tmp47
    tmp49 = tmp46 < 0
    tmp50 = tl.where(tmp49, tmp48, tmp46)
    tl.device_assert(((0 <= tl.broadcast_to(tmp50, [XBLOCK])) & (tl.broadcast_to(tmp50, [XBLOCK]) < 32768)) | ~(tmp40 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp50, [XBLOCK]) < 32768")
    tmp52 = tl.load(in_ptr2 + (128*tmp50 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp53 = tmp52.to(tl.bfloat16)
    tmp54 = tmp53.to(tl.float32)
    tmp55 = tmp45 * tmp54
    tmp56 = tmp55.to(tl.bfloat16)
    tmp57 = tmp56.to(tl.float32)
    tmp58 = tmp57.to(tl.bfloat16)
    tmp59 = tmp58.to(tl.float32)
    tmp60 = tl.load(in_ptr0 + (2048 + 128*x1 + 6144*x2 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp61 = tmp60.to(tl.bfloat16)
    tmp62 = tmp61.to(tl.float32)
    tmp63 = tl.load(in_ptr2 + (64 + 128*tmp50 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp64 = tmp63.to(tl.bfloat16)
    tmp65 = tmp64.to(tl.float32)
    tmp66 = tmp62 * tmp65
    tmp67 = tmp66.to(tl.bfloat16)
    tmp68 = tmp67.to(tl.float32)
    tmp69 = tmp68.to(tl.bfloat16)
    tmp70 = tmp69.to(tl.float32)
    tmp71 = tmp59 + tmp70
    tmp72 = tmp71.to(tl.bfloat16)
    tmp73 = tmp72.to(tl.float32)
    tmp74 = tl.full(tmp73.shape, 0.0, tmp73.dtype)
    tmp75 = tl.where(tmp40, tmp73, tmp74)
    tmp76 = tl.where(tmp6, tmp39, tmp75)
    tmp77 = tl.load(in_ptr0 + (128*x1 + 6144*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp78 = tmp77.to(tl.bfloat16)
    tmp79 = tmp78.to(tl.float32)
    tmp80 = tmp79 * tmp18
    tmp81 = tmp80.to(tl.bfloat16)
    tmp82 = tmp81.to(tl.float32)
    tmp83 = tmp82.to(tl.bfloat16)
    tmp84 = tmp83.to(tl.float32)
    tmp85 = tl.load(in_ptr0 + (64 + 128*x1 + 6144*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp86 = tmp85.to(tl.bfloat16)
    tmp87 = tmp86.to(tl.float32)
    tmp88 = tmp87 * tmp29
    tmp89 = tmp88.to(tl.bfloat16)
    tmp90 = tmp89.to(tl.float32)
    tmp91 = tmp90.to(tl.bfloat16)
    tmp92 = tmp91.to(tl.float32)
    tmp93 = tmp84 - tmp92
    tmp94 = tmp93.to(tl.bfloat16)
    tmp95 = tmp94.to(tl.float32)
    tmp96 = tl.full(tmp95.shape, 0.0, tmp95.dtype)
    tmp97 = tl.where(tmp6, tmp95, tmp96)
    tmp98 = tl.load(in_ptr0 + (64 + 128*x1 + 6144*x2 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp99 = tmp98.to(tl.bfloat16)
    tmp100 = tmp99.to(tl.float32)
    tmp101 = tmp100 * tmp54
    tmp102 = tmp101.to(tl.bfloat16)
    tmp103 = tmp102.to(tl.float32)
    tmp104 = tmp103.to(tl.bfloat16)
    tmp105 = tmp104.to(tl.float32)
    tmp106 = tl.load(in_ptr0 + (128*x1 + 6144*x2 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp107 = tmp106.to(tl.bfloat16)
    tmp108 = tmp107.to(tl.float32)
    tmp109 = tmp108 * tmp65
    tmp110 = tmp109.to(tl.bfloat16)
    tmp111 = tmp110.to(tl.float32)
    tmp112 = tmp111.to(tl.bfloat16)
    tmp113 = tmp112.to(tl.float32)
    tmp114 = tmp105 + tmp113
    tmp115 = tmp114.to(tl.bfloat16)
    tmp116 = tmp115.to(tl.float32)
    tmp117 = tl.full(tmp116.shape, 0.0, tmp116.dtype)
    tmp118 = tl.where(tmp40, tmp116, tmp117)
    tmp119 = tl.where(tmp6, tmp97, tmp118)
    tl.store(out_ptr0 + (x4), tmp76, xmask)
    tl.store(out_ptr1 + (x4), tmp119, xmask)
''', device_str='cuda')

async_compile.wait(globals())
del async_compile

import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream
with torch.cuda._DeviceGuard(0):
    raw_stream0 = get_raw_stream(0)
raw_stream0 = get_raw_stream(0)
buf0 = generate_example_value((16384, 2048), (2048, 1), 'cuda:0', torch.bfloat16, 0, (16384, 2048))
arg4_1 = generate_example_value((16384, 2048), (2048, 1), 'cuda:0', torch.bfloat16, 0, (16384, 2048))
arg3_1 = generate_example_value((2048,), (1,), 'cuda:0', torch.bfloat16, 0, (2048,))
buf2 = generate_example_value((16384, 2048), (2048, 1), 'cuda:0', torch.bfloat16, 0, (16384, 2048))
with torch.cuda._DeviceGuard(0):
    triton_red_fused_fused_add_rms_norm_0.run(buf0, arg4_1, arg3_1, buf2, 16384, 2048, stream=raw_stream0)
del arg3_1, buf2

raw_stream0 = get_raw_stream(0)
arg5_1 = generate_example_value((60, 2048), (2048, 1), 'cuda:0', torch.bfloat16, 0, (60, 2048))
buf3 = generate_example_value((2048, 64), (1, 2048), 'cuda:0', torch.bfloat16, 0, (2048, 64))
with torch.cuda._DeviceGuard(0):
    triton_poi_fused_mm_t_1.run(arg5_1, buf3, 131072, stream=raw_stream0)
del arg5_1, buf3

raw_stream0 = get_raw_stream(0)
buf6 = generate_example_value((16384, 2048), (2048, 1), 'cuda:0', torch.bfloat16, 0, (16384, 2048))
buf7 = generate_example_value((16384, 2048), (2048, 1), 'cuda:0', torch.bfloat16, 0, (16384, 2048))
arg7_1 = generate_example_value((2048,), (1,), 'cuda:0', torch.bfloat16, 0, (2048,))
buf8 = generate_example_value((16384, 2048), (2048, 1), 'cuda:0', torch.bfloat16, 0, (16384, 2048))
buf10 = generate_example_value((16384, 2048), (2048, 1), 'cuda:0', torch.bfloat16, 0, (16384, 2048))
with torch.cuda._DeviceGuard(0):
    triton_red_fused_add_fused_add_rms_norm_2.run(buf6, buf7, buf0, arg4_1, arg7_1, buf8, buf10, 16384, 2048, stream=raw_stream0)
del buf0, arg4_1, buf6, buf7, arg7_1, buf8, buf10

raw_stream0 = get_raw_stream(0)
buf11 = generate_example_value((16384, 6144), (6144, 1), 'cuda:0', torch.bfloat16, 0, (16384, 6144))
arg10_1 = generate_example_value((16384,), (1,), 'cuda:0', torch.int64, 0, (16384,))
arg11_1 = generate_example_value((32768, 128), (128, 1), 'cuda:0', torch.bfloat16, 0, (32768, 128))
buf12 = generate_example_value((16384, 16, 128), (2048, 128, 1), 'cuda:0', torch.bfloat16, 0, (16384, 16, 128))
buf13 = generate_example_value((16384, 16, 128), (2048, 128, 1), 'cuda:0', torch.bfloat16, 0, (16384, 16, 128))
with torch.cuda._DeviceGuard(0):
    triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3.run(buf11, arg10_1, arg11_1, buf12, buf13, 33554432, stream=raw_stream0)
del buf11, arg10_1, arg11_1, buf12, buf13

"""
# AOT ID: ['1_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
from torch._C._dynamo.guards import copy_if_misaligned
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /root/causal/moe-precision-casts/compiled-emulate-precision-casts/cache/torchinductor/lu/clu55lqocaloii6ksgckte6j7fia52vabb5xdl6bgmwb3l5ccldd.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace], Original ATen: [vllm_ir.fused_add_rms_norm]
# Source node to ATen node mapping:
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, add_tensor_3, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_7, mean_dim_1, mul_tensor_2, mul_tensor_3, pow_tensor_scalar_1, rsqrt_default_1
# Graph fragment:
#   %mm : Tensor "bf16[s72, 2048][2048, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg4_1 : Tensor "bf16[s72, 2048][2048, 1]cuda:0" = PlaceHolder[target=arg4_1]
#   %buf1 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf1]
#   %arg3_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg3_1]
#   %convert_element_type_default_4 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mm, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %pow_tensor_scalar_1 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor_2, 2), kwargs = {})
#   %mean_dim_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar_1, [-1], True), kwargs = {})
#   %add_tensor_3 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim_1, 1e-06), kwargs = {})
#   %rsqrt_default_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_3,), kwargs = {})
#   %mul_tensor_2 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor_2, %rsqrt_default_1), kwargs = {})
#   %convert_element_type_default_7 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor_2, torch.bfloat16), kwargs = {})
#   %mul_tensor_3 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_7, %arg3_1), kwargs = {})
#   return %buf1,%mul_tensor_3
triton_red_fused_fused_add_rms_norm_0 = async_compile.triton('triton_red_fused_fused_add_rms_norm_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': False, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_fused_add_rms_norm_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 268439552}, 'kernel_num_gb': 0.201330688, 'kernel_flop': 0, 'backend_hash': '12CB7AF2462FDF7F0782918BFFA38096B8D56EE547964A5304EFBEAD2F02B50A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_fused_add_rms_norm_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp7 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp2 = tl.load(in_ptr1 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.float32)
        tmp3 = tmp2.to(tl.float32)
        tmp4 = tmp1 + tmp3
        tmp5 = tmp4 * tmp4
        tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
        tmp8 = _tmp7 + tmp6
        _tmp7 = tl.where(r0_mask & xmask, tmp8, _tmp7)
    tmp7 = tl.sum(_tmp7, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp9 = tl.load(in_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp11 = tl.load(in_ptr1 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp22 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tmp9.to(tl.float32)
        tmp12 = tmp11.to(tl.float32)
        tmp13 = tmp10 + tmp12
        tmp14 = tl.full([1, 1], 2048.0, tl.float32)
        tmp15 = (tmp7 / tmp14)
        tmp16 = tl.full([1, 1], 1e-06, tl.float32)
        tmp17 = tmp15 + tmp16
        tmp18 = libdevice.rsqrt(tmp17)
        tmp19 = tmp13 * tmp18
        tmp20 = tmp19.to(tl.bfloat16)
        tmp21 = tmp20.to(tl.float32)
        tmp23 = tmp21 * tmp22
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp23, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /root/causal/moe-precision-casts/compiled-emulate-precision-casts/cache/torchinductor/je/cjepwc2b2f7blgpglpblzmjcqqoeg3qaldks2kdlhr4dtokw2e6a.py
# Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.t, aten.mm]
# Source node to ATen node mapping:
#   linear_1 => constant_pad_nd_default, permute_1
# Graph fragment:
#   %arg5_1 : Tensor "bf16[60, 2048][2048, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %permute_1 : Tensor "bf16[2048, 60][1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg5_1, [1, 0]), kwargs = {})
#   %constant_pad_nd_default : Tensor "bf16[2048, 64][64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.constant_pad_nd.default](args = (%permute_1, [0, 4, 0, 0]), kwargs = {})
#   return %constant_pad_nd_default
triton_poi_fused_mm_t_1 = async_compile.triton('triton_poi_fused_mm_t_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 131072}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': False, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_mm_t_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 770048}, 'kernel_num_gb': 0.000507904, 'kernel_flop': 0, 'backend_hash': '12CB7AF2462FDF7F0782918BFFA38096B8D56EE547964A5304EFBEAD2F02B50A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_mm_t_1(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 131072
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x1 = xindex // 2048
    x0 = (xindex % 2048)
    x2 = xindex
    tmp0 = (x1).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x1).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 60, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tl.load(in_ptr0 + (x0 + 2048*(x1)), tmp6, other=0.0).to(tl.float32)
    tmp8 = tmp0 >= tmp5
    tmp9 = tl.full([1], 64, tl.int64)
    tmp10 = tmp0 < tmp9
    tmp11 = tl.full([1], 0.0, tl.float32)
    tmp12 = tl.full(tmp11.shape, 0.0, tmp11.dtype)
    tmp13 = tl.where(tmp8, tmp11, tmp12)
    tmp14 = tl.where(tmp6, tmp7, tmp13)
    tl.store(out_ptr0 + (x2), tmp14, None)
''', device_str='cuda')


# kernel path: /root/causal/moe-precision-casts/compiled-emulate-precision-casts/cache/torchinductor/4r/c4r4c7tovi2agspfoyfqqvxgh43aamu2ll2ddm4xvej6pblusnsw.py
# Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, add, fused_add_rms_norm_maybe_inplace_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten.add]
# Source node to ATen node mapping:
#   add => add_24
#   fused_add_rms_norm_maybe_inplace => add_tensor_2, convert_element_type_default_4, convert_element_type_default_5, convert_element_type_default_6
#   fused_add_rms_norm_maybe_inplace_1 => add_tensor, add_tensor_1, convert_element_type_default, convert_element_type_default_1, convert_element_type_default_2, convert_element_type_default_3, mean_dim, mul_tensor, mul_tensor_1, pow_tensor_scalar, rsqrt_default
# Graph fragment:
#   %getitem_2 : Tensor "bf16[s72, 2048][2048, 1]cuda:0" = PlaceHolder[target=getitem_2]
#   %getitem_3 : Tensor "bf16[s72, 2048][2048, 1]cuda:0" = PlaceHolder[target=getitem_3]
#   %mm : Tensor "bf16[s72, 2048][2048, 1]cuda:0" = PlaceHolder[target=mm]
#   %arg4_1 : Tensor "bf16[s72, 2048][2048, 1]cuda:0" = PlaceHolder[target=arg4_1]
#   %buf9 : Tensor "f32[s72, 1][1, s72]cuda:0" = PlaceHolder[target=buf9]
#   %arg7_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg7_1]
#   %convert_element_type_default_4 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mm, torch.float32), kwargs = {})
#   %convert_element_type_default_5 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_tensor_2 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default_4, %convert_element_type_default_5), kwargs = {})
#   %convert_element_type_default_6 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor_2, torch.bfloat16), kwargs = {})
#   %add_24 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%getitem_2, %getitem_3), kwargs = {})
#   %convert_element_type_default : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_24, torch.float32), kwargs = {})
#   %convert_element_type_default_1 : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%convert_element_type_default_6, torch.float32), kwargs = {})
#   %add_tensor : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_default, %convert_element_type_default_1), kwargs = {})
#   %convert_element_type_default_2 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_tensor, torch.bfloat16), kwargs = {})
#   %pow_tensor_scalar : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%add_tensor, 2), kwargs = {})
#   %mean_dim : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_tensor_scalar, [-1], True), kwargs = {})
#   %add_tensor_1 : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_dim, 1e-06), kwargs = {})
#   %rsqrt_default : Tensor "f32[s72, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_tensor_1,), kwargs = {})
#   %mul_tensor : Tensor "f32[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%add_tensor, %rsqrt_default), kwargs = {})
#   %convert_element_type_default_3 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_tensor, torch.bfloat16), kwargs = {})
#   %mul_tensor_1 : Tensor "bf16[s72, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_default_3, %arg7_1), kwargs = {})
#   return %buf9,%convert_element_type_default_2,%mul_tensor_1
triton_red_fused_add_fused_add_rms_norm_2 = async_compile.triton('triton_red_fused_add_fused_add_rms_norm_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 16384, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': False, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_red_fused_add_fused_add_rms_norm_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 9, 'num_store': 2, 'num_reduction': 1, 'autotune_hints': set(), 'tiling_scores': {'x': 0, 'r0_': 536875008}, 'kernel_num_gb': 0.40265728, 'kernel_flop': 0, 'backend_hash': '12CB7AF2462FDF7F0782918BFFA38096B8D56EE547964A5304EFBEAD2F02B50A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False}
)
@triton.jit
def triton_red_fused_add_fused_add_rms_norm_2(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    _tmp21 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp0 = tl.load(in_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp3 = tl.load(in_ptr1 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp10 = tl.load(in_ptr2 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp12 = tl.load(in_ptr3 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp1 = tmp0.to(tl.bfloat16)
        tmp2 = tmp1.to(tl.float32)
        tmp4 = tmp3.to(tl.bfloat16)
        tmp5 = tmp4.to(tl.float32)
        tmp6 = tmp2 + tmp5
        tmp7 = tmp6.to(tl.bfloat16)
        tmp8 = tmp7.to(tl.float32)
        tmp9 = tmp8.to(tl.float32)
        tmp11 = tmp10.to(tl.float32)
        tmp13 = tmp12.to(tl.float32)
        tmp14 = tmp11 + tmp13
        tmp15 = tmp14.to(tl.bfloat16)
        tmp16 = tmp15.to(tl.float32)
        tmp17 = tmp16.to(tl.float32)
        tmp18 = tmp9 + tmp17
        tmp19 = tmp18 * tmp18
        tmp20 = tl.broadcast_to(tmp19, [XBLOCK, R0_BLOCK])
        tmp22 = _tmp21 + tmp20
        _tmp21 = tl.where(r0_mask & xmask, tmp22, _tmp21)
        tmp23 = tmp18.to(tl.bfloat16)
        tmp24 = tmp23.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp24, r0_mask & xmask)
    tmp21 = tl.sum(_tmp21, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp25 = tl.load(in_ptr0 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp28 = tl.load(in_ptr1 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp35 = tl.load(in_ptr2 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp37 = tl.load(in_ptr3 + (r0_1 + 2048*x0), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp52 = tl.load(in_ptr4 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp26 = tmp25.to(tl.bfloat16)
        tmp27 = tmp26.to(tl.float32)
        tmp29 = tmp28.to(tl.bfloat16)
        tmp30 = tmp29.to(tl.float32)
        tmp31 = tmp27 + tmp30
        tmp32 = tmp31.to(tl.bfloat16)
        tmp33 = tmp32.to(tl.float32)
        tmp34 = tmp33.to(tl.float32)
        tmp36 = tmp35.to(tl.float32)
        tmp38 = tmp37.to(tl.float32)
        tmp39 = tmp36 + tmp38
        tmp40 = tmp39.to(tl.bfloat16)
        tmp41 = tmp40.to(tl.float32)
        tmp42 = tmp41.to(tl.float32)
        tmp43 = tmp34 + tmp42
        tmp44 = tl.full([1, 1], 2048.0, tl.float32)
        tmp45 = (tmp21 / tmp44)
        tmp46 = tl.full([1, 1], 1e-06, tl.float32)
        tmp47 = tmp45 + tmp46
        tmp48 = libdevice.rsqrt(tmp47)
        tmp49 = tmp43 * tmp48
        tmp50 = tmp49.to(tl.bfloat16)
        tmp51 = tmp50.to(tl.float32)
        tmp53 = tmp51 * tmp52
        tl.store(out_ptr2 + (r0_1 + 2048*x0), tmp53, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /root/causal/moe-precision-casts/compiled-emulate-precision-casts/cache/torchinductor/lk/clkx6gpxpy5s22rxdwdub2svtvn2kzrb6ek6whmctnfqpjbohwdb.py
# Topologically Sorted Source Nodes: [split, index_select, chunk, view_3, chunk_1, view_4, chunk_2, unsqueeze_2, mul_4, unsqueeze_3, mul_5, sub_1, mul_6, mul_7, add_2, cat_2, unsqueeze, mul, unsqueeze_1, mul_1, sub, mul_2, mul_3, add_1, cat], Original ATen: [aten.split_with_sizes, aten.index_select, aten.split, aten.view, aten.unsqueeze, aten.mul, aten.sub, aten.add, aten.cat]
# Source node to ATen node mapping:
#   add_1 => add_104
#   add_2 => add_166
#   cat => cat
#   cat_2 => cat_1
#   chunk => split
#   chunk_1 => split_1
#   chunk_2 => split_2
#   index_select => index
#   mul => mul_53
#   mul_1 => mul_56
#   mul_2 => mul_61
#   mul_3 => mul_64
#   mul_4 => mul_92
#   mul_5 => mul_95
#   mul_6 => mul_100
#   mul_7 => mul_103
#   split => split_with_sizes
#   sub => sub_28
#   sub_1 => sub_45
#   unsqueeze => unsqueeze
#   unsqueeze_1 => unsqueeze_1
#   unsqueeze_2 => unsqueeze_2
#   unsqueeze_3 => unsqueeze_3
#   view_3 => view_3
#   view_4 => view_5
# Graph fragment:
#   %addmm : Tensor "bf16[s72, 6144][6144, 1]cuda:0" = PlaceHolder[target=addmm]
#   %arg10_1 : Tensor "i64[s72][1]cuda:0" = PlaceHolder[target=arg10_1]
#   %arg11_1 : Tensor "bf16[32768, 128][128, 1]cuda:0" = PlaceHolder[target=arg11_1]
#   %split_with_sizes : [num_users=3] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%addmm, [2048, 2048, 2048], -1), kwargs = {})
#   %index : Tensor "bf16[s72, 128][128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg11_1, [%arg10_1]), kwargs = {})
#   %split : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%index, 64, -1), kwargs = {})
#   %view_3 : Tensor "bf16[s72, 16, 128][6144, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_6, [%arg1_1, -1, 128]), kwargs = {})
#   %split_1 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_3, 64, -1), kwargs = {})
#   %view_5 : Tensor "bf16[s72, 16, 128][6144, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_7, [%arg1_1, -1, 128]), kwargs = {})
#   %split_2 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_5, 64, -1), kwargs = {})
#   %unsqueeze_2 : Tensor "bf16[s72, 1, 64][128, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem_9, -2), kwargs = {})
#   %mul_92 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_13, %unsqueeze_2), kwargs = {})
#   %unsqueeze_3 : Tensor "bf16[s72, 1, 64][128, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem_10, -2), kwargs = {})
#   %mul_95 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_14, %unsqueeze_3), kwargs = {})
#   %sub_45 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%mul_92, %mul_95), kwargs = {})
#   %mul_100 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_14, %unsqueeze_2), kwargs = {})
#   %mul_103 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_13, %unsqueeze_3), kwargs = {})
#   %add_166 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_100, %mul_103), kwargs = {})
#   %cat_1 : Tensor "bf16[s72, 16, 128][2048, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%sub_45, %add_166], -1), kwargs = {})
#   %unsqueeze : Tensor "bf16[s72, 1, 64][128, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem_9, -2), kwargs = {})
#   %mul_53 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_11, %unsqueeze), kwargs = {})
#   %unsqueeze_1 : Tensor "bf16[s72, 1, 64][128, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%getitem_10, -2), kwargs = {})
#   %mul_56 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_12, %unsqueeze_1), kwargs = {})
#   %sub_28 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%mul_53, %mul_56), kwargs = {})
#   %mul_61 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_12, %unsqueeze), kwargs = {})
#   %mul_64 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%getitem_11, %unsqueeze_1), kwargs = {})
#   %add_104 : Tensor "bf16[s72, 16, 64][1024, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_61, %mul_64), kwargs = {})
#   %cat : Tensor "bf16[s72, 16, 128][2048, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%sub_28, %add_104], -1), kwargs = {})
#   return %cat_1,%cat
triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3 = async_compile.triton('triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 33554432}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*i64', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=132, cc=90, major=9, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': False, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'kernel_name': 'triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 10, 'num_store': 2, 'num_reduction': 0, 'autotune_hints': set(), 'tiling_scores': {'x': 671219712}, 'kernel_num_gb': 0.67960832, 'kernel_flop': 0, 'backend_hash': '12CB7AF2462FDF7F0782918BFFA38096B8D56EE547964A5304EFBEAD2F02B50A', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'incremental_autotune': False, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'batch_invariant': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': True, 'dynamic_disable_pipelining': True, 'are_deterministic_algorithms_enabled': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 128)
    x1 = ((xindex // 128) % 16)
    x2 = xindex // 2048
    x4 = xindex
    tmp0 = (x0).to(tl.int32)
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = (x0).to(tl.int64)
    tmp4 = (tmp3).to(tl.int64)
    tmp5 = tl.full([1], 64, tl.int64)
    tmp6 = tmp4 < tmp5
    tmp7 = tl.load(in_ptr0 + (2048 + 128*x1 + 6144*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp8 = tmp7.to(tl.bfloat16)
    tmp9 = tmp8.to(tl.float32)
    tmp10 = tl.load(in_ptr1 + (x2), tmp6 & xmask, eviction_policy='evict_last', other=0.0)
    tmp11 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp10 < 0
    tmp14 = tl.where(tmp13, tmp12, tmp10)
    tl.device_assert(((0 <= tl.broadcast_to(tmp14, [XBLOCK])) & (tl.broadcast_to(tmp14, [XBLOCK]) < 32768)) | ~(tmp6 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp14, [XBLOCK]) < 32768")
    tmp16 = tl.load(in_ptr2 + (128*tmp14 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp17 = tmp16.to(tl.bfloat16)
    tmp18 = tmp17.to(tl.float32)
    tmp19 = tmp9 * tmp18
    tmp20 = tmp19.to(tl.bfloat16)
    tmp21 = tmp20.to(tl.float32)
    tmp22 = tmp21.to(tl.bfloat16)
    tmp23 = tmp22.to(tl.float32)
    tmp24 = tl.load(in_ptr0 + (2112 + 128*x1 + 6144*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp25 = tmp24.to(tl.bfloat16)
    tmp26 = tmp25.to(tl.float32)
    tmp27 = tl.load(in_ptr2 + (64 + 128*tmp14 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp28 = tmp27.to(tl.bfloat16)
    tmp29 = tmp28.to(tl.float32)
    tmp30 = tmp26 * tmp29
    tmp31 = tmp30.to(tl.bfloat16)
    tmp32 = tmp31.to(tl.float32)
    tmp33 = tmp32.to(tl.bfloat16)
    tmp34 = tmp33.to(tl.float32)
    tmp35 = tmp23 - tmp34
    tmp36 = tmp35.to(tl.bfloat16)
    tmp37 = tmp36.to(tl.float32)
    tmp38 = tl.full(tmp37.shape, 0.0, tmp37.dtype)
    tmp39 = tl.where(tmp6, tmp37, tmp38)
    tmp40 = tmp0 >= tmp5
    tmp41 = tl.full([1], 128, tl.int64)
    tmp42 = tmp0 < tmp41
    tmp43 = tl.load(in_ptr0 + (2112 + 128*x1 + 6144*x2 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp44 = tmp43.to(tl.bfloat16)
    tmp45 = tmp44.to(tl.float32)
    tmp46 = tl.load(in_ptr1 + (x2), tmp40 & xmask, eviction_policy='evict_last', other=0.0)
    tmp47 = (tl.full([XBLOCK], 32768, tl.int32)).to(tl.int32)
    tmp48 = tmp46 + tmp47
    tmp49 = tmp46 < 0
    tmp50 = tl.where(tmp49, tmp48, tmp46)
    tl.device_assert(((0 <= tl.broadcast_to(tmp50, [XBLOCK])) & (tl.broadcast_to(tmp50, [XBLOCK]) < 32768)) | ~(tmp40 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp50, [XBLOCK]) < 32768")
    tmp52 = tl.load(in_ptr2 + (128*tmp50 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp53 = tmp52.to(tl.bfloat16)
    tmp54 = tmp53.to(tl.float32)
    tmp55 = tmp45 * tmp54
    tmp56 = tmp55.to(tl.bfloat16)
    tmp57 = tmp56.to(tl.float32)
    tmp58 = tmp57.to(tl.bfloat16)
    tmp59 = tmp58.to(tl.float32)
    tmp60 = tl.load(in_ptr0 + (2048 + 128*x1 + 6144*x2 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp61 = tmp60.to(tl.bfloat16)
    tmp62 = tmp61.to(tl.float32)
    tmp63 = tl.load(in_ptr2 + (64 + 128*tmp50 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp64 = tmp63.to(tl.bfloat16)
    tmp65 = tmp64.to(tl.float32)
    tmp66 = tmp62 * tmp65
    tmp67 = tmp66.to(tl.bfloat16)
    tmp68 = tmp67.to(tl.float32)
    tmp69 = tmp68.to(tl.bfloat16)
    tmp70 = tmp69.to(tl.float32)
    tmp71 = tmp59 + tmp70
    tmp72 = tmp71.to(tl.bfloat16)
    tmp73 = tmp72.to(tl.float32)
    tmp74 = tl.full(tmp73.shape, 0.0, tmp73.dtype)
    tmp75 = tl.where(tmp40, tmp73, tmp74)
    tmp76 = tl.where(tmp6, tmp39, tmp75)
    tmp77 = tl.load(in_ptr0 + (128*x1 + 6144*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp78 = tmp77.to(tl.bfloat16)
    tmp79 = tmp78.to(tl.float32)
    tmp80 = tmp79 * tmp18
    tmp81 = tmp80.to(tl.bfloat16)
    tmp82 = tmp81.to(tl.float32)
    tmp83 = tmp82.to(tl.bfloat16)
    tmp84 = tmp83.to(tl.float32)
    tmp85 = tl.load(in_ptr0 + (64 + 128*x1 + 6144*x2 + (x0)), tmp6 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp86 = tmp85.to(tl.bfloat16)
    tmp87 = tmp86.to(tl.float32)
    tmp88 = tmp87 * tmp29
    tmp89 = tmp88.to(tl.bfloat16)
    tmp90 = tmp89.to(tl.float32)
    tmp91 = tmp90.to(tl.bfloat16)
    tmp92 = tmp91.to(tl.float32)
    tmp93 = tmp84 - tmp92
    tmp94 = tmp93.to(tl.bfloat16)
    tmp95 = tmp94.to(tl.float32)
    tmp96 = tl.full(tmp95.shape, 0.0, tmp95.dtype)
    tmp97 = tl.where(tmp6, tmp95, tmp96)
    tmp98 = tl.load(in_ptr0 + (64 + 128*x1 + 6144*x2 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp99 = tmp98.to(tl.bfloat16)
    tmp100 = tmp99.to(tl.float32)
    tmp101 = tmp100 * tmp54
    tmp102 = tmp101.to(tl.bfloat16)
    tmp103 = tmp102.to(tl.float32)
    tmp104 = tmp103.to(tl.bfloat16)
    tmp105 = tmp104.to(tl.float32)
    tmp106 = tl.load(in_ptr0 + (128*x1 + 6144*x2 + ((-64) + x0)), tmp40 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp107 = tmp106.to(tl.bfloat16)
    tmp108 = tmp107.to(tl.float32)
    tmp109 = tmp108 * tmp65
    tmp110 = tmp109.to(tl.bfloat16)
    tmp111 = tmp110.to(tl.float32)
    tmp112 = tmp111.to(tl.bfloat16)
    tmp113 = tmp112.to(tl.float32)
    tmp114 = tmp105 + tmp113
    tmp115 = tmp114.to(tl.bfloat16)
    tmp116 = tmp115.to(tl.float32)
    tmp117 = tl.full(tmp116.shape, 0.0, tmp116.dtype)
    tmp118 = tl.where(tmp40, tmp116, tmp117)
    tmp119 = tl.where(tmp6, tmp97, tmp118)
    tl.store(out_ptr0 + (x4), tmp76, xmask)
    tl.store(out_ptr1 + (x4), tmp119, xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1 = args
        args.clear()
        s72 = arg1_1
        s80 = s72
        assert_size_stride(arg0_1, (s72, 16, 128), (2048, 128, 1), 'input')
        assert_size_stride(arg2_1, (2048, 2048), (2048, 1), 'input')
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            arg0_1 = copy_if_misaligned(arg0_1)
            arg2_1 = copy_if_misaligned(arg2_1)
            buf0 = empty_strided_cuda((s72, 2048), (2048, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [view, linear], Original ATen: [aten.view, aten.t, aten.mm]
            extern_kernels.mm(reinterpret_tensor(arg0_1, (s72, 2048), (2048, 1), 0), reinterpret_tensor(arg2_1, (2048, 2048), (1, 2048), 0), out=buf0)
            del arg0_1
            del arg2_1
            assert_size_stride(arg4_1, (s72, 2048), (2048, 1), 'input')
            assert_size_stride(arg3_1, (2048, ), (1, ), 'input')
            arg4_1 = copy_if_misaligned(arg4_1)
            arg3_1 = copy_if_misaligned(arg3_1)
            buf2 = empty_strided_cuda((s72, 2048), (2048, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace], Original ATen: [vllm_ir.fused_add_rms_norm]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_fused_add_rms_norm_0.run(buf0, arg4_1, arg3_1, buf2, s72, 2048, stream=raw_stream0)
            del arg3_1
            assert_size_stride(arg5_1, (60, 2048), (2048, 1), 'input')
            arg5_1 = copy_if_misaligned(arg5_1)
            buf3 = empty_strided_cuda((2048, 64), (1, 2048), torch.bfloat16)
            # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.t, aten.mm]
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_mm_t_1.run(arg5_1, buf3, 131072, stream=raw_stream0)
            del arg5_1
            buf4 = empty_strided_cuda((s72, 64), (64, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [linear_1], Original ATen: [aten.t, aten.mm]
            extern_kernels.mm(buf2, buf3, out=buf4)
            del buf3
            # Topologically Sorted Source Nodes: [linear_1, moe_forward_shared], Original ATen: [aten.mm, vllm.moe_forward_shared]
            buf5 = torch.ops.vllm.moe_forward_shared.default(buf2, reinterpret_tensor(buf4, (s72, 60), (64, 1), 0), buf2, None, arg6_1, 0)
            del arg6_1
            del buf4
            buf6 = buf5[0]
            assert_size_stride(buf6, (s72, 2048), (2048, 1), 'torch.ops.vllm.moe_forward_shared.default')
            assert_alignment(buf6, 16, 'torch.ops.vllm.moe_forward_shared.default')
            buf7 = buf5[1]
            assert_size_stride(buf7, (s72, 2048), (2048, 1), 'torch.ops.vllm.moe_forward_shared.default')
            assert_alignment(buf7, 16, 'torch.ops.vllm.moe_forward_shared.default')
            del buf5
            assert_size_stride(arg7_1, (2048, ), (1, ), 'input')
            arg7_1 = copy_if_misaligned(arg7_1)
            buf8 = buf2; del buf2  # reuse
            buf10 = empty_strided_cuda((s72, 2048), (2048, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, add, fused_add_rms_norm_maybe_inplace_1], Original ATen: [vllm_ir.fused_add_rms_norm, aten.add]
            raw_stream0 = get_raw_stream(0)
            triton_red_fused_add_fused_add_rms_norm_2.run(buf6, buf7, buf0, arg4_1, arg7_1, buf8, buf10, s72, 2048, stream=raw_stream0)
            del arg4_1
            del arg7_1
            del buf0
            assert_size_stride(arg9_1, (6144, ), (1, ), 'input')
            assert_size_stride(arg8_1, (6144, 2048), (2048, 1), 'input')
            arg9_1 = copy_if_misaligned(arg9_1)
            arg8_1 = copy_if_misaligned(arg8_1)
            buf11 = empty_strided_cuda((s72, 6144), (6144, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [fused_add_rms_norm_maybe_inplace, add, fused_add_rms_norm_maybe_inplace_1, linear_2], Original ATen: [vllm_ir.fused_add_rms_norm, aten.add, aten.t, aten.addmm]
            extern_kernels.addmm(arg9_1, buf10, reinterpret_tensor(arg8_1, (2048, 6144), (1, 2048), 0), alpha=1, beta=1, out=buf11)
            del arg8_1
            del arg9_1
            assert_size_stride(arg10_1, (s72, ), (1, ), 'input')
            assert_size_stride(arg11_1, (32768, 128), (128, 1), 'input')
            arg10_1 = copy_if_misaligned(arg10_1)
            arg11_1 = copy_if_misaligned(arg11_1)
            buf12 = reinterpret_tensor(buf10, (s72, 16, 128), (2048, 128, 1), 0); del buf10  # reuse
            buf13 = reinterpret_tensor(buf7, (s72, 16, 128), (2048, 128, 1), 0); del buf7  # reuse
            # Topologically Sorted Source Nodes: [split, index_select, chunk, view_3, chunk_1, view_4, chunk_2, unsqueeze_2, mul_4, unsqueeze_3, mul_5, sub_1, mul_6, mul_7, add_2, cat_2, unsqueeze, mul, unsqueeze_1, mul_1, sub, mul_2, mul_3, add_1, cat], Original ATen: [aten.split_with_sizes, aten.index_select, aten.split, aten.view, aten.unsqueeze, aten.mul, aten.sub, aten.add, aten.cat]
            triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3_xnumel = 2048*s72
            raw_stream0 = get_raw_stream(0)
            triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3.run(buf11, arg10_1, arg11_1, buf12, buf13, triton_poi_fused_add_cat_index_select_mul_split_split_with_sizes_sub_unsqueeze_view_3_xnumel, stream=raw_stream0)
            del arg10_1
            del arg11_1
            buf14 = buf6; del buf6  # reuse
        return (buf12, reinterpret_tensor(buf11, (s72, 16, 128), (6144, 128, 1), 4096), buf13, reinterpret_tensor(buf14, (s72, 16, 128), (2048, 128, 1), 0), buf8, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((16384, 16, 128), (2048, 128, 1), device='cuda:0', dtype=torch.bfloat16)
    arg1_1 = 16384
    arg2_1 = rand_strided((2048, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg3_1 = rand_strided((2048, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg4_1 = rand_strided((16384, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg5_1 = rand_strided((60, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg6_1 = None
    arg7_1 = rand_strided((2048, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg8_1 = rand_strided((6144, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg9_1 = rand_strided((6144, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg10_1 = rand_strided((16384, ), (1, ), device='cuda:0', dtype=torch.int64)
    arg11_1 = rand_strided((32768, 128), (128, 1), device='cuda:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat, device='cuda')


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
